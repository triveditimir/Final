import dialog from 'dialog-node';
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { PlaywrightWebBaseLoader, Page } from "langchain/document_loaders/web/playwright";
import path from 'path';
import fs from 'fs';
import { TextLoader } from 'langchain/document_loaders/fs/text';
import {
  RunnableConfig,
  RunnableWithMessageHistory,
} from "@langchain/core/runnables";
import { ChatMessageHistory } from "@langchain/community/stores/message/in_memory";
import config from '../config/config.json' with { type: "json" };

var retvalue;
var retvalue1 = "OK";
var elementLocator;
let i = 0, j = 1;
let data = []

const basePath = config.openaiBasePath;
const siteURL = config.siteUrl;


const model = new ChatOpenAI({
  openAIApiKey: config.openaiApiKey,
  temperature: 0.1,
  maxRetries: 0,
  maxTokens: -1,
},
  {
    basePath: `${basePath}/mmc-tech-gpt-4o-mini-128k-2024-07-18/`,
  });

const chat = async () => {


  function showDialog(msg, title, timeout) {
    return new Promise((resolve, reject) => {
      dialog.question(msg, title, timeout, (code, retVal, stderr) => {
        if (code === 0) {
          resolve(retVal);
        } else {
          reject(stderr);
        }
      });
    });
  }

  async function htmlPopup() {
    try {
      const result = await showDialog('Do you want to Capture html?', 'Capture HTML', 10000);
      retvalue = result
    } catch (error) {
      console.error(error);
    }
  }

  async function entryelementLocator(msg, title, timeout) {
    return new Promise((resolve, reject) => {
      dialog.entry(msg, title, timeout, (code, retVal, stderr) => {
        if (code === 0) {
          resolve(retVal);
        } else {
          reject(stderr);
        }
      });
    });
  }

  async function enterLocator() {
    try {
      const resultLocator = await entryelementLocator("Enter Locator Detail", " Locator Details", 10000);
      elementLocator = resultLocator
    } catch (error) {
      console.error(error);
    }
  }

  async function writeToHtmlFile(outputFilePath, htmlPage) {
    return new Promise((resolve, reject) => {
      fs.writeFile(outputFilePath, htmlPage, function (err) {
        if (err) reject(err);
        else resolve('Saved!');
      });
    });
  }


  const promptTemplate = ChatPromptTemplate.fromMessages([
    ["human", "You are a helpful assistant"],
    ["human", "{input}"],
  ]);




  const runnable = promptTemplate.pipe(model);

  const messageHistory = new ChatMessageHistory();

  const withHistory = new RunnableWithMessageHistory({
    runnable,

    getMessageHistory: (_sessionId: string) => messageHistory,
    inputMessagesKey: "input",

    historyMessagesKey: "history",
  });

  const __dirname = path.resolve();

  const loader = new PlaywrightWebBaseLoader(siteURL,
    {
      launchOptions: {
        headless: false,
      },
      gotoOptions: {
        waitUntil: "load",
      },
      async evaluate(page: Page) {
        // await page.waitForSelector('#okta-signin-username');
        // const result = await page.$eval('div.content-wrapper', element => element.textContent)
        // return result;
        while (retvalue1 === "OK") {
          await htmlPopup()
          if (retvalue === "OK") {
            await enterLocator()
            console.log()
            //let htmlPagewhole:string = (await page.content()).toString()

            let htmlPagewhole: string = await page.$eval(elementLocator, element => element.outerHTML)
            //await page.innerHTML(elementLocator)
            //let htmlBody = htmlPagewhole.substring(htmlPagewhole.indexOf("<div"),htmlPagewhole.lastIndexOf("</div>")+6)
            let outputFilePath = path.join(__dirname, "data", "output", "HTML", "HTML_" + i.toString() + ".txt")
            console.log("outputFilePath-->", outputFilePath)
            data.push(await page.title())
            const fileWriteResult = await writeToHtmlFile(outputFilePath, htmlPagewhole);
            //const fileWriteResult = await writeToHtmlFile(outputFilePath,htmlPagewhole);
            console.log(`File write result: ${fileWriteResult}`);
            i++;
          } else {
            break;
          }
          retvalue1 = retvalue
        }
        return "Hello";
      }
    }
  );
  //const loader = new TextLoader("./data/keywords.txt");
  const data1 = await loader.load();
  //console.log(data1[0].pageContent.toString())
  var loaderHTML;
  var htmlText;
  var lengthofOutput;
  var maxToken = 10000
  console.log("data.length -->", data.length)
  for (let i = 0; i < data.length; i++) {
    const config: RunnableConfig = { configurable: { sessionId: 50 } };
    var inputFilePathFeature = path.join(__dirname, "data", "output", "HTML", "HTML_" + i.toString() + ".txt")
    var loader1 = new TextLoader(inputFilePathFeature)
    loaderHTML = await loader1.load()
    htmlText = loaderHTML[0].pageContent.toString()
    lengthofOutput = htmlText.length
    console.log("lengthofHTML", htmlText.length)
    var count = Math.ceil(lengthofOutput / maxToken)
    var start = 0
    var outputGherkinscript = "";
    var outputStepDefinition = "";
    for (let j = 0; j < count; j++) {
      var inputMessage = "Below html is a portion of the larger webpage. As a automation tester could you please help me to create a cucumberjs feature file using below portion of the html \n" + htmlText.substring(start, start + maxToken)
      var output = await withHistory.invoke({ input: inputMessage }, config);
      //console.log("output Message", output.content.toString())
      if (!output.content.toString().toLowerCase().includes("sorry")) {
        outputGherkinscript = outputGherkinscript + output.content.toString()
      }
      //console.log(outputGherkinscript)

      //var inputMessagepage = "You are an automation tester. Below html is a portion of the larger webpage. Help me create page object pattern and getter setters for all the elements if present with type links, text boxes, buttons, radio buttons, checkboxes and dropdowns with page object model for below HTML in Playwright and TypeScript format. \n" + htmlText.substring(start, start + maxToken)
      //var inputMessagepage = "You are an automation tester. Below html is a portion of the larger webpage. Help me create page object pattern and getter setters for all the elements if present with type links, text boxes, buttons, radio buttons, checkboxes and dropdowns with page object model for below HTML in selenium and java format. \n" + htmlText.substring(start, start + maxToken)
      var inputMessagepage = `You are an expert automation engineer specializing in Playwright and TypeScript.
                              Generate a production-ready Page Object Model implementation from the HTML file under sources ${htmlText.substring(start, start + maxToken)} and following are the requirements:

                              1. **Element Identification**
                              - Categorize elements by type: links, textboxes, buttons, radio, checkboxes, dropdowns
                              - Use semantic HTML attributes in priority order:
                              1. data-testid
                              2. ARIA roles
                              3. Text content matching
                              4. CSS selectors (last resort)

                              2. **Class Structure**
                              - Implement using Abstract Base Page pattern
                              - Separate element definitions from interaction methods
                              - Include type guards for dynamic element states

                              3. **Code Standards**
                              - TypeScript 5.0+ with strict null checks
                              - Playwright 1.40+ best practices
                              - Documentation with TSDoc
                              - Error handling for element visibility/timeouts

                              4. **Output Format**
                              Provide a complete TypeScript file with the following structure:
                              - Import statements for necessary Playwright modules.-Abstract Base Page class definition.
                              - Specific Page Object class definition (e.g., FirstPage).
                              - Element definitions as private getters.
                              - Public methods for interactions with the page.Error handling and visibility checks.
                              - TSDoc comments for each method and class. 
                              `
      var output1 = await withHistory.invoke({ input: inputMessagepage }, config);
      //console.log(output1.content.toString())
      if (!output1.content.toString().toLowerCase().includes("sorry")) { 
        outputStepDefinition = outputStepDefinition + output1.content.toString()
      }
      // if(!output1.content.toString().toLowerCase().includes("sorry")){
      //   outputStepDefinition=outputStepDefinition+output1.content.toString()
      // }
      // outputStepDefinition=outputStepDefinition+output1.content.toString()
      start = start + maxToken
    }
    // console.log("outputGherkinscript",outputGherkinscript)
    //console.log("outputGherkinscript", outputGherkinscript)
    var outputFilePathFeature = path.join(__dirname, "data", "output", "Feature", "feature_" +i.toString() + ".feature")
    //console.log("outputFilePathFeature", outputFilePathFeature)
    if (outputGherkinscript.length > 0) {
      const fileWriteResult = await writeToHtmlFile(outputFilePathFeature, outputGherkinscript);
    }
    var outputFilePathDefinition = path.join(__dirname, "data", "output", "pageObject", "pageObject" + i.toString() + ".steps.ts")
    // console.log("outputFilePathStep definition",outputFilePathDefinition)
    if (outputStepDefinition.length > 0) {
      var inputMessageCodeOptimize = "Redefine the following typescript code to improve readability, performance, and best practices. Ensure correct type annotation, remove reduntant code, and optimize logic where necessary. Return only the improved code without any explanation" + outputStepDefinition
      var outputOptimizeCode = await withHistory.invoke({ input: inputMessageCodeOptimize }, config);
      var outputOptimizeCodeUpdated = outputOptimizeCode.content.toString()
      if (outputOptimizeCodeUpdated.length > 0){
        const fileWriteResult = await writeToHtmlFile(outputFilePathDefinition, outputOptimizeCodeUpdated);
      }
    }
  }
}
chat();
