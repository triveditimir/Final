import dialog from 'dialog-node';
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { PlaywrightWebBaseLoader, Page } from "langchain/document_loaders/web/playwright";
import path from 'path';
import fs from 'fs';
import { TextLoader } from 'langchain/document_loaders/fs/text';
import {
  RunnableConfig,
  RunnableWithMessageHistory,
} from "@langchain/core/runnables";
import { ChatMessageHistory } from "@langchain/community/stores/message/in_memory";
import { error } from 'console';
import config from '../config/config.json' with { type: "json" };


var dir = '././data/output/API/';

const basePath = config.openaiBasePath;


const model = new ChatOpenAI({
  openAIApiKey: config.openaiApiKey,
  temperature: 0.1,
  maxRetries: 0,
  maxTokens: -1,
},
  {
    basePath: `${basePath}/mmc-tech-gpt-4o-mini-128k-2024-07-18/`,
  });

const chat = async () => {


   async function writeToHtmlFile(outputFilePath, htmlPage) {
      return new Promise((resolve, reject) => {
        fs.writeFile(outputFilePath, htmlPage, function (err) {
          if (err) reject(err);
          else resolve('Saved!');
        });
      });
    }
  

 

  const promptTemplate = ChatPromptTemplate.fromMessages([
    ["human", "You are a helpful assistant"],
    ["human", "{input}"],
  ]);




  const runnable = promptTemplate.pipe(model);

  const messageHistory = new ChatMessageHistory();

  const withHistory = new RunnableWithMessageHistory({
    runnable,

    getMessageHistory: (_sessionId: string) => messageHistory,
    inputMessagesKey: "input",

    historyMessagesKey: "history",
  });

  const __dirname = path.resolve();

 
  
  
  var responsetxt;
  var htmlText;
  var responseText;
  var requestText;
  var requesttxt;
  var lengthofOutput;
  var maxToken = 5000
  
  const config: RunnableConfig = { configurable: { sessionId: 50 } };
  var inputFilePathResponse = dir +"Response" + "/"+"response.txt"
  var response = new TextLoader(inputFilePathResponse)
  responsetxt = await response.load()
  responseText = responsetxt[0].pageContent.toString()

  var inputFilePathRequest = dir +"Request" + "/"+"request.txt"
  var request = new TextLoader(inputFilePathRequest)
  requesttxt = await request.load()
  requestText = requesttxt[0].pageContent.toString()


  var inputMessage = `for the request ${requestText} and response ${responseText}, generate a playwright api automation inclduing headers and response validation by taking data from excel sheet for both request and response`

  console.log("Prompt Message -->",inputMessage)
  var output = await withHistory.invoke({ input: inputMessage }, config);
  console.log("Data from AI --> \n",output.content.toString())
  
  var outputFilePath = path.join(__dirname, "data", "output", "API", "Code","playwright.txt")
      if (output.content.toString().length > 0) {
        const fileWriteResult = await writeToHtmlFile(outputFilePath, output.content.toString());
      }
}
chat();
