import { test } from '@playwright/test';
import { BlueIAVPage } from '../data/output/pageObject/riskIntakePage.steps';
test('test', async ({ page }) => {
    const loginPage = new BlueIAVPage(page);
    await page.goto('https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue');
    await loginPage.createNewApplication();
});

