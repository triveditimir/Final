import { test, expect } from '@playwright/test';
import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage.steps';
import { FileDownload } from '../data/output/Utils/fileDownload'
import { MongoDBClient } from '../data/output/Utils/mongo';
import * as dotenv from 'dotenv';
import { claimsMarketInsight } from '../data/output/pageObject/claimsMarketInsightPage';

test('ClaimsMarketInsight', async ({ page }) => {
  const linqLoginPage = new BlueIAviationInsightsPage(page);
  const claimsMarketPage = new claimsMarketInsight(page);
  const downloadFile = new FileDownload(page);
  await page.goto('https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue');
  await linqLoginPage.loginAsColleague();
  await claimsMarketPage.navigateToMarketInsights();
  await claimsMarketPage.verifyMarketDashboardReports();
  await claimsMarketPage.openClaimsAndVerifyFilters();
  await claimsMarketPage.validateClaimsSummaryboard();
  await claimsMarketPage.validatefilterChips();
  await claimsMarketPage.clickClaimCountAndVerify();
  await downloadFile.downloadAndSavePDF();

  /**
   * Compares pie chart data with table data for No. of Claims
   * Logs and asserts that pie chart counts approximate table counts.
   */

  const pieChartClaimsCountData = await claimsMarketPage.getPieChartLegendData();
  const numberOfClaimsCountTableData = await claimsMarketPage.getNumberOfClaimsTableData("Number of Claims");
  console.log('pieChartClaimsCountData', pieChartClaimsCountData)
  console.log('numberOfClaimsCountTableData', numberOfClaimsCountTableData)
  const result1 = claimsMarketPage.validateLegendPercentages(pieChartClaimsCountData, numberOfClaimsCountTableData)
  expect(result1).toBeTruthy()
  /**
     * Compares pie chart data with table data for Incurred Total
     * Logs and asserts that pie chart counts approximate table counts.
 */
  await page.locator("//button[normalize-space()='Claim Incurred']").click();
  const pieChartClaimIncurredData = await claimsMarketPage.getPieChartLegendData();
  const claimIncurredTableData = await claimsMarketPage.getNumberOfClaimsTableData("Incurred Total");
  console.log('pieChartClaimIncurredData', pieChartClaimIncurredData)
  console.log('claimIncurredTableData', claimIncurredTableData)
  const result2 = claimsMarketPage.validateLegendPercentages(pieChartClaimIncurredData, claimIncurredTableData)
  expect(result2).toBeTruthy()


  /**
     * Verify user is able to see the screen elements for "Occurrence Count Triangle","Incurred Loss Triangle"
     * and "Claim Summary by Policy Year"
 */
  const occuranceCountTriangle = await page.locator("//span[normalize-space()='Occurrence Count Triangle']")
  await claimsMarketPage.validateSummaryViewTableData(occuranceCountTriangle)
  const incurredLossTriangle = await page.locator("//span[normalize-space()='Incurred Loss Triangle']")
  await claimsMarketPage.validateSummaryViewTableData(incurredLossTriangle)
  const claimsSummaryByPolicyYear = await page.locator("//span[normalize-space()='Claim Summary by Policy Year']")
  await claimsMarketPage.validateSummaryViewTableData(claimsSummaryByPolicyYear)

});


