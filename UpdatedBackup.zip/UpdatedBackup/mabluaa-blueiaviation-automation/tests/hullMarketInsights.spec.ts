import { test, expect } from '@playwright/test';
import { marketInsightsPage } from '../data/output/pageObject/marketInsightsPage.steps';
import { LoginPage } from '../data/output/pageObject/aviationOverviewPage.steps';
import { FileDownload } from '../data/output/Utils/fileDownload';
import { FormatNumber } from '../data/output/Utils/numericConversion';
import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage.steps';
import * as dotenv from 'dotenv';
import * as fs from 'fs';

// logger instance
const log = console; // logger instance
// Loading environment variables from .env file
dotenv.config();

const BASE_URL = process.env.BASE_URL;

if (!BASE_URL) {
  throw new Error('BASE_URL is not defined in environment variables');
}


test('Vefiry Hull Market Insights', async ({ page }) => {

  const insightsPage = new marketInsightsPage(page);
  const loginPage = new LoginPage(page);
  const fileDownload = new FileDownload(page);
  const blueInsightPage = new BlueIAviationInsightsPage(page);


  log.info('Navigate to login page');
  await page.goto(`${BASE_URL}/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue`);

  log.info('Perform login');
  await loginPage.clickColleagueLogin();

  log.info('Validate footer elements');
  await loginPage.validateAviationOverviewFooters();

  log.info('Navigate to Insights');
  await blueInsightPage.navigateToInsights();

  log.info('Navigate to Market Insights');
  await blueInsightPage.navigateToMarketInsights();

  log.info('Verify Hull tab elements');
  await insightsPage.seeAvailableElementsonHullTab();


  log.info('Validate slider filter');
  await insightsPage.validateSliderHullValueFilter(600000);
  await page.waitForTimeout(5000);

  // Download charts PDF and PNG
  log.info('Download Chart Year over year change Hull Rate PDF AND PNG');
  await insightsPage.downloadChartPDF('chart1');
  await insightsPage.downloadChartPNG('chart1');

  // Get buttons and log
  log.info('Get ButtonAnnualHullRateTrend element');
  const ButtonAnnualHullRateTrend = await insightsPage.getButtonAnnualHullRateTrend();

  log.info('Get ButtonAverageHullRate element');
  const ButtonAverageHullRate = await insightsPage.getButtonAverageHullRate();

  if (ButtonAnnualHullRateTrend) {
    log.info('Click ButtonAnnualHullRateTrend');
    await ButtonAnnualHullRateTrend.click();
  } else {
    log.error('ButtonAnnualHullRateTrend not found');
    throw new Error('Button not found');
  }

  log.info('Download Annual Hull Rate Trand PDF AND PNG');
  await insightsPage.downloadChartPDF('chart2');
  await insightsPage.downloadChartPNG('chart2');

  if (ButtonAverageHullRate) {
    log.info('Click ButtonAverageHullRate');
    await ButtonAverageHullRate.click();
  } else {
    log.error('ButtonAverageHullRate not found');
    throw new Error('Button not found');
  }
  log.info('Download Average Hull Rate PDF AND PNG');

  await insightsPage.downloadChartPDF('chart2');
  await insightsPage.downloadChartPNG('chart2');
  // Final log
  log.info('Test completed successfully');
});