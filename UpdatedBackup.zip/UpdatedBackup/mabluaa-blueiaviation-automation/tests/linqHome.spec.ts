import { test } from '@playwright/test';
import { LinqPage } from '../data/output/pageObject/linQHomePage.steps';
import { BlueIAviationPage } from '../data/output/pageObject/marketInsightsPage.steps';
test('test', async ({ page }) => {
    const linqHomePage = new LinqPage(page);
    const BlueIAV = new BlueIAviationPage(page);
    await page.goto('https://staging2.linqbymarsh.com/linq/home');
    await BlueIAV.clickonloginAsColleague();
    await page.waitForTimeout(2000);
    await linqHomePage.navigateToHomePageAndVerify();
    await linqHomePage.clickLogo();
    await linqHomePage.clickAviationInsights();
})