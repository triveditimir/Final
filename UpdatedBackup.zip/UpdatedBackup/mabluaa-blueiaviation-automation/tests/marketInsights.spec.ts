// mongodb.spec.ts
import { test, expect } from '@playwright/test';
import { marketInsightsPage } from '../data/output/pageObject/marketInsightsPage.steps';
import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage.steps';
import { LoginPage } from '../data/output/pageObject/aviationOverviewPage.steps';

import { MongoDBClient } from '../data/output/Utils/mongo';
import * as dotenv from 'dotenv';
// Load environment variables from .env file
dotenv.config();

//import { MongoDBClient } from 'mongodb';
test('Compare UI data with MongoDB data', async ({ page }) => {

const uri=process.env.mongodb_uri;
 // const uri = 'mongodb://U1352559_app:%2B9FnzU9J*AYb%23ti@ip-10-237-90-22.ec2.internal:27012/?authSource=%24external&authMechanism=PLAIN&MaxPoolSize=200&socketTimeoutMS=300000&connectTimeoutMS=300000&w=majority&wtimeoutMS=300000&readConcernLevel=majority&replicaSet=rs_nam_aws_stg02&tls=true&tlsCAFile=C%3A%5CUsers%5CU1352559%5COneDrive+-+MMC%5CDocuments%5CMDB%5CCAroot.pem';
  const db = 'BlueiAviation';
console.log(uri);
  const client = new MongoDBClient(db);
  await client.connect();
   console.log("DB is Connected");

  //const db = client.('BlueiAviation');
  const mongoData = await client.getOne('aviation_hull_data_demo',{market: 'Starr'});
  //const mongoData = await collection.findOne({ maxHullValue: 4500000 });
 console.log(mongoData);
 console.log(mongoData?.market);
   const loginPage = new LoginPage(page);
 
  const blueInsightPage = new BlueIAviationInsightsPage(page);
//await page.goto('https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue');
  await loginPage.clickColleagueLogin();
await page.waitForTimeout(15000); // Wait for 2 seconds
  await blueInsightPage.navigateToInsights();
//await page.waitForTimeout(1500); // Wait for 2 seconds
  await blueInsightPage.navigateToMarketInsights();
//await page.waitForTimeout(1500); // Wait for 2 seconds
await blueInsightPage.navigateToHullGraph();
await page.waitForTimeout(1500); // Wait for 2 seconds

const textLocator=  page.locator("//div[@id='yearChangeHullRate']//div//*[name()='svg']//*[name()='g']//*[name()='g']//*[name()='g' and contains(@role,'region')]//*[name()='g' and contains(@transform,'translate(')]//*[name()='g']//*[name()='g']//*[name()='g' and contains(@role,'group')]//*[name()='g']//*[name()='g' and contains(@role,'switch')]//*[name()='g' and contains(@transform,'translate(')]//*[name()='g' and contains(@fill,'#000000')]//*[name()='text']//*[name()='tspan' and text()='Starr']");
const text = await textLocator.textContent();
console.log('Text content:', text);

//   const uiText = await myPage.getOnlyText();

expect(mongoData).not.toBeNull();
expect(text).toBe(mongoData?.market); // Adjust the comparison as needed
console.log('Comparison successful:', text === mongoData?.market);
client.close();
});