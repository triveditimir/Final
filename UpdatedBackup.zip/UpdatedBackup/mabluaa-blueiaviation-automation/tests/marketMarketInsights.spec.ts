import { test, expect } from '@playwright/test';
import { marketInsightsPage } from '../data/output/pageObject/marketInsightsPage.steps';
import { LoginPage } from '../data/output/pageObject/aviationOverviewPage.steps';
import { FileDownload } from '../data/output/Utils/fileDownload';
import { FormatNumber } from '../data/output/Utils/numericConversion';
import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage.steps';
import * as dotenv from 'dotenv';
import * as fs from 'fs';
// logger instance
const log = console; // logger instance
// Loading environment variables from .env file
dotenv.config();

const BASE_URL = process.env.BASE_URL;


if (!BASE_URL) {
  throw new Error('BASE_URL is not defined in environment variables');
}

test('Vefiry Market tab on Market Insights', async ({ page }) => {
  log.info('Starting test: Verify Market tab on Market Insights');

  const aviationLoginPage = new LoginPage(page);
  const insightsPage = new marketInsightsPage(page);
  const loginPage = new LoginPage(page);
  const fileDownload = new FileDownload(page);
  const blueInsightPage = new BlueIAviationInsightsPage(page);

  log.info('Navigating to login URL');
  await page.goto(`${BASE_URL}/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue`);
  log.info('Clicking on Colleague Login');
  await loginPage.clickColleagueLogin();
  log.info('Validating Aviation Overview Footers');
  await aviationLoginPage.validateAviationOverviewFooters();
  log.info('Navigating to Insights');
  await blueInsightPage.navigateToInsights();
  log.info('Navigating to Market Insights');
  await blueInsightPage.navigateToMarketInsights();
  log.info('Checking available elements on Market tab');
  await insightsPage.seeAvailableElementsonMarketTab();

  // Get buttons
  const ButtonMarketverageCommissionLevelTaret = await insightsPage.getButtonMarketverageCommissionLevelTaret();
  const ButtongetbuttonMarketBusinessBreakdown = await insightsPage.getbuttonMarketBusinessBreakdown();
  const ButtonMarketDistributionbyPremium = await insightsPage.getButtonMarketDistributtonbyPremium();
  // Download charts
  log.info('Downloading Chart Lost Business By Market as PDF and PNG');

  await insightsPage.downloadChartPDF('chart3');
  await insightsPage.downloadChartPNG('chart3');

  // Button click: MarketverageCommissionLevelTarget

  if (ButtonMarketverageCommissionLevelTaret) {
    log.info('Clicking ButtonMarketverageCommissionLevelTaret');
    await ButtonMarketverageCommissionLevelTaret.click();
  } else {
    log.error('ButtonMarketverageCommissionLevelTaret not found');
    throw new Error('Button not found');
  }

  // Download after clicking
  log.info('Downloading Chart Average Commission Level Against Taret as PDF and PNG after button click');

  await insightsPage.downloadChartPDF('chart3');
  await insightsPage.downloadChartPNG('chart3');

  // Button click: MarketBusinessBreakdown

  if (ButtongetbuttonMarketBusinessBreakdown) {
    log.info('Clicking ButtonMarketBusinessBreakdown');
    await ButtongetbuttonMarketBusinessBreakdown.click();
  } else {
    log.error('ButtonMarketBusinessBreakdown not found');
    throw new Error('Button not found');
  }

  // Download after clicking
  log.info('Downloading Chart Market Business Breakdown as PDF and PNG');

  await insightsPage.downloadChartPDF('chart4');
  await insightsPage.downloadChartPNG('chart4');

  // Button click: MarketDistributionbyPremium
  if (ButtonMarketDistributionbyPremium) {
    log.info('Clicking ButtonMarketDistributionbyPremium');
    await ButtonMarketDistributionbyPremium.click();
  } else {
    log.error('ButtonMarketDistributionbyPremium not found');
    throw new Error('Button not found');
  }

  log.info('Final download of Chart Market Distribution By Premium as PDF and PNG');
  await insightsPage.downloadChartPDF('chart4');
  await insightsPage.downloadChartPNG('chart4');

  log.info('Test completed successfully');

});



