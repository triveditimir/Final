import { test, expect } from '@playwright/test';
import { marketInsightsPage } from '../data/output/pageObject/marketInsightsPage.steps';
import { LoginPage } from '../data/output/pageObject/aviationOverviewPage.steps';
import { FileDownload } from '../data/output/Utils/fileDownload';
import { FormatNumber } from '../data/output/Utils/numericConversion';
import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage.steps';
import * as dotenv from 'dotenv';
import * as fs from 'fs';

// logger instance
const log = console; // logger instance
// Loading environment variables from .env file
dotenv.config();

const BASE_URL = process.env.BASE_URL;

if (!BASE_URL) {
  throw new Error('BASE_URL is not defined in environment variables');
}

test('Vefiry Underwriter tab on Market Insights', async ({ page }) => {
  // Instantiate page objects
  const insightsPage = new marketInsightsPage(page);
  const loginPage = new LoginPage(page);
  const fileDownload = new FileDownload(page);
  const blueInsightPage = new BlueIAviationInsightsPage(page);
  const aviationLoginPage = new LoginPage(page);

  // Navigate to login URL

  await page.goto(`${BASE_URL}/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue`);
  log.info('Navigated to login page');

  // Perform login
  log.info('Clicking on Colleague Login');
  await loginPage.clickColleagueLogin();
  log.info('Validating Aviation Overview Footers');
  await aviationLoginPage.validateAviationOverviewFooters();
  // Navigate to Insights
  await blueInsightPage.navigateToInsights();
  await blueInsightPage.navigateToMarketInsights();
  log.info('Navigated to Market Insights');

  // Check available elements on Underwriter tab

  await insightsPage.seeAvailableElementsonUnderwriterTab();

  // Retrieve button elements
  const ButtonLiabilityPremium = await insightsPage.getButtonLiabilityPremium();
  const ButtonLiabilityPremiumSecondary = await insightsPage.getButtonLiabilityPremiumSecondary();
  // Download Hull Rate charts (PDF & PNG)

  await insightsPage.downloadChartPDF('chart5');
  await insightsPage.downloadChartPNG('chart5');

  // Download Hull Rate Average (PDF & PNG)
  await insightsPage.downloadChartPDF('chart6');
  await insightsPage.downloadChartPNG('chart6');

  // Interact with Liability Premium button 
  if (ButtonLiabilityPremium) {
    log.info('Clicking on Liability Premium Button');
    await ButtonLiabilityPremium.click();
  } else {
    log.error('ButtonAnnualHullRateTrend not found');
    throw new Error('Button not found');
  }

  // Download Liability Premium Average (PDF & PNG)


  await insightsPage.downloadChartPDF('chart5');
  await insightsPage.downloadChartPNG('chart5');

  // Interact with Liability Premium button 

  // Download Liability Premium Average (PDF & PNG)

  if (ButtonLiabilityPremiumSecondary) {
    log.info('Click ButtonAnnualHullRateTrend');
    await ButtonLiabilityPremiumSecondary.click();
  } else {
    log.error('ButtonAnnualHullRateTrend not found');
    throw new Error('Button not found');
  }
  await insightsPage.downloadChartPDF('chart6');
  await insightsPage.downloadChartPNG('chart6');
});