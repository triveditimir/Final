import { test } from '@playwright/test';
import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage.steps';
import { FormatNumber } from '../data/output/Utils/numericConversion';
import * as fs from 'fs';

import { LoginPage } from '../data/output/pageObject/aviationOverviewPage.steps';
/* This TC will validate the Aviation Overview Page and Insight Page */
import { FileDownload } from '../data/output/Utils/fileDownload'
test('test', async ({ page }) => {
  const linqLoginPage = new BlueIAviationInsightsPage(page);
    const aviationLoginPage = new LoginPage(page);
    //const downloadFile = new fileDownload(page);
    await page.goto('https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue');

    await linqLoginPage.loginAsColleague();
    await linqLoginPage.validateOverviewPage();
    await aviationLoginPage.navigateToOverview();
    await aviationLoginPage.validateAviationOverviewFooters();
    await linqLoginPage.navigateToInsights();
    await linqLoginPage.interactWithChart();
    //await linqLoginPage.navigateToPlacementInsights();


    //await downloadFile.downloadPDFNew();

})