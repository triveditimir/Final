// mongo-utils.ts
import { MongoClient, Db, Collection, Document } from 'mongodb';
import * as dotenv from 'dotenv';
// Imported winston for sophisticated logging
import winston from 'winston';

// Configure winston logger
const log = winston.createLogger({
  level: 'info', // Change to 'debug' or 'error' as needed
  format: winston.format.combine(
    winston.format.colorize(),
    winston.format.timestamp({ format: 'DD-MM-YYYY HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message }) => `[${timestamp}] ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.Console(),
  ],
});

dotenv.config();

export class MongoDBClient {
  private client: MongoClient;
  private db!: Db; // Will be initialized after connect
  private readonly dbName: string;

  constructor(dbName: string) {
    this.dbName = dbName;

    const uri = process.env.MONGODB_URI; // Use consistent naming
    if (!uri) {
      log.error('MongoDB URI is not defined in environment variables.');
      throw new Error('MongoDB URI is not defined in environment variables.');
    }
    this.client = new MongoClient(uri);
    log.info(`MongoDBClient initialized for database: ${this.dbName}`);
  }

  /**
   * Connects to MongoDB and initializes the database instance.
   */
  async connect(): Promise<void> {
    try {
      log.info('Attempting to connect to MongoDB...');
      await this.client.connect();
      this.db = this.client.db(this.dbName);
      log.info(`Successfully connected to MongoDB database: ${this.dbName}`);
    } catch (error) {
      log.error('Failed to connect to MongoDB', error);
      throw error; // Rethrow to allow caller to handle
    }
  }

  /**
   * Retrieves a single document matching the query.
   * @param collectionName - Name of the collection.
   * @param query - Filter query object.
   * @returns Document or null.
   */
  async getOne<T extends Document>(collectionName: string, query: object): Promise<T | null> {
    try {
      const collection: Collection<T> = this.db.collection(collectionName);
      log.info(`Fetching one document from collection: ${collectionName} with query: ${JSON.stringify(query)}`);
      const result = await collection.findOne<T>(query);
      if (result) {
        log.info(`Document found: ${JSON.stringify(result)}`);
      } else {
        log.warn(`No document found for query: ${JSON.stringify(query)}`);
      }
      return result;
    } catch (error) {
      log.error(`Error fetching document from collection: ${collectionName}`, error);
      throw error;
    }
  }

  /**
   * Retrieves multiple documents matching the query.
   * @param collectionName - Name of the collection.
   * @param query - Filter query object.
   * @returns Array of documents.
   */
  async getMany<T extends Document>(collectionName: string, query: object): Promise<T[]> {
    try {
      const collection: Collection<T> = this.db.collection(collectionName);
      log.info(`Fetching multiple documents from collection: ${collectionName} with query: ${JSON.stringify(query)}`);
      const results = await collection.find<T>(query).toArray();
      log.info(`Number of documents retrieved: ${results.length}`);
      return results;
    } catch (error) {
      log.error(`Error fetching documents from collection: ${collectionName}`, error);
      throw error;
    }
  }

  /**
   * Closes the MongoDB connection.
   */
  async close(): Promise<void> {
    try {
      await this.client.close();
      log.info('MongoDB connection closed.');
    } catch (error) {
      log.error('Error closing MongoDB connection', error);
      throw error;
    }
  }
}
