import { Page, Locator, expect, Download } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import pdfParse from 'pdf-parse';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { pathToFileURL } from 'url';
import { PDFDocument, PDFDict, PDFStream, PDFName } from 'pdf-lib';
import sharp from 'sharp';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';
import * as zlib from 'zlib';

// Imported winston for sophisticated logging
import winston from 'winston';

// Configure winston logger
const logger = winston.createLogger({
  level: 'info', // Change to 'debug' or 'error' as needed
  format: winston.format.combine(
    winston.format.colorize(),
    winston.format.timestamp({ format: 'DD-MM-YYYY HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message }) => `[${timestamp}] ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.Console(),
  ],
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configurable download folder path
const DEFAULT_DOWNLOAD_FOLDER = path.resolve('C:/Users/U1352559/Project/AviationAutomation/mabluaa-blueiaviation-automation/data/output/documents');

/**
 * BasePage class: Provides common page functionalities.
 * Purpose: To encapsulate shared methods like waitForVisible.
 * Arguments:
 *  - page (Page): Playwright page object.
 * Returns: None.
 */
abstract class BasePage {
  protected readonly page: Page;

  constructor(page: Page) {
    console.info('Initializing BasePage');
    this.page = page;
  }

  /**
   * Waits for an element to be visible.
   * Purpose: To ensure element is ready for interaction.
   * Arguments:
   *  - locator (Locator): The element to wait for.
   *  - timeout (number): Optional timeout in ms (default 50000).
   * Returns: Promise<void>
   */
  protected async waitForVisible(locator: Locator, timeout = 50000): Promise<void> {
    console.info(`Waiting for element to be visible with timeout ${timeout}ms`);
    await expect(locator).toBeVisible({ timeout });
  }

  /**
   * Static utility to get a Locator by XPath.
   * Purpose: To create a Locator dynamically.
   * Arguments:
   *  - page (Page): Playwright page object.
   *  - uiSelector (string): XPath selector string.
   * Returns: Locator
   */
  static getButtonByXPath(page: Page, uiSelector: string): Locator {
    console.info(`Getting locator by XPath: ${uiSelector}`);
    return page.locator(`xpath=${uiSelector}`);
  }
}

/**
 * FileDownload class: Handles file download operations.
 * Purpose: To facilitate downloading, saving, and processing files.
 * Arguments:
 *  - page (Page): Playwright page object.
 * Returns: None.
 */
export class FileDownload extends BasePage {
  static downloadFolder = DEFAULT_DOWNLOAD_FOLDER;

  constructor(page: Page) {
    super(page);
    console.info('Initializing FileDownload');
    // Ensure download folder exists once during instantiation
    FileDownload.ensureDownloadFolder();
  }

  /**
   * Ensures the download folder exists.
   * Purpose: To create the folder if it doesn't exist.
   * Arguments: None.
   * Returns: void.
   */
  static ensureDownloadFolder() {
    if (!fs.existsSync(this.downloadFolder)) {
      console.info(`Creating download folder at ${this.downloadFolder}`);
      fs.mkdirSync(this.downloadFolder, { recursive: true });
    } else {
      console.info(`Download folder already exists at ${this.downloadFolder}`);
    }
  }

  /**
   * Saves a download to a specified path.
   * Purpose: To save the downloaded file to disk.
   * Arguments:
   *  - download (Download): Playwright Download object.
   *  - filename (string): Target filename.
   * Returns: Promise<string> - Path where file is saved.
   */
  private static async saveDownloadToFile(download: Download, filename: string): Promise<string> {
    this.ensureDownloadFolder();
    const savePath = path.join(this.downloadFolder, filename);
    console.info(`Saving download to: ${savePath}`);
    await download.saveAs(savePath);
    console.info(`File saved at ${savePath}`);
    return savePath;
  }

  /**
   * Clicks the download button.
   * Purpose: To trigger download via UI.
   * Arguments:
   *  - locator (Locator): Locator for the download button.
   * Returns: Promise<void>
   */
  async performDownloadClick(locator: Locator): Promise<void> {
    console.info('Waiting for download button to be visible');
    await expect(locator).toBeVisible({ timeout: 60000 });
    console.info('Waiting for download button to be enabled');
    await expect(locator).toBeEnabled({ timeout: 60000 });
    console.info('Clicking download button');
    await locator.click({ timeout: 60000 });
  }

  /**
   * Downloads a file and saves it with a timestamped filename.
   * Purpose: To automate file download and save.
   * Arguments:
   *  - page (Page): Playwright page object.
   *  - extension (string): File extension ('pdf', 'png', etc.).
   *  - prefix (string): Optional filename prefix.
   * Returns: Promise<string> - Path to saved file.
   */
  static async downloadAndSaveFile(page: Page, extension: string, prefix = 'AviationInsight'): Promise<string> {
    this.ensureDownloadFolder();
    console.info('Starting download process...');
    const [download] = await Promise.all([page.waitForEvent('download', { timeout: 190000 })]);
    console.info('Download event received.');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${prefix}__${timestamp}.${extension}`;
    return await this.saveDownloadToFile(download, filename);
  }

  /**
   * Downloads and saves a PDF file.
   * Purpose: To download a PDF report.
   * Arguments: None.
   * Returns: Promise<string> - Path to saved PDF.
   */
  async downloadAndSavePDF(): Promise<string> {
    console.info('Downloading and saving PDF...');
    return await FileDownload.downloadAndSaveFile(this.page, 'pdf', 'AviationAutomationPDFReport');
  }

  /**
   * Downloads and saves a PNG file.
   * Purpose: To download a PNG report.
   * Arguments: None.
   * Returns: Promise<string> - Path to saved PNG.
   */
  async downloadAndSavePNG(): Promise<string> {
    console.info('Downloading and saving PNG...');
    return await FileDownload.downloadAndSaveFile(this.page, 'png', 'AviationAutomationPNGReport');
  }

  /**
   * Gets the latest PDF file based on modification time.
   * Purpose: To retrieve the most recent PDF.
   * Arguments: None.
   * Returns: string | null - Path to latest PDF or null if none.
   */
  static getLatestFile(): string | null {
    if (!fs.existsSync(this.downloadFolder)) {
      console.warn(`Download folder does not exist: ${this.downloadFolder}`);
      return null;
    }
    const files = fs.readdirSync(this.downloadFolder)
      .filter(file => file.endsWith('.pdf'))
      .map(file => ({
        file,
        time: fs.statSync(path.join(this.downloadFolder, file)).mtime.getTime(),
      }))
      .sort((a, b) => b.time - a.time);
    if (files.length > 0) {
      const latestFile = path.join(this.downloadFolder, files[0].file);
      console.info(`Latest PDF file: ${latestFile}`);
      return latestFile;
    } else {
      console.warn('No PDF files found in download folder.');
      return null;
    }
  }

  /**
   * Extracts text from a PDF file.
   * Purpose: To parse and retrieve specific text.
   * Arguments:
   *  - filePath (string): Path to the PDF.
   * Returns: Promise<string | null> - Extracted text or null if not found/error.
   */
  static async extractTextFromPDF(filePath: string): Promise<string | null> {
    try {
      console.info(`Extracting text from PDF: ${filePath}`);
      const dataBuffer = fs.readFileSync(filePath);
      const data = await pdfParse(dataBuffer);
      const fullText = data.text;
      const regex = /Generated on:\s*\d{2}\/\d{2}\/\d{4}/;
      const match = fullText.match(regex);
      if (match) {
        console.info(`Found generated date: ${match[0]}`);
        return match[0];
      } else {
        console.warn('Generated on date not found in PDF.');
        return null;
      }
    } catch (error) {
      console.error('Error extracting text from PDF:', error);
      return null;
    }
  }

  /**
   * Extracts the second image embedded in the PDF.
   * Purpose: To retrieve a specific image from PDF.
   * Arguments:
   *  - filePath (string): Path to the PDF.
   * Returns: Promise<Buffer | null> - Image buffer or null if not found/error.
   */
  static async extractSecondImageFromPDF(filePath: string): Promise<Buffer | null> {
    try {
      console.info(`Extracting second image from PDF: ${filePath}`);
      const pdfBytes = fs.readFileSync(filePath);
      const pdfDoc = await PDFDocument.load(pdfBytes);
      let imageCount = 0;

      for (const page of pdfDoc.getPages()) {
        const resources = page.node.Resources();
        if (!resources) continue;

        const xObjectRef = resources.get(PDFName.of('XObject'));
        if (!xObjectRef) continue;

        const xObjectDict = xObjectRef instanceof PDFDict ? xObjectRef : null;
        if (!xObjectDict) continue;

        for (const [key, value] of xObjectDict.entries()) {
          if (value instanceof PDFStream) {
            const subtype = value.dict.get(PDFName.of('Subtype'));
            if (subtype instanceof PDFName && subtype.decodeText() === 'Image') {
              imageCount += 1;
              if (imageCount === 2) {
                const imageBuffer = FileDownload.getImageBufferFromStream(value);
                // Save for debugging
                fs.writeFileSync('extracted_second_image.png', imageBuffer);
                console.info('Extracted second image from PDF.');
                return imageBuffer;
              }
            }
          }
        }
      }
      console.warn('Did not find second image in PDF.');
      return null;
    } catch (error) {
      console.error('Error extracting second image from PDF:', error);
      return null;
    }
  }

  /**
   * Helper to get image buffer from a PDFStream, handling filters.
   * Purpose: To decode image data from PDF stream.
   * Arguments:
   *  - stream (PDFStream): PDFStream object.
   * Returns: Buffer of image data.
   */
  static getImageBufferFromStream(stream: PDFStream): Buffer {
    const { dict } = stream;
    const filter = dict.get(PDFName.of('Filter'));
    const decodeParms = dict.get(PDFName.of('DecodeParms'));
    let bytes = stream.getContents();

    if (!bytes) {
      console.error('Stream contents are empty.');
      return Buffer.alloc(0);
    }

    // Handle filters
    if (filter) {
      if (filter instanceof PDFName) {
        const filterName = filter.decodeText();
        if (filterName === 'DCTDecode') {
          return Buffer.from(bytes);
        } else if (filterName === 'FlateDecode') {
          return zlib.unzipSync(Buffer.from(bytes));
        } else if (filterName === 'JXDecode') {
          return Buffer.from(bytes);
        } else {
          console.warn(`Unknown filter: ${filterName}`);
          return Buffer.from(bytes);
        }
      } else if (filter instanceof Array) {
        for (const f of filter) {
          if (f instanceof PDFName) {
            const filterName = f.decodeText();
            if (filterName === 'DCTDecode') {
              return Buffer.from(bytes);
            } else if (filterName === 'FlateDecode') {
              bytes = zlib.unzipSync(Buffer.from(bytes));
            } else if (filterName === 'JXDecode') {
              return Buffer.from(bytes);
            } else {
              console.warn(`Unknown filter in array: ${filterName}`);
            }
          }
        }
        return Buffer.from(bytes);
      }
    }
    return Buffer.from(bytes);
  }

  /**
   * Resize image buffer to specified width and height.
   * Purpose: To resize images.
   * Arguments:
   *  - imageBuffer (Buffer): Original image buffer.
   *  - width (number): Target width.
   *  - height (number): Target height.
   * Returns: Promise<Buffer> - Resized image buffer.
   */
  static async resizeImage(imageBuffer: Buffer, width: number, height: number): Promise<Buffer> {
    if (!imageBuffer || imageBuffer.length === 0) {
      throw new Error('Image buffer is empty or invalid.');
    }
    try {
      console.info(`Resizing image to ${width}x${height}`);
      return await sharp(imageBuffer).resize(width, height).toBuffer();
    } catch (err) {
      console.error('Error resizing image:', err);
      throw err;
    }
  }

  /**
   * Compares two images and returns the number of different pixels.
   * Purpose: To perform visual comparison.
   * Arguments:
   *  - imgBuffer1 (Buffer): First image buffer.
   *  - imgBuffer2 (Buffer): Second image buffer.
   * Returns: number - Count of different pixels.
   */
  static compareImages(imgBuffer1: Buffer, imgBuffer2: Buffer): number {
    const PNG = require('pngjs').PNG;
    const pixelmatch = require('pixelmatch');

    const img1 = PNG.sync.read(imgBuffer1);
    const img2 = PNG.sync.read(imgBuffer2);

    if (img1.width !== img2.width || img1.height !== img2.height) {
      throw new Error('Images dimensions do not match for comparison.');
    }

    const { width, height } = img1;
    const diff = new PNG({ width, height });
    const numDiffPixels = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.1 });
    console.info(`Number of different pixels: ${numDiffPixels}`);
    return numDiffPixels;
  }

  /**
   * Main method to compare embedded PDF image with UI screenshot.
   * Purpose: To validate visual similarity.
   * Arguments:
   *  - filePath (string): Path to the PDF.
   *  - uiSelector (string): Selector for the UI element.
   *  - threshold (number): Max allowed pixel difference.
   */
  async comparePdfImageWithUIChart(filePath: string, uiSelector: string, threshold = 100): Promise<void> {
    console.info(`Comparing PDF image with UI chart: ${filePath}`);
    const imageBuffer = await FileDownload.extractSecondImageFromPDF(filePath);
    if (!imageBuffer || imageBuffer.length === 0) {
      console.error('Failed to extract image from PDF.');
      throw new Error('Failed to extract image from PDF.');
    }
    fs.writeFileSync('extracted_image.png', imageBuffer);
    console.info('Extracted image saved as extracted_image.png');

    const uiChartBuffer = await this.page.locator(uiSelector).screenshot();
    console.info('Captured UI screenshot.');

    const targetWidth = 800; // Can be made configurable
    const targetHeight = 600;

    const resizedPdfImage = await FileDownload.resizeImage(imageBuffer, targetWidth, targetHeight);
    const resizedUiImage = await FileDownload.resizeImage(uiChartBuffer, targetWidth, targetHeight);

    const diffPixels = FileDownload.compareImages(resizedPdfImage, resizedUiImage);
    console.info(`Difference pixels: ${diffPixels}`);
    expect(diffPixels).toBeLessThanOrEqual(threshold);
  }

  /**
   * Extracts all images embedded in the PDF.
   * Purpose: To retrieve all images.
   * Arguments:
   *  - filePath (string): Path to PDF.
   * Returns: Promise<Buffer[]> - Array of image buffers.
   */
  static async extractAllImagesFromPDF(filePath: string): Promise<Buffer[]> {
    const images: Buffer[] = [];
    try {
      console.info(`Extracting all images from PDF: ${filePath}`);
      const pdfBytes = fs.readFileSync(filePath);
      const pdfDoc = await PDFDocument.load(pdfBytes);

      for (const page of pdfDoc.getPages()) {
        const resources = page.node.Resources();
        if (!resources) continue;

        const xObjectRef = resources.get(PDFName.of('XObject'));
        if (!xObjectRef) continue;

        const xObjectDict = xObjectRef instanceof PDFDict ? xObjectRef : null;
        if (!xObjectDict) continue;

        for (const [key, value] of xObjectDict.entries()) {
          if (value instanceof PDFStream) {
            const subtype = value.dict.get(PDFName.of('Subtype'));
            if (subtype instanceof PDFName && subtype.decodeText() === 'Image') {
              const imageBuffer = FileDownload.getImageBufferFromStream(value);
              images.push(imageBuffer);
            }
          }
        }
      }
    } catch (error) {
      console.error('Error extracting images from PDF:', error);
    }
    return images;
  }

  /**
   * Opens the latest downloaded PDF in a new tab and captures screenshots of all pages.
   * Purpose: To visually verify PDF content.
   * Arguments: None.
   */
  async openLatestPDFCaptureScreenshot(): Promise<void> {
    const latestFilePath = FileDownload.getLatestFile();
    if (!latestFilePath) {
      console.error('No latest PDF file found.');
      throw new Error('No PDF file found to open.');
    }
    const fileUrl = pathToFileURL(latestFilePath).href;
    console.info(`Opening PDF at: ${fileUrl}`);

    // Open a new tab
    const newPage = await this.page.context().newPage();

    try {
      // Navigate to the PDF URL
      console.info('Navigating to PDF URL');
      await newPage.goto(fileUrl);
      await newPage.waitForLoadState('networkidle');

      // Wait for the PDF viewer to load
      console.info('Waiting for PDF viewer to load');
      await newPage.waitForTimeout(15000); // Wait for rendering

      // Get total pages
      const totalPages = await newPage.evaluate(() => {
        if (window['pdfViewer']) {
          return window['pdfViewer'].pdfDocument.numPages;
        }
        return 1; // fallback
      });
      console.info(`Total pages in PDF: ${totalPages}`);

      const screenshots: Buffer[] = [];
      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        // Scroll to page
        console.info(`Scrolling to page ${pageNum}`);
        await newPage.evaluate((page) => {
          if (window['pdfViewer']) {
            window['pdfViewer'].scrollPageIntoView({ pageNumber: page });
          }
        }, pageNum);

        // Wait for rendering
        console.info(`Waiting for page ${pageNum} to render`);
        await newPage.waitForTimeout(2000);

        // Take screenshot
        console.info(`Taking screenshot of page ${pageNum}`);
        const screenshotBuffer = await newPage.screenshot({ fullPage: true });
        const isBlank = await FileDownload.isImageBlank(screenshotBuffer);
        if (isBlank) {
          console.warn(`Page ${pageNum} is blank, skipping.`);
          continue;
        }
        screenshots.push(screenshotBuffer);
      }

      if (screenshots.length === 0) {
        console.warn('No non-blank pages captured.');
      } else {
        // Combine images vertically
        const imagesMetadata = await Promise.all(screenshots.map(buf => sharp(buf).metadata()));
        const totalHeight = imagesMetadata.reduce((sum, meta) => sum + meta.height, 0);
        const maxWidth = Math.max(...imagesMetadata.map(meta => meta.width));

        console.info('Creating combined image.');
        const compositeImage = sharp({
          create: {
            width: maxWidth,
            height: totalHeight,
            channels: 3,
            background: { r: 255, g: 255, b: 255 },
          },
        });

        // Composite images
        let topOffset = 0;
        for (let i = 0; i < screenshots.length; i++) {
          await compositeImage.composite([{ input: screenshots[i], top: topOffset, left: 0 }]);
          topOffset += imagesMetadata[i].height;
        }

        // Save combined image
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const savePath = path.join(FileDownload.downloadFolder, `AviationPDF_${timestamp}.png`);
        await compositeImage.toFile(savePath);
        console.info(`Combined screenshot saved at: ${savePath}`);
      }
    } catch (error) {
      console.error('Error capturing PDF pages:', error);
    } finally {
      // Close the new tab
      if (!newPage.isClosed()) {
        console.info('Closing the PDF tab');
        await newPage.close();
      }
    }

    // Optionally bring back the original page
    const hasFurtherTests = false; // Set true if more tests follow
    if (!hasFurtherTests) {
      if (!this.page.isClosed()) {
        console.info('Bringing original page to front');
        await this.page.bringToFront();
      }
    }
  }

  /**
   * Helper to check if an image is blank (all white).
   * Purpose: To identify blank pages.
   * Arguments:
   *  - buffer (Buffer): Image buffer.
   * Returns: Promise<boolean> - True if blank, false otherwise.
   */
  static async isImageBlank(buffer: Buffer): Promise<boolean> {
    const { data, info } = await sharp(buffer).raw().toBuffer({ resolveWithObject: true });
    console.info('Checking if image is blank.');
    for (let i = 0; i < data.length; i += info.channels) {
      if (
        data[i] !== 255 || // R
        data[i + 1] !== 255 || // G
        data[i + 2] !== 255 // B
      ) {
        console.info('Found non-white pixel.');
        return false; // Not blank
      }
    }
    console.info('Image is blank.');
    return true; // All white pixels
  }
}