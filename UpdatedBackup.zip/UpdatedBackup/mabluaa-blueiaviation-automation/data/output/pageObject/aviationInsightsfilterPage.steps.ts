
import { Page, Locator, expect } from '@playwright/test';
import { basePage } from './BasePage';

/**
 * Page Object class for the Blue IAviation page.
 */
export class BlueIAviationPage extends basePage {
    constructor(page: Page) {
        super(page);
    }

    // Element definitions
    private get colleagueLoginLink(): Locator {
        return this.page.locator("//span[normalize-space()='Colleague login']");
    }

    private get insightsButton(): Locator {
        return this.page.getByText('Insights', { exact: true });
    }



    private get globalHeader(): Locator {
        return this.page.locator('.logo-white-text');
    }
    private get menuHeader(): Locator {
        return this.page.locator('//div[@class="ext-menu"]//div');
    }


    private get section(): Locator {
        return this.page.locator('.card-body');
    }

    private get placementInsightsHeader(): Locator {
        return this.page.locator('text=PLACEMENT INSIGHTS');
    }

    private get placementInsightsButtonLink(): Locator {
        return this.page.locator("(//button[normalize-space()='PLACEMENT INSIGHTS'])[1]");
    }

    private get placementInsightsFilter(): Locator {
        return this.page.locator("//button[@class='filter-chip d-flex align-items-center flex-row justify-content-center outline-btn']");
    }

    private get getHullValuePriorChange(): Promise<string> {
        return this.page.locator("//div[@id='RSMMain']/div[3]/div[1]/ci-card-view[1]/div/div[2]").innerText();
    }

    private get selectPlanTypeUAS(): Locator {
        return this.page.locator("//input[@value='UAS']");
    }

    private delay(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    private get clickApplyfilter(): Locator {
        return this.page.locator("//button[@id='goBtn']");
    }

    private get getHullValuePostChange(): Promise<string> {
        return this.page.locator("//div[@id='RSMMain']/div[3]/div[1]/ci-card-view[1]/div/div[2]").innerText();
    }



    private get selectClient(): Locator {
        return this.page.locator("//input[@name='companyData']");
    }

    private get goClient(): Locator {

        return this.page.locator("//button[contains(text(), 'Go')]");
    }


    private get placementAnalyticsReports(): Locator {
        return this.page.locator('ci-placement-analytics-reports');
    }

    private get marketInsightsButton(): Locator {
        return this.page.getByRole('button', { name: 'MARKET INSIGHTS' });
    }
    private get marketInsightsButtonLink(): Locator {
        return this.page.locator("(//button[normalize-space()='MARKET INSIGHTS'])[1]");
    }

    private get marketDashboardReports(): Locator {
        return this.page.locator('ci-market-dashboard-reports');
    }

    private get chart1(): Locator {
        return this.page.locator('#chart1');
    }

    /**
     * Navigates to the login page and clicks on the colleague login link.
     */
    public async loginAsColleague(): Promise<void> {
        await this.page.goto('https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue');
        await this.waitForVisible(this.colleagueLoginLink);
        await this.colleagueLoginLink.click();

    }

    /**
     * Validates the presence of key texts in the global header and section.
     */
    public async validateOverviewPage(): Promise<void> {
        await this.waitForVisible(this.globalHeader);
        await expect(this.globalHeader).toContainText(['MY DATA & ANALYTICS'])
        await expect(this.menuHeader).toContainText(['LINQ HOME', 'Aviation Overview', 'INSIGHTS', 'RISK INTAKE']);
        await expect(this.section).toContainText(['Insights', 'Risk Intake']);
    }

    /**
     * Clicks on the Insights button and validates the placement insights.
     */
    public async navigateToInsights(): Promise<void> {
        await this.insightsButton.click();
        await this.selectClient.click();
        await this.goClient.click();
        await this.waitForVisible(this.placementInsightsHeader);
        await expect(this.placementInsightsHeader).toBeVisible();
        await expect(this.placementAnalyticsReports).toMatchAriaSnapshot(`- text: RSM Market Aircraft Client History UAS Claims`, { timeout: 10000 });
        //  await expect(this.placementAnalyticsReports).toContainText(['RSM', 'Market', 'Aircraft', 'Client History', 'UAS', 'Claims']);
    }

    public async navigateToPlacementInsights(): Promise<void> {
        await this.placementInsightsButtonLink.click();
        await this.placementInsightsFilter.click();
        const hullValuePriorChange = await this.getHullValuePriorChange;
        console.log("Hull value prior to change Plan Type is ", hullValuePriorChange);
        await this.selectPlanTypeUAS.click();
        await this.delay(500);
        await this.clickApplyfilter.click();
        await this.delay(500);
        const hullValuePostChange = await this.getHullValuePostChange;
        console.log("Hull value post to change Plan Type is", hullValuePostChange);
        if (hullValuePriorChange == hullValuePostChange) {
            console.log("Hull values are equal.");
        }
        else {
            console.log("Hull values are different.");
        }
    }

    /**
     * Interacts with the chart and validates its snapshot.
     */
    public async interactWithChart(): Promise<void> {
        await expect(this.chart1).toMatchAriaSnapshot(`- button "Net Hull Rate By Insured Value"`);
        await this.page.getByRole('button', { name: 'Net Hull Rate By Insured Value' }).click();
        await expect(this.chart1).toMatchAriaSnapshot(`- button "Net Liability Premium By Limit"`);
    }

    /**
     * Navigates to market insights and validates the market dashboard reports.
     */
    public async navigateToMarketInsights(): Promise<void> {
        await this.marketInsightsButtonLink.click();
        //await expect(this.marketDashboardReports).toMatchAriaSnapshot(`- text: Hull Liability Market Underwriter MACH Claims`);
        //await expect(this.marketDashboardReports).toContainText(['Hull', 'Liability', 'Market', 'Underwriter', 'MACH', 'Claims']);
    }

    /**
     * Initiates the download process for the PDF report.
     */

}
