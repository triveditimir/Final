import { Page, Locator, expect } from '@playwright/test';


import { basePage } from './BasePage';


/**
 * LoginPage class that represents the login and overview page.
 */
export class LoginPage extends basePage {
  private get colleagueLoginLink(): Locator {
    return this.page.locator("//span[normalize-space()='Colleague login']");
  }
  

  private get footer(): Locator {
    return this.page.locator('linq-global-footer');
  }

  private get contactUsDisclaimer(): Locator {
    return this.page.getByText('Contact Us Disclaimer: Any');
  }
  private get RSM(): Locator {
        return this.page.locator("//div[contains(text(),'RSM')]");
    }

  private get footerDisclaimer(): Locator {
    return this.footer.locator('div').filter({ hasText: 'Disclaimer: Any' }).nth(2);
  }

  public async navigateToLogin(): Promise<void> {
    await this.page.goto('https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue');
  }

  public async clickColleagueLogin(): Promise<void> {
    await this.waitForVisible(this.colleagueLoginLink);
    await this.colleagueLoginLink.click();
  }

  public async navigateToOverview(): Promise<void> {
    await this.page.goto('https://staging2.linqbymarsh.com/blueiaviation/overview?dl=true');
  }

  public async validateAviationOverviewFooters(): Promise<void> {
    await this.waitForVisible(this.footer);
    await this.waitForVisible(this.contactUsDisclaimer);
    await this.waitForVisible(this.footerDisclaimer);
    await this.footerDisclaimer.click();
  }

 
}
