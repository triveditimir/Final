
import { Page, Locator, expect } from '@playwright/test';
import { basePage } from './BasePage';


export class claimsMarketInsight extends basePage {
    constructor(page: Page) {
        super(page);
    }

    /**
     * Extracts the "Number of Claims" table data inside the div with id "claimCountIncurredChart"
     * and returns it as a JSON object with key-value pairs.
     * @returns Promise resolving to an object with keys as claim types and values as counts
     */
    public async getNumberOfClaimsTableData(labelToMatch: string): Promise<Record<string, number>> {
        const container = this.page.locator('#claimCountIncurredChart');
        const dynamicTables = container.locator('ci-dynamic-table');
        const count = await dynamicTables.count();
        for (let i = 0; i < count; i++) {
            const label = await dynamicTables.nth(i).locator('label.title').textContent();
            if (label?.trim() === labelToMatch) {
                const rows = dynamicTables.nth(i).locator('table tbody tr');
                const rowCount = await rows.count();
                const result: Record<string, number> = {};
                for (let j = 0; j < rowCount; j++) {
                    const key = (await rows.nth(j).locator('td').first().textContent())?.trim() || '';
                    const valueText = (await rows.nth(j).locator('td').nth(1).textContent())?.trim() || '0';
                    const value = Number(valueText.replace(/[$,]/g, '')) || 0;
                    if (key) {
                        result[key] = value;
                    }
                }
                return result;
            }
        }
        return {};
    }

    /**
     * Extracts the legend names and their corresponding values from the pie chart inside #claimCountIncurredChart.
     * Returns a JSON object with legend names as keys and their percentage values as numbers.
     */
    public async getPieChartLegendData(): Promise<Record<string, number>> {
        const container = this.page.locator('#claimCountIncurredChart');
        const legendGroup = container.locator('[aria-label="Legend"]');
        const legendItems = legendGroup.locator('tspan');
        const legendCount = await legendItems.count();
        const result: Record<string, number> = {};

        // Map legend names to their colors
        const legendNameToColor: Record<string, string> = {};
        for (let i = 0; i < legendCount; i++) {
            const legendName = (await legendItems.nth(i).textContent())?.trim() || '';
            // Find closest g tag with role switch
            const legendTspan = legendItems.nth(i);
            const switchG = await legendTspan.evaluateHandle((el) => {
                let parent = el.parentElement;
                while (parent && parent.getAttribute('role') !== 'switch') {
                    parent = parent.parentElement;
                }
                return parent;
            });
            if (switchG) {
                // Inside switchG find g tag with fill and stroke attributes and a child path element
                const colorG = await switchG.evaluateHandle((el) => {
                    const children = Array.from(el.querySelectorAll('g'));
                    for (const child of children) {
                        if (child.hasAttribute('fill') && child.hasAttribute('stroke') && child.querySelector('path')) {
                            return child;
                        }
                    }
                    return null;
                });
                if (colorG) {
                    const fill = await colorG.evaluate((el) => el.getAttribute('fill'));
                    if (fill) {
                        legendNameToColor[legendName] = fill;
                    }
                }
            }
        }

        // Get pie chart colors in order
        const seriesGroup = container.locator('g[aria-label="Series"][role="group"]');
        const pieSlices = seriesGroup.locator('g[role="menuitem"][fill]');
        const pieSliceCount = await pieSlices.count();
        const pieColors: string[] = [];
        for (let i = 0; i < pieSliceCount; i++) {
            const fill = await pieSlices.nth(i).getAttribute('fill');
            if (fill) {
                pieColors.push(fill);
            }
        }

        // Get all tspan text content inside g tags that have child text tags
        const textGroups = container.locator('g:has(text tspan)');
        const textGroupCount = await textGroups.count();
        const pieValues: string[] = [];
        for (let i = 0; i < textGroupCount; i++) {
            const tspan = textGroups.nth(i).locator('text tspan');
            const tspanCount = await tspan.count();
            for (let j = 0; j < tspanCount; j++) {
                const text = (await tspan.nth(j).textContent())?.trim() || '';
                if (text) {
                    pieValues.push(text);
                }
            }
        }

        // Create JSON mapping legend names to values based on order of pieColors and pieValues
        const legendNames = Object.keys(legendNameToColor);
        const resultJson: Record<string, number> = {};
        for (let i = 0; i < legendNames.length; i++) {
            const name = legendNames[i];
            const valueText = pieValues[i] || '0';
            const value = parseFloat(valueText.replace('%', '')) || 0;
            resultJson[name] = value;
        }

        return resultJson;
    }

    //  * Validates if the percentages in legendData are correctly calculated based on tableData.
    //  * Considers only keys present in legendData for calculation.
    //  * Rounds percentages to 1 decimal place for comparison.
    //  * @param legendData - Object with keys as legend names and values as percentage values
    //  * @param tableData - Object with keys as legend names and values as absolute counts
    //  * @returns true if all percentages match correctly, false otherwise
    //  */
    public validateLegendPercentages(legendData: Record<string, number>, tableData: Record<string, number>): boolean {
        // Calculate total of relevant keys in tableData (keys present in legendData)
        const relevantKeys = Object.keys(legendData);
        const total = relevantKeys.reduce((sum, key) => sum + (tableData[key] || 0), 0);

        // Check each key's percentage
        for (const key of relevantKeys) {
            const absoluteValue = tableData[key] || 0;

            const expectedPercentage = total === 0 ? 0 : (absoluteValue / total) * 100;
            const roundedExpected = Math.round(expectedPercentage * 10) / 10; // 1 decimal place
            const actual = legendData[key];
            if (roundedExpected !== actual) {
                return false;
            }
        }
        return true;
    }

    public get claimsMain(): Locator {
        return this.page.locator('#claimsMain');
    }

    public get claimCountIncurredChart(): Locator {
        return this.page.locator('#claimCountIncurredChart');
    }

    public filterChips(filterName: string): Locator {
        return this.page.locator(`//av-filter-chips//button[contains(text(), "${filterName}")]`);
    }

    public get occuranceCountTriangle(): Locator {
        return this.page.locator("//span[normalize-space()='Occurrence Count Triangle']");
    }

    private get insightsButton(): Locator {
        return this.page.getByRole('button', { name: 'INSIGHTS' });
    }

    private marketInsightsButton(): Locator {
        return this.page.locator('//button[contains(text(),"MARKET INSIGHTS")]');
    }

    private get marketDashboardReports(): Locator {
        return this.page.locator("//ci-market-dashboard-reports//div[contains(@class, 'market-dashboard-menu-container')]")
    }

    private claimsButton(): Locator {
        return this.page.locator('//div[contains(text(),"Claims")]');
    }

    private get filtersButton(): Locator {
        return this.page.locator('//av-filter-chips//button//span[text()="Filters"]');
    }

    private get collapseAllFilterButton(): Locator {
        return this.page.locator('//button[normalize-space()="Collapse All"]');
    }

    private get resetAllFilterButton(): Locator {
        return this.page.locator('//button[normalize-space()="Reset All"]');
    }

    private filterContainer(filterName: string): Locator {
        return this.page.locator(`//*[@id="filterContainer"]//span[text()="${filterName}"]/parent::div`);
    }

    private filterContainerwithValue(): Locator {
        return this.page.locator('input[type="checkbox"]:checked');
    }

    private get claimcards(): Locator {
        return this.page.locator('//*[@id="claimsMain"]//ci-card-view');
    }

    private get claimsSummaryView(): Locator {
        return this.page.locator('//*[@id="claimCountIncurredChart"]//ci-toggle-button');

    }

    private get analysisReport(): Locator {
        return this.page.locator('#analysisReport');
    }

    private get downloadPDFButton(): Locator {
        return this.page.getByText('Download as PDF');
    }

    /**
     * Clicks on the insights and market insights buttons.
     */
    public async navigateToMarketInsights(): Promise<void> {
        //Todo: Need to work around these timeouts, currently this is a workaround
        await this.insightsButton.click();
        await this.page.waitForTimeout(5000);
        const marketInsightBtn = await this.marketInsightsButton()
        await this.waitForVisible(marketInsightBtn);
        await marketInsightBtn.click();
        await this.page.waitForTimeout(5000);
        await this.page.locator('//button[contains(text(),"PLACEMENT INSIGHTS")]').click();
        await this.page.waitForTimeout(5000);
        await marketInsightBtn.click();
        await this.page.waitForTimeout(5000);
    }

    /**
     * Verifies the presence of expected dashboards in the market Insights screen.
     */
    public async verifyMarketDashboardReports(): Promise<void> {
        const expectedTexts = ['Hull', 'Liability', 'Market', 'Underwriter', 'MACH', 'Claims'];
        const element = await this.marketDashboardReports
        for (const text of expectedTexts) {
            await expect(element).toContainText(text);
            console.log("the expected value is as ", text)
        }

    }

    /**
     * Opens the claims section and verifies the filters.
     */
    public async openClaimsAndVerifyFilters(): Promise<void> {
        //await this.waitForVisible(this.claimsButton);
        await this.claimsButton().click();
        await this.filtersButton.click();
        await expect(this.collapseAllFilterButton).toBeVisible();
        await expect(this.resetAllFilterButton).toBeVisible();
        await this.verifyFilters();
    }

    /**
     * Verifies the filters types in the filter container.
     */

    private async verifyFilters(): Promise<void> {
        const policyTypeLocator = await this.filterContainer("Policy Type")
        //const policyTypeFilterValue = await this.filterContainerwithValue().textContent();
        const planeTypeLocator = await this.filterContainer("Plane Type")
        const lossPerilLocator = await this.filterContainer("Loss Peril")
        const claimTypeLocator = await this.filterContainer("Claim Type")
        const coverageTypeLocator = await this.filterContainer("Coverage Type")
        const marketLocator = await this.filterContainer("Market")
        const yearLocator = await this.filterContainer("Year")
        const crewLocator = await this.filterContainer("Crew")
        const businessTpyeLocator = await this.filterContainer("Business Type")
        const yearquarterLocator = await this.filterContainer("Year Quarter")
        const quotaShareLocator = await this.filterContainer("Quota Share")
        const hullValueLocator = await this.filterContainer("Hull Value")



        await this.waitForVisible(policyTypeLocator);
        await expect(policyTypeLocator).toMatchAriaSnapshot(`
            - text: Policy Type  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "Hull & Liability" [checked]
            - text: Hull & Liability
        `);

        await expect(planeTypeLocator).toMatchAriaSnapshot(`
            - text: Plane Type  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "Jet Engine" [checked]
            - text: Jet Engine
        `);

        await expect(lossPerilLocator).toMatchAriaSnapshot(`
            - text: Loss Peril  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "Personal Injury" [checked]
            - text: Personal Injury
            - checkbox "Pilot Error" [checked]
            - text: Pilot Error
            - checkbox "Weather Other" [checked]
            - text: Weather Other
        `);

        await expect(claimTypeLocator).toMatchAriaSnapshot(`
            - text: Claim Type  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "Liability  Bodily Injury or Fatality" [checked]
            - text: Liability  Bodily Injury or Fatality
            - checkbox "Physical DamageIM" [checked]
            - text: Physical DamageIM
        `);

        await expect(coverageTypeLocator).toMatchAriaSnapshot(`
            - text: Coverage Type  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "Hull" [checked]
            - text: Hull
            - checkbox "Passenger Liability" [checked]
            - text: Passenger Liability
        `);

        await expect(marketLocator).toMatchAriaSnapshot(`
            - text: Market  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "QBE" [checked]
            - text: QBE
            - checkbox "Starr" [checked]
            - text: Starr
        `);

        await expect(yearLocator).toMatchAriaSnapshot(`
            - text: Year  
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "2022" [checked]
            - text: "2022"
        `);
        await expect(crewLocator).toMatchAriaSnapshot(`
            - text: Crew  
            - checkbox "All" [checked]
            - text: All
            - checkbox "2+" [unchecked]
            - text: "2+"
        `);
        await expect(businessTpyeLocator).toMatchAriaSnapshot(`
            - text: Business Type          
            - textbox "Enter search term"
            - text: Clear All
            - checkbox "Commercial" [checked]
            - text: Commercial
            - checkbox "Industrial Aid" [checked]
            - text: Industrial Aid
        `);



    }

    /**
     * Clicks on the claim count and verifies the claims main section.
     */
    public async validateClaimsSummaryboard(): Promise<void> {
        await expect(this.claimsSummaryView).toMatchAriaSnapshot(`
            - button "Claim Count"
            - button "Claim Incurred"`)
        await expect(this.claimcards.first()).toContainText("TOTAL PREMIUM")
        await expect(this.claimcards.nth(1)).toContainText("TOTAL INCURRED")
        await expect(this.claimcards.nth(2)).toContainText("LOSS RATIO")

    }

    public async clickClaimCountAndVerify(): Promise<void> {
        await this.claimCountIncurredChart.locator('div').filter({ hasText: 'Claim Count Claim Incurred' }).nth(1).click();
        await this.claimsMain.waitFor();
        await expect(this.claimsMain).toMatchAriaSnapshot(`
            - button "Claim Count"
            - button "Claim Incurred"
            - group:
              - region "Chart":
                - group "Series":
                  - menuitem
                  - menuitem
                  - text: /\\d+\\.\\d+% \\d+\\.\\d+%/
                - group "Legend":
                  - switch "Open" [checked]
                  - switch "Closed" [checked]
            - text: Number of Claims
            - table:
              - rowgroup
              - rowgroup:
                - row "Open 4":
                  - cell "Open"
                  - cell "4"
                - row "Closed 2":
                  - cell "Closed"
                  - cell "2"
                - row "Total 6":
                  - cell "Total"
                  - cell "6"
            - text: Open Claims
            - table:
              - rowgroup
              - rowgroup:
                - row "Liability Bodily Injury or Fatality 2":
                  - cell "Liability Bodily Injury or Fatality"
                  - cell "2"
                - row "Physical DamageIM 2":
                  - cell "Physical DamageIM"
                  - cell "2"
        `);
    }

    /**
     * Downloads the report as a PDF.
     */
    public async downloadReportAsPDF(): Promise<void> {
        await this.claimCountIncurredChart.locator('img').click();
        await this.downloadPDFButton.click();
    }


    public async validatefilterChips(): Promise<void> {
        const checkedBoxes = this.page.locator('#filterContainer input[type="checkbox"]:checked');
        for (let i = 0; i < await checkedBoxes.count(); i++) {
            const label = await checkedBoxes.nth(i).evaluate(el =>
                el.closest('label')?.textContent?.trim()
            );

            const filterName = await checkedBoxes.nth(i).evaluate((el) => {
                const showPanel = el.closest('div[class*="show-panel"]');
                const parent = showPanel?.parentElement;
                const header = parent?.querySelector('[class*="filter-option-header"]');
                return header?.textContent?.trim() || null;
            });

            await this.filterChips(filterName).hover();
            const tooltipText = this.getTooltipText();
            expect(tooltipText).toContain(label?.trim());
        }
    }
    public async validateSummaryViewTableData(clickElement: Locator): Promise<void> {
        await clickElement.click();
        await this.page.locator('//ci-claims-customize-table//table[@role="table"]').isVisible();
        const hasContent = await this.page.locator('//ci-claims-customize-table//table//td').evaluateAll(cells =>
            cells.some(cell => cell.textContent?.trim())
        );
        expect(hasContent).toBe(true);
        await this.page.locator('//*[@id="claimSummaryByPolicyYearChart"]/div/ci-menu-card/div/img').isVisible();
    }
}
