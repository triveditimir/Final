
import { Page, Locator, expect } from '@playwright/test';
import { basePage } from './BasePage';


/**
 * Class representing the login and home page of the application.
 */
export class LinqPage extends basePage {
  /*private get colleagueLoginLink(): Locator {
    return this.page.locator('a[data-testid="colleague-login"]');
  } */

  private get homePageContainer(): Locator {
    return this.page.locator('app-linq-home');
  }

  private get logoContainer(): Locator {
    return this.page.locator('.site-header__logo-container');
  }

  private get aviationInsightsLink(): Locator {
    return this.page.getByText('Aviation Insights General').first();
  }

  /**
   * Navigates to the login page and clicks on the colleague login link.
   */
  /*public async navigateToColleagueLogin(): Promise<void> {
    await this.page.goto('https://staging2.linqbymarsh.com/linq/auth/login');
    await this.waitForVisible(this.colleagueLoginLink);
    await this.colleagueLoginLink.click();
  } */

  /**
   * Navigates to the home page and verifies the content.
   */
  public async navigateToHomePageAndVerify(): Promise<void> {
    //await this.page.goto('https://staging2.linqbymarsh.com/linq/home');
    await this.waitForVisible(this.homePageContainer);

    await expect(this.homePageContainer).toMatchAriaSnapshot(`
      - text: My Data & Analytics My Policies & Programs My Team My Insights & Intelligence My Apps & Shortcuts My Favorites
      - emphasis: 
      - emphasis: 
      - emphasis: 
    `);

    await expect(this.homePageContainer).toMatchAriaSnapshot(`
      - emphasis: 
      - paragraph: Private Equity Mergers & Acquisitions
      - paragraph: Overview of Portfolio Company activity
      - emphasis: 
      - emphasis: 
      - paragraph: Aviation Insights
      - paragraph: General Aviation Benchmarking & Analytics
      - emphasis: 
      - emphasis: 
      - paragraph: Marine Insights
      - paragraph: Marine placement analysis and market intelligence
      - emphasis: 
    `);
  }

  /**
   * Clicks on the logo to navigate back to the home page.
   */
  public async clickLogo(): Promise<void> {
    await this.waitForVisible(this.logoContainer);
    await this.logoContainer.click();
  }

  /**
   * Clicks on the Aviation Insights General link and waits for the popup.
   * @returns The new page that opens in a popup.
   */
  public async clickAviationInsights(): Promise<Page> {
    const aviationPagePromise = this.page.waitForEvent('popup');
    await this.waitForVisible(this.aviationInsightsLink);
    await this.aviationInsightsLink.click();
    return await aviationPagePromise;
  }
}
