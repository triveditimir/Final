import { Page, Locator, expect } from '@playwright/test';
import { FileDownload } from '../Utils/fileDownload';
import fs from 'fs'



/**
 * Abstract Base Page class that provides common functionality for all pages.
 */
export abstract class basePage {
    protected readonly page: Page;
    protected fileDownload: FileDownload;

    constructor(page: Page) {
        this.page = page;
    }

    

    /**
     * Waits for the element to be visible.
     * @param locator - The locator of the element to wait for.
     */
    protected async waitForVisible(locator: Locator): Promise<void> {
        await expect(locator).toBeVisible({ timeout: 35000 });
    }

    protected async getTooltipText(): Promise<string> {
        const tooltip = await this.page.locator('.p-tooltip-text')
        if (tooltip.isVisible()) {
            const tooltipText = await tooltip.textContent();
            return tooltipText
        }
        return ""
    }


    







}