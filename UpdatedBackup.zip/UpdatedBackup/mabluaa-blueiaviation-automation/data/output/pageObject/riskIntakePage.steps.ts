
import { Page, Locator, expect } from '@playwright/test';
import { basePage } from './BasePage';


/**
 * Page Object class for the BlueIAV page.
 */
export class BlueIAVPage extends basePage {
    constructor(page: Page) {
        super(page);
    }

    // Element definitions
    private get colleagueLoginLink(): Locator {
        return this.page.locator('a:has-text("Colleague login")');
    }

    private get riskIntakeButton(): Locator {
        return this.page.getByText('Risk Intake', { exact: true });
    }

    private get companyNameDropdown(): Locator {
        return this.page.getByRole('searchbox', { name: 'Select Company Name or' });
    }

    private get scottsdaleIncOption(): Locator {
        return this.page.getByRole('option', { name: 'Scottsdale Inc (Demo)' });
    }

    private get createNewApplicationButton(): Locator {
        return this.page.getByRole('button', { name: 'Create new Application' });
    }
    private get clickonDropdown(): Locator {
        return this.page.locator('//span[text()="Enter Applicant Structure"]');
    }


    private get individualOption(): Locator {
        return this.page.getByText('Individual', { exact: true });
    }

    private get nextButton(): Locator {
        return this.page.getByRole('button', { name: 'Next' });
    }

    private get primaryContactNameDropdown(): Locator {
        return this.page.getByRole('combobox', { name: 'Enter primary contact name' });
    }

    private get deepakPrabhuOption(): Locator {
        return this.page.getByText('Deepak Prabhu');
    }

    private get jobTitleTextbox(): Locator {
        return this.page.getByRole('textbox', { name: 'Enter job title' });
    }

    private get feinNumberTextbox(): Locator {
        return this.page.getByRole('textbox', { name: 'Enter FEIN number' });
    }

    private get tickerSymbolTextbox(): Locator {
        return this.page.getByRole('textbox', { name: 'Enter ticker symbol' });
    }

    private get dunsNumberTextbox(): Locator {
        return this.page.getByRole('textbox', { name: 'Enter DUNS number' });
    }

    private get demographicsRegion(): Locator {
        return this.page.getByRole('region', { name: 'Demographics' });
    }

    private get currencyDropdown(): Locator {
        return this.page.locator('//mat-select//span[text()="Enter currency"]');
    }

    private get totalNumberTextbox(): Locator {
        return this.page.getByRole('textbox', { name: 'Enter total number of' });
    }

    private get ofacSanctionTextbox(): Locator {
        return this.page.getByRole('textbox', { name: 'Enter Name of OFAC Sanction' });
    }

    private get continueButton(): Locator {
        return this.page.getByRole('button', { name: 'Continue' });
    }

    private get saveButton(): Locator {
        return this.page.getByRole('button', { name: 'Save', exact: true });
    }

    private get successMessage(): Locator {
        return this.page.getByText('Details saved successfully');
    }

    /**
     * Logs in and creates a new application.
     */
    public async createNewApplication(): Promise<void> {
        await this.colleagueLoginLink.click();
        //await this.page.goto('https://staging2.linqbymarsh.com/blueiaviation/overview?dl=true');
        await this.riskIntakeButton.click();
        await this.page.waitForTimeout(5000);
        await this.page.reload();
        await this.companyNameDropdown.click();
        await this.scottsdaleIncOption.click();
        await this.createNewApplicationButton.click();
        await this.clickonDropdown.click();
        await this.individualOption.click();
        await this.nextButton.click();
        await this.primaryContactNameDropdown.click();
        await this.deepakPrabhuOption.click();
        await this.jobTitleTextbox.fill('test');
        await this.nextButton.click();
        await this.feinNumberTextbox.fill('123');
        await this.tickerSymbolTextbox.fill('32');
        await this.dunsNumberTextbox.fill('33');
        await this.nextButton.click();
        await this.currencyDropdown.click();
        await this.page.getByRole('option', { name: 'USD' }).click();
        await this.totalNumberTextbox.fill('112');
        await this.page.locator('#mat-mdc-checkbox-6-input').check();
        await this.ofacSanctionTextbox.fill('vid');
        await this.page.locator('#mat-mdc-checkbox-8-input').check();
        await this.continueButton.click();
        await this.successMessage.click();
        await expect(this.successMessage).toContainText("Details saved successfully");
        await this.page.locator('div:nth-child(14) > .flex-col > blu-ul-checkbox > .main-checkbox > .checkbox-container').click();
        await this.page.getByText('LINQ HOME LINQ HOME Aviation').click();
        //await this.saveButton.click();
        //await this.successMessage.click();
    }
}
