import { test, expect } from '@playwright/test';
import * as dotenv from 'dotenv';
import AppFn from '../src/businessFunctions/AppFn';
import { AppMain } from '../src/AppMain';

let appMain: AppMain
let appFunc: AppFn

test.describe('Hull Market Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    dotenv.config();

  });

  test.beforeEach(async ({ page }) => {
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {

  });

  test.afterAll(async () => {

  });

  test('Verify Hull Market Insight Filters and UI Elements @smoke @liability', async ({ page }, testInfo) => {
    await appMain.ClaimsMarketInsight.navigateToMarketInsights();

    await test.step('Hull Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyMarketDashboardReports()
    });


    await test.step('Select Hull section and verify filters and retention', async () => {
      await appFunc.hullMarketInsightFunction.verifyFiltersAndRetenion()

    });

    await test.step('Verify filter chips value as selected in filters', async () => {
      await appFunc.filterFunctions.validatefilterChips()
    });

    await test.step('Validate Graph footers', async () => {
      await appFunc.hullMarketInsightFunction.verifyGraphFootersHull()
    });

    await test.step('Hull: Verify Toggle Button', async () => {
      await appFunc.graphFunctions.verifyToggleButtonIsSelected("Annual Hull Rate Trend");

    });

    await test.step('Validate footer and disclaimers visibility', async () => {
      await appFunc.dashboardFunctions.validateFooter();
    });

    await test.step('Validate Graph Axes for different filters', async () => {
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Crew", "All", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Plane Type", "UAS", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Plane Type", "Jet Engine", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Business Type", "Industrial Aid", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Business Type", "Commercial", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Market", "Starr", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Year", "2025", true)
      await appFunc.hullMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Year Quarter", "Q1", true)

      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      await appFunc.hullMarketInsightFunction.verifyChartAxes()
      await appFunc.filterFunctions.resetAllFilters();

    })

    await test.step(' Get filters', async () => {
      const { results, percentPlacementYoYRange } = await appFunc.dbPipeline.runFullPipeline();
      console.log('Percent Placement YoY Range:', percentPlacementYoYRange);
      const expectedText = await appFunc.hullMarketInsightFunction.percentPlacementYoYRangegetText();
      console.log("Expected Text is", expectedText)
      expect(percentPlacementYoYRange).toBe(expectedText);
    })



  });

});