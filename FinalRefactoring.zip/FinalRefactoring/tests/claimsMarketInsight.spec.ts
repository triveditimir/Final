import * as dotenv from 'dotenv';
import { test, Page } from '@playwright/test';
import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';

let appMain: AppMain
let appFunc: AppFn

test.describe('Claims Market Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    // Setup steps before all tests run, e.g., initialize database connections, environment variables
    dotenv.config();
  });

  test.beforeEach(async ({ page }) => {
    // Setup steps before each test, e.g., navigate to login page
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {
    // Capture screenshot after each test and attach to report
    const screenshot = await page.screenshot();
    await testInfo.attach('Screenshot', {
      body: screenshot,
      contentType: 'image/png',
    });
  });

  test.afterAll(async () => {
    // Cleanup steps after all tests run, e.g., close database connections
  });

  test('Validate Market Insight Claims Dashboard and Filters @smoke @claims', async ({ page }, testInfo) => {
    await appMain.ClaimsMarketInsight.navigateToMarketInsights();


    await test.step('Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyMarketDashboardReports()
    });

    await test.step('Select Claims section', async () => {
      await appFunc.claimsMarketInsightFunction.navigateToClaimsDashboard()
    });


    await test.step('Verify filters and filters Retention on Claims Dashboard', async () => {
      await appFunc.claimsMarketInsightFunction.verifyFiltersAndRetenion()
    });

    await test.step('Verify filter chips value as selected in filters', async () => {
      await appFunc.filterFunctions.validatefilterChips()
    });

    await test.step('Verify summary on Claims Dashboard', async () => {
      await appFunc.claimsMarketInsightFunction.validateClaimsSummaryboard()
    });

    await test.step('Validate table data with pie chart for Number Of Claims', async () => {
      await appFunc.claimsMarketInsightFunction.validateClaimsPieChartWithTableData("Number of Claims")
    })

    await test.step('Validate table data with pie chart for Claim Incurred', async () => {
      await appMain.ClaimsMarketInsight.buttonWithText("Claim Incurred").click();
      await appFunc.claimsMarketInsightFunction.validateClaimsPieChartWithTableData("Incurred Total")
    })

    await test.step('Validate table data with graph for Analysis Data', async () => {
      await appFunc.claimsMarketInsightFunction.validateTableGraphDataConsistency();
    })

    await test.step('Verify Table Data for Summary views', async () => {
      await appFunc.claimsMarketInsightFunction.validateSummaryViewTableData()
    })

    await test.step('Validate Graph Axes for "Claim Summary by Policy Year"', async () => {
      const claimSummaryChartId = "claimSummaryByPolicyYearChart"
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimSummaryChartId, "Claim Type", "Physical DamageIM", true)
    })

    await test.step('Validate Graph Axes for different filters', async () => {
      const claimMarketChartId = "claimByMarketChart"
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimMarketChartId, "Policy Type", "Hull & Liability", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimMarketChartId, "Plane Type", "Jet Engine", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimMarketChartId, "Loss Peril", "Pilot Error", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimMarketChartId, "Claim Type", "Liability  Bodily Injury or Fatality", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimMarketChartId, "Coverage Type", "Hull", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(claimMarketChartId, "Market", "QBE", true)
      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      await appFunc.graphFunctions.verifyChartAxes(claimMarketChartId)
    })

    await test.step('Verify screen elements for "By Count" inside "Detailed View" button', async () => {
      await appFunc.claimsMarketInsightFunction.validateClaimsDetailedView()
    })

    await test.step('Verify screen elements for "Claim Values Distribution"', async () => {
      const claimValueDistributionReportId = "claimValuesDistributionReport"
      await appFunc.claimsMarketInsightFunction.claimValueDistributionLabel()
      await appFunc.graphFunctions.verifyChartAxes(claimValueDistributionReportId)
    })

    await test.step('Validates the "custom slider" along with range for "Total Incurred" at the right of "Claim Values Distribution"', async () => {
      await appFunc.claimsMarketInsightFunction.validateClaimIncurredSliderForClaimValueDistribution()
    })
    // Download Chart Different Charts of Market Insight in  PDF and PNG
    await test.step('Download Chart Different Charts of Claims Insight in  PDF and PNG', async () => {
      await appFunc.claimsMarketInsightFunction.downloadSummaryandDetailedViewViewCharts();
      await appFunc.claimsMarketInsightFunction.downloadreserveAndPaidCharts();
      await appFunc.claimsMarketInsightFunction.claimOccurrenceIncurredDownload();
      await appFunc.claimsMarketInsightFunction.claimSummaryByMarketDownload();
      await appFunc.claimsMarketInsightFunction.lossPerilDownload();
      await appFunc.claimsMarketInsightFunction.claimValueDistributonDownload();
      await appFunc.claimsMarketInsightFunction.lossPerilByYearDownload();


    }); 
  });
});
