import { test, Page } from '@playwright/test';
import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';

import * as dotenv from 'dotenv';

let appMain: AppMain
let appFunc: AppFn


test.describe('MACH Market Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    // Setup steps before all tests run, e.g., initialize database connections, environment variables
    dotenv.config();
  });

  test.beforeEach(async ({ page }) => {
    // Setup steps before each test, e.g., navigate to login page
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {
    // Capture screenshot after each test and attach to report

  });

  test.afterAll(async () => {

  });

  test('Verify MACH Market Insight Filters and UI Elements @smoke @mach', async ({ page }, testInfo) => {
    await appMain.ClaimsMarketInsight.navigateToMarketInsights();

    await test.step('Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyMarketDashboardReports()
    });

    await test.step('Select Liability section and verify filters and retention', async () => {
      await appFunc.machMarketInsightFunction.verifyFiltersAndRetenion()

    });

    await test.step('Validate footer and disclaimers visibility', async () => {
      await appFunc.dashboardFunctions.validateFooter();
    });

    await test.step('MACH: Verify Toggle Button', async () => {
      await appFunc.graphFunctions.verifyToggleButtonIsSelected("Hull Rate by Insured Value");
    });

    await test.step('Verify Graph Changes related for Dropdown and Toggle Selection', async () => {
        const toggleBtnSelctor = appMain.graphPage.chartToggleBtn("Average Net Liability")
          await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart1", "Median Hull Rate")
          await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart1", "Median Net Liability",toggleBtnSelctor)
          await appFunc.graphFunctions.verifyChartChangesOnToggleSelection("#chart2", "Hull Rate by Insured Value", ["Actual", "Trend"])
          await appFunc.graphFunctions.verifyChartChangesOnToggleSelection("#chart2", "Liability Premium by Liability Limit", ["Actual", "Trend"])
    });
    

    await test.step('Validate graph axes for multiple filters', async () => {
      const chartId = "averageHullRateChartId"

      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(chartId, "Crew", "2+", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(chartId, "Plane Type", "UAS", true)

      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      await appFunc.graphFunctions.verifyChartAxes(chartId)
      await appFunc.filterFunctions.resetAllFilters();
    });
    //TODO:- Footer is not working, need to fix
    /*test.step('Validate MACH Aviation Hull Rate Chart Footer', async () => {
      const expectedFooterTexts = ['Plane Type', 'Insured Value Range', 'Sample Count'];
      await appFunc.graphFunctions.verifyGraphFooters('chart1', expectedFooterTexts)

    }); */

    await test.step('Download Chart Different Charts of Mach  Insight in  PDF and PNG', async () => {
      await appFunc.machMarketInsightFunction.downloadMultipleMachChartsPresentonTop();
    });
  });
});
