import { test } from '@playwright/test';
import * as dotenv from 'dotenv';
import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';

let appMain: AppMain
let appFunc: AppFn

test.describe('Liability Market Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    dotenv.config();

  });

  test.beforeEach(async ({ page }) => {
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {
    // Capture screenshot after each test and attach to report
    const screenshot = await page.screenshot();
    await testInfo.attach('Screenshot', {
      body: screenshot,
      contentType: 'image/png',
    });
  });

  test.afterAll(async () => {
    // Cleanup steps after all tests run, e.g., close database connections
  });

  test('Verify Liability Market Insight Filters and UI Elements @smoke @liability', async ({ page }, testInfo) => {
    await appMain.ClaimsMarketInsight.navigateToMarketInsights();

    await test.step('Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyMarketDashboardReports()
    });

    await test.step('Select Liability section and verify filters and retention', async () => {
      await appFunc.liabilityMarketInsightFunction.verifyFiltersAndRetenion()
    });

    await test.step('UnderWriter: Verify Toggle Button', async () => {
      await appFunc.graphFunctions.verifyToggleButtonIsSelected("Average Liability Premium By Limit");

    });

    await test.step('Verify Graph Changes related to the Dropdown changes', async () => {
      await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart2", "Median Liability Premium By Limit")
    });

    await test.step('Verify Graph Changes related for Toggle Selection', async () => {
      await appFunc.graphFunctions.verifyChartChangesOnToggleSelection("#chart2", "Annual Average Net Liability", ["Average", "Median"])
      
    });

    await test.step('Liability: Verify Chart Footer Bottom Text', async () => {
      await appFunc.liabilityMarketInsightFunction.verifyChartFooterText();
    });

    await test.step('Validate footer and disclaimers visibility', async () => {
      await appFunc.dashboardFunctions.validateFooter();
    });

    await test.step('Validate Graph Axes for different filters', async () => {
      const liabilityChartId = "yearChangeHullRate"
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(liabilityChartId, "Crew", "2+", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(liabilityChartId, "Plane Type", "UAS", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(liabilityChartId, "Business Type", "Industrial Aid", true)
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(liabilityChartId, "Liability Limit", "$300,000,000", true)

      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      await appFunc.graphFunctions.verifyChartAxes(liabilityChartId)
      // All years selected to enable more options in Year Quater
      await appFunc.graphFunctions.verifyGraphAxesWithClickOnFilterOption(liabilityChartId, "Year Quarter", "Q3", true)

      // TODO issue due to fix due to multiple elements
      // All years selected to enable more options in Quota Share
      //await appFunc.filterFunctions.selectAllFilterOptions("Year")
      //await appFunc.liabilityMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Quota Share", "Quota Share", true)

    })

    await test.step('Validate Warning when filters incorrect', async () => {
      await appFunc.filterFunctions.resetAllFilters();
      await appFunc.filterFunctions.unSelectFilterOptionsAllAndValidateWarning("Market", "Insufficient Data")
      await appFunc.filterFunctions.resetAllFilters();
    })

    // Download Chart Year over Year change Net Liability Premium PDF and PNG
    await test.step('Download Chart Year over Year change Net Liability Premium PDF and PNG', async () => {
      await appFunc.liabilityMarketInsightFunction.downloadAndValidateCharts();
    });
  });
});
