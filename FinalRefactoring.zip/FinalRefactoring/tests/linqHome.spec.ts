import { test, expect, Page } from '@playwright/test';

import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';
import * as dotenv from 'dotenv';

let appMain: AppMain
let page: Page
let appFunc: AppFn

test.describe('Linq Home Page', () => {
    test.beforeAll(async ({ browser }) => {
        // Setup steps before all tests run, e.g., initialize database connections, environment variables
        dotenv.config();
    });

    test.beforeEach(async ({ page }) => {
        // Setup steps before each test, e.g., navigate to login page
        appMain = new AppMain(page);
        appFunc = new AppFn(page)
        await appFunc.linqHomeFunction.navigateToLinqHomePage()
    });


    test.afterEach(async ({ page }, testInfo) => {
        // Capture screenshot after each test and attach to report
        const screenshot = await page.screenshot();
        await testInfo.attach('Screenshot', {
            body: screenshot,
            contentType: 'image/png',
        });
    });
    test.afterAll(async () => {
        // Cleanup steps after all tests run, e.g., close database connections
    });
    test('Validate LINQ Home Page screen', async ({ page }, testInfo) => {

        await test.step('Linq Home Page Validation', async () => {
            await appFunc.linqHomeFunction.navigateToHomePageAndVerify()
        });

        await test.step('Validate Logo Linq Home', async () => {
            await appFunc.linqHomeFunction.clickLogo()
        });

        await test.step('Click on Aviation Insight from Linq Home', async () => {
            await appFunc.linqHomeFunction.clickAviationInsights()
        });


    })
});


