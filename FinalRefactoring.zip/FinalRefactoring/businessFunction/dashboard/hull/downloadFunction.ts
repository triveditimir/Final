import { Page, expect } from "@playwright/test";
import fs from 'fs';
import { FileDownload } from '../../../data/output/Utils/fileDownload';

export default class downloadBFunction {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
    // Ensure download folder exists
    FileDownload.ensureDownloadFolder();
  }

/**
   * Verify that download options are visible on the page.
   */
  async verifyDownloadOptions(): Promise<void> {
    try {
      const downloadLink = this.page.locator('//*[@id="chart1"]/div/ci-menu-card/div/img');
      await expect(downloadLink).toBeVisible({ timeout: 30000 });
      console.log("Download options are visible");
    } catch (err) {
      console.error("Error verifying download options:", err);
      throw err;
    }
  }

  /**
   * Clicks the main download button/link to reveal options.
   */
  async clickDownloadMainLink(): Promise<void> {
    const mainDownloadBtn = this.page.locator('//*[@id="chart1"]/div/ci-menu-card/div/img');
    await expect(mainDownloadBtn).toBeVisible({ timeout: 30000 });
    await mainDownloadBtn.click();
    console.log("Clicked main download link");
  }

  /**
   * Download "As PDF" option.
   */
  async downloadAsPdf(): Promise<string> {
    await this.clickDownloadMainLink();

    const pdfOption = this.page.locator("//label[normalize-space()='Download as PDF']");
    await expect(pdfOption).toBeVisible({ timeout: 20000 });
    await pdfOption.click();

    const filePath = await FileDownload.downloadAndSaveFile(this.page, 'pdf', 'ReportPDF');
    console.log(`PDF downloaded at: ${filePath}`);
    return filePath;
  }

  /**
   * Download "As PNG" option.
   */
  async downloadAsPng(): Promise<string> {
    await this.clickDownloadMainLink();

    const pngOption = this.page.locator("//label[normalize-space()='Download as PNG']");
    await expect(pngOption).toBeVisible({ timeout: 20000 });
    await pngOption.click();

    const filePath = await FileDownload.downloadAndSaveFile(this.page, 'png', 'ReportPNG');
    console.log(`PNG downloaded at: ${filePath}`);
    return filePath;
  }

  /**
   * Validate the latest file exists and has the expected extension.
   */
  async validateLatestFile(extension: string): Promise<string> {
    const latestFile = FileDownload.getLatestFile();
    if (!latestFile || !fs.existsSync(latestFile)) {
      throw new Error("No latest file found");
    }
    if (!latestFile.endsWith(`.${extension}`)) {
      throw new Error(`Latest file extension mismatch. Expected .${extension}`);
    }
    console.log(`Validated latest file: ${latestFile}`);
    return latestFile;
  }

  /**
   * Validate content inside the latest PDF.
   */
  async validatePdfContent(): Promise<void> {
    const pdfPath = await this.validateLatestFile('pdf');
    const text = await FileDownload.extractTextFromPDF(pdfPath);
    if (!text || !text.includes("Generated on")) {
      throw new Error("PDF content validation failed");
    }
    console.log("PDF content validated");
  }

  /**
   * Perform full download cycle: PDF and PNG.
   */
  async performDownloadAndValidation(): Promise<void> {
    const pdfPath = await this.downloadAsPdf();
    await this.validatePdfContent();

    const pngPath = await this.downloadAsPng();
    // Additional validations can be added here
  }

  /**
   * Check if "Download Started" popup is visible.
   */
  async verifyDownloadStartedPopup(): Promise<void> {
    const popupLocator = this.page.locator('xpath=//div[contains(text(),"Download Started")]');
    await expect(popupLocator).toBeVisible({ timeout: 20000 });
    console.log("Download started popup is visible");
  }
}