import { Locator, Page } from "playwright";
import { AppMain } from "../../../src/AppMain";
import { expect } from "allure-playwright";
import fs from 'fs';
import { DownloadPage } from "../../../data/output/pageObject/common/downLoadPage";
import { FileDownload } from "../../../data/output/Utils/fileDownload";



export default class DownloadFunctions {
  readonly page: Page;
readonly appMain: AppMain

  constructor(page: Page) {
    this.page = page;
    this.appMain = new AppMain(page)
    // Ensure download folder exists
    
    FileDownload.ensureDownloadFolder();
  }

 
/**
   * Verify that download options are visible on the page.
   */
  async verifyDownloadOptions(): Promise<void> {
    try {
      FileDownload.performDownloadClick;
      console.log("Download options are visible");
    } catch (err) {
      console.error("Error verifying download options:", err);
      throw err;
    }
  }

    /**
   * Download "As PDF" option.
   */
  
   async downloadAsPdf(): Promise<string> {
    //await this.clickDownloadMainLink();
    await expect(this.appMain.downloadPage.pdfOptionselect).toBeVisible({ timeout: 900000 });
    this.appMain.downloadPage.pdfOptionselect.click();
    const filePath = await FileDownload.downloadAndSaveFile(this.page, 'pdf', 'ReportPDF');
    console.log(`PDF downloaded at: ${filePath}`);
    return filePath;
  }

  /**
   * Download "As PNG" option.
   */
   async downloadAsPng(): Promise<string> {
    await expect(this.appMain.downloadPage.pngOptionselect).toBeVisible({ timeout: 900000 });
    this.appMain.downloadPage.pngOptionselect.click();
    const filePath = await FileDownload.downloadAndSaveFile(this.page, 'png', 'ReportPNG');
    console.log(`PNG downloaded at: ${filePath}`);
    return filePath;
  
  }

  /**
   * Validate the latest file exists and has the expected extension.
   */
  async validateLatestFile(extension: string): Promise<string> {
    const latestFile = FileDownload.getLatestFile();
    if (!latestFile || !fs.existsSync(latestFile)) {
      throw new Error("No latest file found");
    }
    if (!latestFile.endsWith(`.${extension}`)) {
      throw new Error(`Latest file extension mismatch. Expected .${extension}`);
    }
    console.log(`Validated latest file: ${latestFile}`);
    return latestFile;
  }

  /**
   * Validate content inside the latest PDF.
   */
  async validatePdfContent(): Promise<void> {
    const pdfPath = await this.validateLatestFile('pdf');
    const text = await FileDownload.extractTextFromPDF(pdfPath);
    if (!text || !text.includes("Generated on")) {
      throw new Error("PDF content validation failed");
    }
    console.log("PDF content validated");
  }

  /**
   * Perform full download cycle: PDF and PNG.
   */
  async performDownloadAndValidation(): Promise<void> {
    const pdfPath = await this.downloadAsPdf();
    await this.validatePdfContent();

    const pngPath = await this.downloadAsPng();
    // Additional validations can be added here
  }

  /**
   * Check if "Download Started" popup is visible.
   */
  async verifyDownloadStartedPopup(): Promise<void> {
    const popupLocator = this.page.locator('xpath=//div[contains(text(),"Download Started")]');
    await expect(popupLocator).toBeVisible({ timeout: 500000 });
    console.log("Download started popup is visible");
  }
}
