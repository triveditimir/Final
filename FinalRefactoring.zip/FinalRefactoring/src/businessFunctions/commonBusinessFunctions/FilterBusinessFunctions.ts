import { Locator, Page } from "playwright";
import { AppMain } from "../../../src/AppMain";
import { expect } from "allure-playwright";
import { normalizeDollarValue } from "../../../data/output/Utils/commonUtils";

export default class FilterFunctions {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    public async unSelectFilterOptionsAllAndValidateWarning(filterName: string, warningMessage: string): Promise<void> {
        const filterPage = this.appMain.filterPage
        //get all checked filter and unselect them
        const selectedCheckboxes = filterPage.getAllSelectedCheckBoxInFilter(filterName)
        const count = await selectedCheckboxes.count();
        for (let i = 0; i < count; i++) {
            await selectedCheckboxes.nth(i).click();
        }

        await this.applyFilters()

        const warningMsg = await filterPage.getWarningMessageLocator(warningMessage)
        await expect(warningMsg).toBeVisible({ timeout: 20000 });
        this.resetAllFilters()
    }

    public async selectAllFilterOptions(filterName: string): Promise<void> {
        const filterPage = this.appMain.filterPage

        const allCheckboxesInFilter = await filterPage.getAllCheckBoxInFilter(filterName)
        const checkboxesCount = await allCheckboxesInFilter.count();
        for (let i = 0; i < checkboxesCount; i++) {
            const checkbox = allCheckboxesInFilter.nth(i);
            if (!(await checkbox.isChecked())) {
                await checkbox.check();
            }
        }
        await this.applyFilters()
    }

    public async clickFilterOption(filterName: string, filterValue: string): Promise<void> {
        const filterValueOption = await this.appMain.filterPage.getFilterValueLocator(filterName, filterValue)
        await filterValueOption.click()
    }
    public async clickFilterOptionAndApply(filterName: string, filterValue: string): Promise<void> {
        await this.clickFilterOption(filterName, filterValue)
        await this.applyFilters()
    }

    public async resetAllFilters(): Promise<void> {
        await this.appMain.filterPage.resetAllFilterButton.click()
        await this.page.waitForTimeout(2000);
    }

    public async applyFilters(): Promise<void> {
        const filterPage = this.appMain.filterPage
        const applyFilterBtn = filterPage.applyFilterButton();
        await applyFilterBtn.click();
        await this.page.waitForTimeout(4000);
    }

    public async validatefilterChips(): Promise<void> {
        await this.page.waitForTimeout(4000);
        const filterPage = this.appMain.filterPage
        const checkedBoxes = filterPage.checkboxFilterSelected()

        for (let i = 0; i < await checkedBoxes.count(); i++) {
            let label = await checkedBoxes.nth(i).evaluate(el =>
                el.closest('label')?.textContent?.trim()
            );

            const filterName = await checkedBoxes.nth(i).evaluate((el) => {
                const showPanel = el.closest('div[class*="show-panel"]');
                const parent = showPanel?.parentElement;
                const header = parent?.querySelector('[class*="filter-option-header"]');
                return header?.textContent?.trim() || null;
            });

            await this.appMain.filterPage.filterChips(filterName).first().hover();
            const tooltipText = await this.appMain.filterPage.getTooltipText();
            //Todo: Avoiding $ as for libiality limit $ is missing in tooltip
            if (label.startsWith("$")) {
                label = normalizeDollarValue(label).toString()
            }

            expect(tooltipText).toContain(label?.trim());
        }
    }
}