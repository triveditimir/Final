import { Page } from "playwright";
import { AppMain } from "../../../src/AppMain";
import { expect } from "allure-playwright";

export default class DashboardFunctions {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    public async verifyMarketDashboardReports(): Promise<void> {
        const expectedTexts = ['Hull', 'Liability', 'Market', 'Underwriter', 'MACH', 'Claims'];
        const element = await this.appMain.dashboardPage.dashboardMenu

        for (const text of expectedTexts) {
            await expect(element).toContainText(text);
            console.log("the expected value is as ", text)
        }
    }
    public async verifyPlacementDashboardReports(): Promise<void> {
        const expectedTexts = ['RSM', 'Market', 'Aircraft', 'Client History', 'UAS', 'Benchmarking','Premiums','Claims'];
        const element = await this.appMain.dashboardPage.placementDashboardMenu

        for (const text of expectedTexts) {
            await expect(element).toContainText(text);
            console.log("the expected value is as ", text)
        }
    }

    public async validateFooter(): Promise<void> {
        const aviationOverviewPage = this.appMain.aviationOverviewPage
        await expect(aviationOverviewPage.footer).toBeVisible();
        await expect(aviationOverviewPage.contactUsDisclaimer).toBeVisible();
        await expect(aviationOverviewPage.footerDisclaimer).toBeVisible();
    }
}