import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import { expect } from "allure-playwright";

import { crewSnapshot, businessTypeSnapshot, planeTypeSnapshot, marketSnapshot, liabilityLimitSnapshot, yearSnapshot, yearQuarterSnapshot, quotaShareSnapshot } from './AriaSnapshots';
import FilterFunctions from "../../commonBusinessFunctions/FilterBusinessFunctions";
import GraphFunctions from "../../commonBusinessFunctions/GraphBusinessFunctions";

export default class LiabilityMarketInsightFunction {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    async verifyToggleLabels(): Promise<void> {
       const liabilityMarketPage = this.appMain.liabilityMarketPage
        const liabilityButton = await liabilityMarketPage.liabilityButton
        await liabilityButton.click();
        //Validate toggle lables
        const liabilityToggleBtn = await liabilityMarketPage.liabilityToggleBtn
        await liabilityToggleBtn.first().click();
        await expect(liabilityToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')
        await liabilityToggleBtn.last().click();
        await expect(liabilityToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')

    }

    async verifyChartFooterText(): Promise<void> {
        const liabilityMarketPage = this.appMain.liabilityMarketPage
        const chartFooterMessage = await liabilityMarketPage.chartFooterMessage
        await expect(chartFooterMessage).toBeVisible({timeout : 15000})
        
    }

    async verifyFiltersAndRetenion(): Promise<void> {
        const liabilityMarketPage = this.appMain.liabilityMarketPage
        const liabilityButton = await liabilityMarketPage.liabilityButton

        await liabilityButton.click();

        // Verify Filters
        await this.verifyDefaultFilterSettings();
        // Verify Rententions
        await this.validateFilterRetention();


        const resFilter = await this.appMain.filterPage.filterContainerLocator().getByText('Commercial')
        await expect(resFilter).not.toBeChecked();

        //Reset Filters
        await liabilityMarketPage.resetAllFilterButton.click();
        await this.page.waitForTimeout(5000);

        await liabilityButton.click();
    };

    public async verifyGraphAxesWithClickOnFilterOption(filterName: string, filterValue?: string, resetFilters: boolean = true): Promise<void> {
        const filterFunctions = new FilterFunctions(this.page)
        console.log(filterName, filterValue)
        await filterFunctions.clickFilterOption(filterName, filterValue)
        await filterFunctions.applyFilters()

        await this.verifyChartAxes()

        if (resetFilters) {
            await filterFunctions.resetAllFilters();
        }
    }

    public async verifyChartAxes() {
        const graphFunctions = new GraphFunctions(this.page)
        const chartSelector = '#yearChangeHullRate';
        graphFunctions.verifyChartAxes(chartSelector)
    }


    private async validateFilterRetention() {
        const liabilityMarketPage = this.appMain.liabilityMarketPage
        await liabilityMarketPage.uncheckCommercialBusinessType();
        await this.page.waitForTimeout(5000);
        const marketButton = await liabilityMarketPage.marketButton;
        marketButton.click();
    }

    private async verifyDefaultFilterSettings(): Promise<void> {
        const liabilityMarketPage = this.appMain.liabilityMarketPage

        await liabilityMarketPage.VerifyFiltersButtons();

        const filterNamesAndSnapshots = [
            { name: "Crew", snapshot: crewSnapshot },
            { name: "Business Type", snapshot: businessTypeSnapshot },
            { name: "Plane Type", snapshot: planeTypeSnapshot },
            { name: "Market", snapshot: marketSnapshot },
            { name: "Liability Limit", snapshot: liabilityLimitSnapshot },
            { name: "Year", snapshot: yearSnapshot },
            { name: "Year Quarter", snapshot: yearQuarterSnapshot },
            { name: "Quota Share", snapshot: quotaShareSnapshot }
        ];

        for (const filter of filterNamesAndSnapshots) {
            const locator = await this.appMain.filterPage.filterContainer(filter.name);
            await liabilityMarketPage.waitForVisible(locator);
            await expect(locator).toMatchAriaSnapshot(filter.snapshot);
        }
    }

    // Helper to perform download and validation
    private async downloadAndValidateChart(): Promise<void> {
        const liabilityMarketPage = this.appMain.liabilityMarketPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        await liabilityMarketPage.averageChartDownload.click();
        await downloadFuncs.downloadAsPdf();
        await liabilityMarketPage.averageChartDownload.click();
        await downloadFuncs.downloadAsPng();
        await downloadFuncs.validatePdfContent();
    }

    /**
     * End-to-end business function to download multiple charts as PDF and PNG,
     * validate their content, and switch between different chart options.
     */
    public async downloadAndValidateCharts(): Promise<void> {
        const liabilityMarketPage = this.appMain.liabilityMarketPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Download Year over Year change Net Liability Premium Chart
         {
            await this.appMain.liabilityMarketPage.YearoverYearChangeNetLiabilityDownload.click();
            await downloadFuncs.downloadAsPdf();
            await this.appMain.liabilityMarketPage.YearoverYearChangeNetLiabilityDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();

        };

        // Array of chart options with their respective switch actions
        const chartOptions = [
            { name: 'Default', switchAction: async () => {} }, // No switch needed
            { name: 'MedianLiabilityPremiumByLimit', switchAction: async () => {
                await liabilityMarketPage.charSelectionDropDown.click();
                await liabilityMarketPage.selectMedianLiabilityPremiumByLimit.click();
            }},
            { name: 'AverageNetLiabilityByLimit', switchAction: async () => {
                await liabilityMarketPage.charSelectionDropDown.click();
                await liabilityMarketPage.averageNetLiabilityByLimit.click();
            }},
            { name: 'MedianNetLiabilityByLimit', switchAction: async () => {
                await liabilityMarketPage.charSelectionDropDown.click();
                await liabilityMarketPage.medianNetLiabilityByLimit.click();
            }},
            { name: 'AverageNetLiabilityperPAX', switchAction: async () => {
                await liabilityMarketPage.charSelectionDropDown.click();
                await liabilityMarketPage.averageNetLiabilityperPAX.click();
            }},
            { name: 'MedianNetLiabilityperPAX', switchAction: async () => {
                await liabilityMarketPage.charSelectionDropDown.click();
                await liabilityMarketPage.MedianNetLiabilityperPAX.click();
            }},
            { name: 'AircraftCount', switchAction: async () => {
                await liabilityMarketPage.charSelectionDropDown.click();
                await liabilityMarketPage.AircraftCount.click();
            }},
        ];

        // Loop through each chart option
        for (const option of chartOptions) {
            {
                await option.switchAction();
                await this.downloadAndValidateChart();
            };
        }

    }
}