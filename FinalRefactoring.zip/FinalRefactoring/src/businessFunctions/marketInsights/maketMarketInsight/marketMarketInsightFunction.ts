import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import { expect } from "allure-playwright";

import { crewSnapshot, businessTypeSnapshot, planeTypeSnapshot, yearSnapshot, quotaShareSnapshot } from './AriaSnapshots';
import FilterFunctions from "../../commonBusinessFunctions/FilterBusinessFunctions";
import GraphFunctions from "../../commonBusinessFunctions/GraphBusinessFunctions";

export default class marketMarketInsightFunction {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    async verifyToggleLabels(): Promise<void> {
        const insightsPage = this.appMain.insightsPage
        const marketButton = await insightsPage.marketButton
        await marketButton.click();
        //Validate toggle lables
        const marketToggleBtn = await insightsPage.marketInsightToggleBtn
        await marketToggleBtn.first().click();
        await expect(marketToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')
        await marketToggleBtn.last().click();
        await expect(marketToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')

    }
    async verifyFiltersAndRetenion(): Promise<void> {
        const insightsPage = this.appMain.insightsPage
        const marketButton = await insightsPage.marketButton

        await marketButton.click();

        // Verify Filters
        await this.verifyDefaultFilterSettings();
        // Verify Rententions
        await this.validateFilterRetention();


        const resFilter = await insightsPage.filterContainerLocator().getByText('Commercial')
        await expect(resFilter).not.toBeChecked();

        //Reset Filters
        await insightsPage.resetAllFilterButton.click();
        await this.page.waitForTimeout(5000);

        await marketButton.click();
    };

    public async verifyGraphAxesWithClickOnFilterOption(filterName: string, filterValue?: string, resetFilters: boolean = true): Promise<void> {
        const filterFunctions = new FilterFunctions(this.page)
        console.log(filterName, filterValue)
        await filterFunctions.clickFilterOption(filterName, filterValue)
        await filterFunctions.applyFilters()

        await this.verifyChartAxes()

        if (resetFilters) {
            await filterFunctions.resetAllFilters();
        }
    }

    public async verifyChartAxes() {
        const graphFunctions = new GraphFunctions(this.page)
        const chartSelector = '#lostBusinessByMarket';
        graphFunctions.verifyChartAxes(chartSelector)
    }


    private async validateFilterRetention() {
        const insightsPage = this.appMain.insightsPage
        await insightsPage.uncheckCommercialBusinessType();
        await this.page.waitForTimeout(5000);
        const marketButton = await insightsPage.marketButton;
        marketButton.click();
    }

    private async verifyDefaultFilterSettings(): Promise<void> {
        const insightsPage = this.appMain.insightsPage

        await insightsPage.VerifyFiltersButtons();

        const filterNamesAndSnapshots = [
            { name: "Crew", snapshot: crewSnapshot },
            { name: "Business Type", snapshot: businessTypeSnapshot },
            { name: "Plane Type", snapshot: planeTypeSnapshot },
            //{ name: "Market", snapshot: marketSnapshot },
            // { name: "Liability Limit", snapshot: liabilityLimitSnapshot },
            { name: "Year", snapshot: yearSnapshot },
            //{ name: "Year Quarter", snapshot: yearQuarterSnapshot },
            { name: "Quota Share", snapshot: quotaShareSnapshot }
        ];

        for (const filter of filterNamesAndSnapshots) {
            const locator = await insightsPage.filterContainer(filter.name);
            await insightsPage.waitForVisible(locator);
            await expect(locator).toMatchAriaSnapshot(filter.snapshot);
        }
    }
    public async downloadMultiplePrimaryCharts() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidatePrimaryCharts = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.downloadfirst.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const primarychartActions = [
            {
                description: 'Market Insight - Lost Business By Market',
                action: async () => {
                    await insightsPage.button_LostBusinessByMarket.click();
                    await insightsPage.chartSelectionDropDownfirst.click();
                    await insightsPage.chartAirCraftLost.click();
                    await insightsPage.downloadfirst.click();
                }
            },
            {
                description: 'Market Insight - Client Lost',
                action: async () => {
                    await insightsPage.chartSelectionDropDownfirst.click();
                    await insightsPage.chartClientLost.click();
                    await insightsPage.downloadfirst.click();
                }
            },
            {
                description: 'Market Insight - Lost Business',
                action: async () => {
                    await insightsPage.chartSelectionDropDownfirst.click();
                    await insightsPage.chartLostBusiness.click();
                    await insightsPage.downloadfirst.click();
                }
            },
            {
                description: 'Market Insight - Total Premium',
                action: async () => {
                    await insightsPage.chartSelectionDropDownfirst.click();
                    await insightsPage.chartTotalPremium.click();
                    await insightsPage.downloadfirst.click();
                }
            },
            {
                description: 'Market Level - Average Commission Level Target',
                action: async () => {
                    await insightsPage.chartSelectionDropDownfirst.click();
                    await insightsPage.buttonMarketverageCommissionLevelTaret.click();
                    await insightsPage.downloadfirst.click();
                }
            }
        ];

        // Loop through each chart action
        for (const chart of primarychartActions) {
            await chart.action();
            await downloadAndValidatePrimaryCharts();
        }
    }


    public async downloadMultipleSecondaryCharts() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidateSecondaryCharts = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.downloadsecond.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const secondaryChartActions = [
            {
                description: 'Market Distribution by Premium',
                action: async () => {
                    await insightsPage.buttonMarketDistributtonbyPremium.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Market Distribution by Aircraft Percent',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartMarketDistributionbyAircraftPercent.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Market Business Breakdown',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.buttonMarketBusinessBreakdown.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Quota Share - Average Line Size',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartQuotaShareAverageLineSize.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Quota Share - Median Line Size',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartQuotaShareMedianLineSize.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Lead Markets By Market',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartLeadMarketsByMarket.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Total Qs Premium by Market',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartTotalQSPremiumbyMarket.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'Avg Qs Premium by Market',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartAvgQSPremiumbyMarket.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'QS Participants by Total Qs Aircraft',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartQSParticipantsbyTotalQSAircraft.click();
                    await insightsPage.downloadsecond.click();
                }
            },
            {
                description: 'QS Participants by Client',
                action: async () => {
                    await insightsPage.chartSelectionDropDownSecond.click();
                    await insightsPage.chartQSParticipantsbyClient.click();
                    await insightsPage.downloadsecond.click();
                }
            }
        ];



        for (const chart of secondaryChartActions) {
            await chart.action();
            await downloadAndValidateSecondaryCharts();
        }


    }
}
