import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import VerifyDB from "../../commonBusinessFunctions/verifyDatabaseData";



export default class hullPipeline {
  readonly page: Page;
  readonly appMain: AppMain;

  constructor(page: Page) {
    this.page = page;
    this.appMain = new AppMain(page);
  }

  // Existing methods...

  // method to run the full pipeline
  public async runFullPipeline() {
    const fullPipeline = [
      {
        $addFields: {
          yearQuater: {
            $cond: [
              { $lte: [{ $month: "$rnwDate" }, 3] },
              "Q1",
              {
                $cond: [
                  { $lte: [{ $month: "$rnwDate" }, 6] },
                  "Q2",
                  {
                    $cond: [
                      { $lte: [{ $month: "$rnwDate" }, 9] },
                      "Q3",
                      "Q4"
                    ]
                  }
                ]
              }
            ]
          },
          quotaShare: {
            $cond: [
              { $lt: ["$placementPtg", 1] },
              "Quota Share",
              "Non Quota Share"
            ]
          }
        }
      },
      {
        $match: {
          "cnNumber": "CN107417897",
          "placementType": { "$in": ["Commercial", "Industrial Aid"] },
          "planeType": { "$in": ["Jet Engine"] },
          "market": { "$in": ["QBE", "Starr"] },
          "yearQuater": { "$in": ["Q1"] },
          "quotaShare": { "$in": ["Non Quota Share", "Quota Share"] },
          "renewalYear": { "$in": [2025] },
          "maxHullValue": { "$gte": 2200000, "$lte": 8500000 },
          "hullPremium": { "$gte": 1 },
          "pyHullrate": { "$gte": 0.01 }
        }
      },
      {
        $addFields: {
          percentDiffHullRateYoY: {
            $cond: [
              {
                $in: [
                  "$percentdiffhullrate",
                  ["null", "", "NULL"]
                ]
              },
              0,
              {
                $multiply: [
                  "$percentdiffhullrate",
                  100
                ]
              }
            ]
          }
        }
      },
      {
        $addFields: {
          percentPlacementYoYRange: {
            $switch: {
              branches: [
                {
                  case: {
                    $in: [
                      "$percentDiffHullRateYoY",
                      [0, null]
                    ]
                  },
                  then: "0"
                },
                {
                  case: {
                    $lt: [
                      "$percentDiffHullRateYoY",
                      -50
                    ]
                  },
                  then: "Below -50%"
                },
                {
                  case: {
                    $and: [
                      {
                        $lt: [
                          "$percentDiffHullRateYoY",
                          -40
                        ]
                      },
                      {
                        $gte: [
                          "$percentDiffHullRateYoY",
                          -50
                        ]
                      }
                    ]
                  },
                  then: "-50% to -40%"
                },
                {
                  case: {
                    $and: [
                      {
                        $lt: [
                          "$percentDiffHullRateYoY",
                          -30
                        ]
                      },
                      {
                        $gte: [
                          "$percentDiffHullRateYoY",
                          -40
                        ]
                      }
                    ]
                  },
                  then: "-40% to -30%"
                },
                {
                  case: {
                    $and: [
                      {
                        $lt: [
                          "$percentDiffHullRateYoY",
                          -20
                        ]
                      },
                      {
                        $gte: [
                          "$percentDiffHullRateYoY",
                          -30
                        ]
                      }
                    ]
                  },
                  then: "-30% to -20%"
                },
                {
                  case: {
                    $and: [
                      {
                        $lt: [
                          "$percentDiffHullRateYoY",
                          -10
                        ]
                      },
                      {
                        $gte: [
                          "$percentDiffHullRateYoY",
                          -20
                        ]
                      }
                    ]
                  },
                  then: "-20% to -10%"
                },
                {
                  case: {
                    $and: [
                      {
                        $lt: [
                          "$percentDiffHullRateYoY",
                          0
                        ]
                      },
                      {
                        $gte: [
                          "$percentDiffHullRateYoY",
                          -10
                        ]
                      }
                    ]
                  },
                  then: "-10% to 0%"
                },
                {
                  case: {
                    $in: [
                      "$percentDiffHullRateYoY",
                      [0, null]
                    ]
                  },
                  then: "0"
                },
                {
                  case: {
                    $and: [
                      {
                        $gt: [
                          "$percentDiffHullRateYoY",
                          0
                        ]
                      },
                      {
                        $lte: [
                          "$percentDiffHullRateYoY",
                          10
                        ]
                      }
                    ]
                  },
                  then: "0% to 10%"
                },
                {
                  case: {
                    $and: [
                      {
                        $gt: [
                          "$percentDiffHullRateYoY",
                          10
                        ]
                      },
                      {
                        $lte: [
                          "$percentDiffHullRateYoY",
                          20
                        ]
                      }
                    ]
                  },
                  then: "10% to 20%"
                },
                {
                  case: {
                    $and: [
                      {
                        $gt: [
                          "$percentDiffHullRateYoY",
                          20
                        ]
                      },
                      {
                        $lte: [
                          "$percentDiffHullRateYoY",
                          30
                        ]
                      }
                    ]
                  },
                  then: "20% to 30%"
                },
                {
                  case: {
                    $and: [
                      {
                        $gt: [
                          "$percentDiffHullRateYoY",
                          30
                        ]
                      },
                      {
                        $lte: [
                          "$percentDiffHullRateYoY",
                          40
                        ]
                      }
                    ]
                  },
                  then: "30% to 40%"
                },
                {
                  case: {
                    $and: [
                      {
                        $gt: [
                          "$percentDiffHullRateYoY",
                          40
                        ]
                      },
                      {
                        $lte: [
                          "$percentDiffHullRateYoY",
                          50
                        ]
                      }
                    ]
                  },
                  then: "40% to 50%"
                },
                {
                  case: {
                    $gt: [
                      "$percentDiffHullRateYoY",
                      50
                    ]
                  },
                  then: "Above 50%"
                }
              ],
              default: "Did not match"
            }
          }
        }
      },
      {
        $facet: {
          YoYChangeHullRate: [
            {
              $match: {
                percentdiffhullrate: { $ne: null }
              }
            },
            {
              $group: {
                _id: {
                  percentPlacementYoYRange: "$percentPlacementYoYRange",
                  market: "$market"
                },
                uniqueTailNum: {
                  $addToSet: "$tailnum"
                }
              }
            },
            {
              $project: {
                percentPlacementYoYRange: "$_id.percentPlacementYoYRange",
                market: "$_id.market",
                uniqueTailNum: { $size: "$uniqueTailNum" }
              }
            }
          ],
          bucketUniqueTailTotal: [
            {
              $match: {
                percentdiffhullrate: { $ne: null }
              }
            },
            {
              $group: {
                _id: {
                  percentPlacementYoYRange: "$percentPlacementYoYRange"
                },
                uniqueTailNum: {
                  $addToSet: "$tailnum"
                }
              }
            },
            {
              $project: {
                _id: 0,
                bucket: "$_id.percentPlacementYoYRange",
                uniqueTailNumCount: { $size: "$uniqueTailNum" }
              }
            }
          ]
        }
      }
    ];
    
    // Call your method to execute the pipeline
    const verifyPipeline = new VerifyDB(this.page)
    const results = await verifyPipeline.verifyDatabaseDataWithPipeline(
      fullPipeline,
      "BlueiAviation", // replace with our actual database name
      "aviation_hull_data_demo" // replace with our collection name
    );
    console.log(JSON.stringify(results, null, 2));
    const percentPlacementYoYRange = results[0]?.YoYChangeHullRate[0]?.percentPlacementYoYRange;
    console.log('Extracted percentPlacementYoYRange:', percentPlacementYoYRange);
    
    return {
    results,percentPlacementYoYRange
  };
  }

  
}
