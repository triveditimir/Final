import { Page } from "playwright";
import { claimsMarketInsight } from "../data/output/pageObject/marketInsight/claimsMarketInsightPage";
import { ClaimsPlacementInsight } from "../data/output/pageObject/placementInsight/claimsPlacementInsightPage";
import { FileDownload } from './../data/output/Utils/fileDownload';
import { DashboardPage } from "./../data/output/pageObject/common/dashboardPage";
import { FilterPage } from "./../data/output/pageObject/common/FilterPage";
import { DownloadPage } from "./../data/output/pageObject/common/downLoadPage";
import DownloadFunctions from './../src/businessFunctions/commonBusinessFunctions/DownloadBusinessFunctions';
import { GraphPage } from "../data/output/pageObject/common/graphPage";
import { BlueIAviationInsightsPage } from "../data/output/pageObject/aviationOverview/aviationInsightsPage";
import { AviationOverviewPage } from "../data/output/pageObject/aviationOverview/aviationOverviewPage";
import { LiabilityMarketInsightPage } from "../data/output/pageObject/marketInsight/liabilityMarketInsightPage";
import { MarketInsightsPage } from "../data/output/pageObject/marketInsight/marketInsightsPage";
import { MachMarketInsightPage } from "../data/output/pageObject/marketInsight/mACHMarketInsightPage";
import { LinqPage } from "../data/output/pageObject/linqHome/linQHomePage";
import { ProspectInsight } from "../data/output/pageObject/prospectsInsight/prospectsInsightPage";
 

export class AppMain {
    protected page: Page;

    constructor(page: Page) {
        this.page = page
    }

    public get BlueIAviationInsightsPage(): BlueIAviationInsightsPage {
        return new BlueIAviationInsightsPage(this.page)
    }

    public get ClaimsMarketInsight(): claimsMarketInsight {
        return new claimsMarketInsight(this.page);
    }

    public get claimsPlacementInsight(): ClaimsPlacementInsight {
        return new ClaimsPlacementInsight(this.page);
    }

    public get downloadFile(): FileDownload {
        return new FileDownload(this.page)
    }

    public get aviationOverviewPage(): AviationOverviewPage {
        return new AviationOverviewPage(this.page)
    }

    public get liabilityMarketPage(): LiabilityMarketInsightPage {
        return new LiabilityMarketInsightPage(this.page)
    }

    public get insightsPage(): MarketInsightsPage {
        return new MarketInsightsPage(this.page)
    }

    public get dashboardPage(): DashboardPage {
        return new DashboardPage(this.page)
    }

    public get filterPage(): FilterPage {
        return new FilterPage(this.page)
    }

    public get downloadPage(): DownloadPage {
        return new DownloadPage(this.page)
    }
    public get downloadFunctions(): DownloadFunctions {
    return new DownloadFunctions(this.page);
    }
     public get machMarketInsightPage(): MachMarketInsightPage {
        return new MachMarketInsightPage(this.page)
    }

     public get graphPage(): GraphPage {
        return new GraphPage(this.page)
    }
    public get linqPage(): LinqPage {
        return new LinqPage(this.page)
    }

    public get prospectInsight(): ProspectInsight {
        return new ProspectInsight(this.page)
    }

     
     

}