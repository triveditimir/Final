import dialog from 'dialog-node';
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { PlaywrightWebBaseLoader, Page } from "langchain/document_loaders/web/playwright";
import path from 'path';
import fs from 'fs';
import { TextLoader } from 'langchain/document_loaders/fs/text';
import {
  RunnableConfig,
  RunnableWithMessageHistory,
} from "@langchain/core/runnables";
import { ChatMessageHistory } from "@langchain/community/stores/message/in_memory";
import config from '../../config/config.json' with { type: "json" };

var retvalue;
var retvalue1 = "OK";
var elementLocator;
let i = 0, j = 1;
let data = [];

const basePath = config.openaiBasePath;
const siteURL = config.siteUrl;


const model = new ChatOpenAI({
  openAIApiKey: process.env.openaiApiKey,
  temperature: 0.1,
  maxRetries: 0,
  maxTokens: -1,
},
  {
    basePath: `${basePath}/mmc-tech-gpt-4o-mini-128k-2024-07-18/`,
  });
import { JSDOM } from 'jsdom';

// Function to highlight and capture on a specific page
function highlightAndCapture() {
    const currentPage = window.location.href; // Get the current page URL

    // Check if the current page matches your target page
    if (currentPage === 'https://example.com/specific-page') {
        // Your logic to highlight and capture goes here
        console.log('Highlighting and capturing on the specific page.');
    } else {
        console.log('Not on the specific page.');
    }
}

// Call the function
highlightAndCapture();
const chat = async () => {


  function showDialog(msg, title, timeout) {
    return new Promise((resolve, reject) => {
      dialog.question(msg, title, timeout, (code, retVal, stderr) => {
        if (code === 0) {
          resolve(retVal);
        } else {
          reject(stderr);
        }
      });
    });
  }

  async function htmlPopup() {
    try {
      const result = await showDialog('Do you want to Capture html?', 'Capture HTML', 30000);
      retvalue = result
    } catch (error) {
      console.error(error);
    }
  }





  async function writeToHtmlFile(outputFilePath, htmlPage) {
    return new Promise((resolve, reject) => {
      fs.writeFile(outputFilePath, htmlPage, function (err) {
        if (err) reject(err);
        else resolve('Saved!');
      });
    });
  }




  const promptTemplate = ChatPromptTemplate.fromMessages([
    ["human", "You are a helpful assistant"],
    ["human", "{input}"],
  ]);




  const runnable = promptTemplate.pipe(model);

  const messageHistory = new ChatMessageHistory();

  const withHistory = new RunnableWithMessageHistory({
    runnable,

    getMessageHistory: (_sessionId: string) => messageHistory,
    inputMessagesKey: "input",

    historyMessagesKey: "history",
  });

  const __dirname = path.resolve();

  const loader = new PlaywrightWebBaseLoader(siteURL,
    {
      launchOptions: {
        headless: false,
        channel: "chrome",
        //args:['--start-maximized']
        // args:['--start-fullscreen'],
        //downloadsPath: "C:/Users/U1310797"
      },
      gotoOptions: {
        waitUntil: "load",
      },

      async evaluate(page: Page) {
        page.setViewportSize({ width: 1920, height: 1080 });
        while (retvalue1 === "OK") {
          await htmlPopup()
          if (retvalue === "OK") {
            let htmlPagewhole = await page.evaluate(async () => {

              // Create variables to store the starting and ending coordinates of the selection
              var startX, startY, endX, endY
              var count = 0
              var selectedHTML;


              // Create a new div element to represent the selection highlight
              var selectionDiv = document.createElement('div');
              selectionDiv.style.position = 'absolute';
              selectionDiv.style.backgroundColor = 'rgba(255, 0, 0, 0.3)';
              selectionDiv.style.pointerEvents = 'none';
              selectionDiv.style.zIndex = '9999';

              // Add an event listener to the document for mousedown event
              document.addEventListener('mousedown', function (event) {
                // Store the starting coordinates of the selection
                startX = event.clientX;
                startY = event.clientY;

                // Set the initial position and size of the selection highlight div
                selectionDiv.style.left = startX + 'px';
                selectionDiv.style.top = startY + 'px';
                selectionDiv.style.width = '0';
                selectionDiv.style.height = '0';

                // Append the selection highlight div to the document body
                document.body.appendChild(selectionDiv);
              });

              // Add an event listener to the document for mousemove event
              document.addEventListener('mousemove', function (event) {
                // Update the position and size of the selection highlight div based on the mouse movement
                if (startX !== undefined && startY !== undefined) {
                  var currentX = event.clientX;
                  var currentY = event.clientY;

                  var width = Math.abs(currentX - startX);
                  var height = Math.abs(currentY - startY);

                  selectionDiv.style.width = width + 'px';
                  selectionDiv.style.height = height + 'px';

                  selectionDiv.style.left = (currentX < startX ? currentX : startX) + 'px';
                  selectionDiv.style.top = (currentY < startY ? currentY : startY) + 'px';
                }
              });

              // Add an event listener to the document for mouseup event
              document.addEventListener('mouseup', function (event) {
                // Store the ending coordinates of the selection
                endX = event.clientX;
                endY = event.clientY;

                // Check if the selection area is valid (non-zero width and height)
                if (startX !== endX && startY !== endY) {
                  // Create a range object to represent the selected area
                  var range = document.createRange();

                  // Get the DOM element at the starting coordinates of the selection
                  var startElement = document.elementFromPoint(startX, startY);

                  // Get the DOM element at the ending coordinates of the selection
                  var endElement = document.elementFromPoint(endX, endY);

                  // Set the start and end points of the range object
                  range.setStartBefore(startElement);
                  range.setEndAfter(endElement);

                  // Create a new div element to contain the selected HTML
                  var selectedDiv = document.createElement('div');

                  // Clone the selected range and append it to the div element
                  selectedDiv.appendChild(range.cloneContents());

                  // Get the HTML content of the selected area
                  selectedHTML = selectedDiv.outerHTML;
                  console.log("selectedHTML --> ", selectedHTML)

                  // storing as a blob
                  let blob = new Blob([JSON.stringify(selectedHTML)], { type: 'text/plain' })


                  //   let url = URL.createObjectURL(blob)
                  //   let downloadLink = document.createElement('a')
                  //   var fileName = count.toString() + '.txt'
                  //   downloadLink.download = "example.txt"
                  //   downloadLink.href = url

                  //   count++
                  //  // data.push(downloadLink)
                  // // Click to download file
                  //  downloadLink.click()

                }

                // Remove the selection highlight div from the document
                document.body.removeChild(selectionDiv);

                // Reset the starting and ending coordinates
                startX = undefined;
                startY = undefined;
              });
              //return selected HTML
              return await new Promise(resolve => {
                setTimeout(() => {
                  resolve(selectedHTML)
                }, 3000)
              });
              ;
            });
            page.on('console', msg => {
              if (msg.text().includes("selectedHTML")) {
                data.push(msg.text().replace("selectedHTML -->  ", ""))
              }
            });
            i++;
          } else {
            break;
          }
          retvalue1 = retvalue
        }
        return "Hello";
      }
    }
  );


  const data1 = await loader.load();
  var loaderHTML;
  var htmlText;
  var lengthofOutput;
  var maxToken = 10000
  console.log("data ---- -->", data)
  console.log("data.length -->", data.length)



  for (let i = 0; i < data.length; i++) {
    let outputFilePath = path.join(__dirname, "data", "output", "HTML", "HTML_" + i.toString() + ".txt")
    console.log("outputFilePath-->", outputFilePath)
    const fileWriteResult = await writeToHtmlFile(outputFilePath, data[i]);
    console.log(`File write result: ${fileWriteResult}`);
    const config: RunnableConfig = { configurable: { sessionId: 50 } };
    var inputFilePathFeature = path.join(__dirname, "data", "output", "HTML", "HTML_" + i.toString() + ".txt")
    //var inputFilePathFeature = data[i]
    var loader1 = new TextLoader(inputFilePathFeature)
    loaderHTML = await loader1.load()
    htmlText = loaderHTML[0].pageContent.toString()
    lengthofOutput = htmlText.length
    console.log("lengthofHTML", htmlText.length)
    var count = Math.ceil(lengthofOutput / maxToken)
    var start = 0
    var outputGherkinscript = "";
    var outputStepDefinition = "";
    for (let j = 0; j < count; j++) {
      var inputMessage = "Below html is a portion of the larger webpage. As a automation tester could you please help me to create a cucumberjs feature file using below portion of the html \n" + htmlText.substring(start, start + maxToken)
      var output = await withHistory.invoke({ input: inputMessage }, config);
      if (!output.content.toString().toLowerCase().includes("sorry")) {
        outputGherkinscript = outputGherkinscript + output.content.toString()
      }

      //var inputMessagepage = "You are an automation tester. Below html is a portion of the larger webpage. Help me create page object pattern and getter setters for all the elements if present with type links, text boxes, buttons, radio buttons, checkboxes and dropdowns with page object model for below HTML in Playwright and TypeScript format. \n" + htmlText.substring(start, start + maxToken)
      //var inputMessagepage = "You are an automation tester. Below html is a portion of the larger webpage. Help me create page object pattern and getter setters for all the elements if present with type links, text boxes, buttons, radio buttons, checkboxes and dropdowns with page object model for below HTML in selenium and java format. \n" + htmlText.substring(start, start + maxToken)
      var inputMessagepage = `You are an expert automation engineer specializing in Playwright and TypeScript.
                              Generate a production-ready Page Object Model implementation from the HTML file under sources ${htmlText.substring(start, start + maxToken)} and following are the requirements:

                              1. **Element Identification**
                              - Categorize elements by type: links, textboxes, buttons, radio, checkboxes, dropdowns
                              - Use semantic HTML attributes in priority order:
                              1. data-testid
                              2. ARIA roles
                              3. Text content matching
                              4. CSS selectors (last resort)

                              2. **Class Structure**
                              - Implement using Abstract Base Page pattern
                              - Separate element definitions from interaction methods
                              - Include type guards for dynamic element states

                              3. **Code Standards**
                              - TypeScript 5.0+ with strict null checks
                              - Playwright 1.40+ best practices
                              - Documentation with TSDoc
                              - Error handling for element visibility/timeouts

                              4. **Output Format**
                              Provide a complete TypeScript file with the following structure:
                              - Import statements for necessary Playwright modules.-Abstract Base Page class definition.
                              - Specific Page Object class definition (e.g., FirstPage).
                              - Element definitions as private getters.
                              - Public methods for interactions with the page.Error handling and visibility checks.
                              - TSDoc comments for each method and class. 
                              `
      var output1 = await withHistory.invoke({ input: inputMessagepage }, config);
      if (!output1.content.toString().toLowerCase().includes("sorry")) {
        outputStepDefinition = outputStepDefinition + output1.content.toString()
      }
      start = start + maxToken
    }
    var outputFilePathFeature = path.join(__dirname, "data", "output", "Feature", "feature_" + i.toString() + ".feature")
    if (outputGherkinscript.length > 0) {
      const fileWriteResult = await writeToHtmlFile(outputFilePathFeature, outputGherkinscript);
    }
    var outputFilePathDefinition = path.join(__dirname, "data", "output", "pageObject", "pageObject" + i.toString() + ".steps.ts")
    if (outputStepDefinition.length > 0) {
      var inputMessageCodeOptimize = "Redefine the following typescript code to improve readability, performance, and best practices. Ensure correct type annotation, remove reduntant code, and optimize logic where necessary. Return only the improved code without any explanation" + outputStepDefinition
      var outputOptimizeCode = await withHistory.invoke({ input: inputMessageCodeOptimize }, config);
      var outputOptimizeCodeUpdated = outputOptimizeCode.content.toString()
      if (outputOptimizeCodeUpdated.length > 0) {
        const fileWriteResult = await writeToHtmlFile(outputFilePathDefinition, outputOptimizeCodeUpdated);
      }
    }
  }
}
chat();
