  // Helper function to normalize dollar values for comparison
  export const normalizeDollarValue = (value: string): number | null => {
    if (!value) return null;
    // Remove $ and commas, convert k to *1000
    const val = value.toLowerCase().replace(/\$/g, '').replace(/,/g, '').trim();
    if (val.endsWith('k')) {
      const num = parseFloat(val.slice(0, -1));
      return isNaN(num) ? null : num * 1000;
    }
    const num = parseFloat(val);
    return isNaN(num) ? null : num;
  }