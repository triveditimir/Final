
export const FormatNumber = (value): string => {
    if (value >= 1e6) {
        return (value / 1e6).toFixed(2) + 'M'; // Convert to millions
    }
    if (value >= 1e3) {
        return (value / 1e3).toFixed(2) + 'K'; // Convert to thousands
    }
    return value.toString(); // Return the number as is

}