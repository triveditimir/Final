import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';

export class LiabilityMarketInsightPage extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    public applyFilterButton(): Locator {
        return this.page.locator('#goBtn');
    }

    public get liabilityButton(): Locator {
        return this.page.locator('//div[contains(text(),"Liability")]')
    }

    public get marketButton(): Locator {
        return this.page.locator('//div[contains(text(),"Market")]')
    }

    public get warningMsg(): Locator {
        return this.page.locator("//div[contains(@class, 'warning-message') and contains(text(), 'Insufficient Data')]")
    }

    public get liabilityToggleBtn(): Locator {
        return this.page.locator("//ci-toggle-button//button")
    }

    public get chartFooterMessage(): Locator {
        return this.page.locator('//ci-graph-footer//div[text()="Chart numbers represent the percentage of sample clients falling within the indicated percentage change range."]')
    }

    public async uncheckCommercialBusinessType(): Promise<void> {
        const filterByBusinessType = this.page.locator('//input[@value="Commercial"]/parent::label')
        await filterByBusinessType.click();
        await this.page.waitForTimeout(5000);
        await this.page.locator('//button[text()="Apply Filters"]').click();
    }

    public async checkCommercialBusinessType(): Promise<void> {
        const filterByBusinessType = this.page.locator('//input[@value="Commercial"]/parent::label')
        await filterByBusinessType.click();
        await this.page.locator('//button[text()="Apply Filters"]').click();
    }

    public get YearoverYearChangeNetLiabilityDownload(): Locator {
        return this.page.locator("//*[@id='chart1']/div/ci-menu-card/div/img")
    }



    public get annualAverageNetLiabilityChartMenu(): Locator {
        return this.page.locator("//button[normalize-space()='Annual Average Net Liability']")
    }
    public get clickOnAverageButton(): Locator {
        return this.page.locator("//button[normalize-space()='Average']")
    }

    public get clickOnMeidanButton(): Locator {
        return this.page.locator("//button[normalize-space()='Median']")
    }
    public get averageChartDownload(): Locator {
        return this.page.locator("//*[@id='chart2']/div/ci-menu-card/div/img")
    }

    public get averageLiabilityPremiumByLimitChartMenu(): Locator {
        return this.page.locator("//button[normalize-space()='Average Liability Premium By Limit']")
    }


    public get charSelectionDropDown(): Locator {
        return this.page.locator("//div[@aria-label='dropdown trigger']")
    }


    public get selectMedianLiabilityPremiumByLimit(): Locator {
        return this.page.locator("//span[normalize-space()='Median Liability Premium By Limit']")
    }

    public get averageNetLiabilityByLimit(): Locator {
        return this.page.locator("//span[contains(text(),'Average % Δ Net Liability By Limit')]")
    }

    public get medianNetLiabilityByLimit(): Locator {
        return this.page.locator("//span[contains(text(),'Median % Δ Net Liability By Limit')]")
    }
    public get averageNetLiabilityperPAX(): Locator {
        return this.page.locator("//span[normalize-space()='Average Net Liability per PAX']")
    }

    public get MedianNetLiabilityperPAX(): Locator {
        return this.page.locator("//span[normalize-space()='Median Net Liability per PAX']")
    }
    public get AircraftCount(): Locator {
        return this.page.locator("//span[normalize-space()='Aircraft Count']")
    }

  

   

}
