
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';


export class ProspectInsight extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    public get prospects(): Locator {
        return this.page.locator('//button[normalize-space()="PROSPECTS"]');
    }
    public get aviationInsightslabel(): Locator {
        return this.page.locator('//ci-placement-analytics-header//*[text()=" Aviation Insights "]');
    }


    public get graphImgProspect(): Locator {
        return this.page.locator('//img[@alt="Prospect"]');
    }



    private get downloadPDFButton(): Locator {
        return this.page.getByText('Download as PDF');
    }

}
