
import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';



/**
 * Class representing the login and home page of the application.
 */
export class LinqPage extends BasePage {
  /*private get colleagueLoginLink(): Locator {
    return this.page.locator('a[data-testid="colleague-login"]');
  } */

  public get homePageContainer(): Locator {
    return this.page.locator('app-linq-home');
  }

  public get logoContainer(): Locator {
    return this.page.locator('.site-header__logo-container');
  }

  public get aviationInsightsLink(): Locator {
    return this.page.getByText('Aviation Insights General').first();
  }

  public get colleagueLoginLink(): Locator {
        return this.page.locator("//span[normalize-space()='Colleague login']");
    }

  public get footer(): Locator {
    return this.page.locator('linq-global-footer');
  }

  public get contactUsDisclaimer(): Locator {
    return this.page.getByText('Contact Us Disclaimer: Any');
  }
  private get RSM(): Locator {
        return this.page.locator("//div[contains(text(),'RSM')]");
    }

  public get footerDisclaimer(): Locator {
    return this.footer.locator('div').filter({ hasText: 'Disclaimer: Any' }).nth(2);
  }
  
}
