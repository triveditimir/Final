import { Locator, Page } from '@playwright/test';
import { BasePage } from '../BasePage';

export class DownloadPage extends BasePage {
    constructor(page: Page) {
        super(page)
    }



    public get pdfOptionselect(): Locator {
        return this.page.locator("//label[normalize-space()='Download as PDF']");
    }

    public get pngOptionselect(): Locator {
        return this.page.locator("//label[normalize-space()='Download as PNG']");
    }


}
