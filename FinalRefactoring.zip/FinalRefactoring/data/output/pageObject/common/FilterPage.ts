import { Locator, Page } from '@playwright/test';
import { BasePage } from '../BasePage';

export class FilterPage extends BasePage {
    constructor(page: Page) {
        super(page)
    }

    public filterContainer(filterName: string): Locator {
        return this.page.locator(`//*[@id="filterContainer"]//span[text()="${filterName}"]/parent::div`);
    }

    public filterContainerLocator(): Locator {
        return this.page.locator('#filterContainer');
    }

    public get filtersButton(): Locator {
        return this.page.locator('//av-filter-chips//button//span[text()="Filters"]');
    }

    public applyFilterButton(): Locator {
        return this.page.locator('#goBtn');
    }

    public checkboxFilterSelected(): Locator {
        return this.page.locator('#filterContainer input[type="checkbox"]:checked');
    }

    public filterChips(filterName: string): Locator {
        return this.page.locator(`//av-filter-chips//button[contains(text(), "${filterName}")]`);
    }

    public getAllSelectedCheckBoxInFilter(filterName: string): Locator {
        return this.filterContainer(filterName).locator('input[type="checkbox"]:checked')
    }

    public getAllCheckBoxInFilter(filterName: string): Locator {
        return this.filterContainer(filterName).locator('input[type="checkbox"]')
    }

    public getFilterValueLocator(filterName: string, filterValue: string): Locator {
        const filterContainer = this.filterContainer(filterName)
        return filterContainer.locator(`text=${filterValue}`)
    }

    public getWarningMessageLocator(warningMessage: string): Locator {
        return this.page.locator(`//div[contains(@class, 'warning-message') and contains(text(), '${warningMessage}')]`)
    }

    public getFilterCardValue(filterTitle: string): Promise<string> {
        return this.page.locator(`//div[contains(@class, 'card-text') and contains(text(), '${filterTitle}')]/parent::div/div[contains(@class, 'card-value')]`).innerText();
    }

}
