import { Locator, Page } from '@playwright/test';
import { BasePage } from '../BasePage';

export class GraphPage extends BasePage {

    constructor(page: Page) {
        super(page)
    }

    public footerSpans(containerId: string): Locator {
        return this.page.locator(`//*[@id="${containerId}"]//div/ci-graph-footer//span`);
    }

    public chartSelector(chartId: string): Locator {
        return this.page.locator("#chartId']")
    }

    public chartToggleBtn(buttonText: string): Locator {
        return this.page.locator(`//ci-toggle-button//button[normalize-space()='${buttonText}']`)
    }

    public chartInsideToggleBtn(buttonText: string): Locator {
        return this.page.locator(`//av-single-toggle-selection//button[normalize-space()='${buttonText}']`)
    }

    public chartSlider(chartId: string): Locator {
        return this.page.locator(`//*[@id="${chartId}"]//ci-customise-slider`)
    }
    public chartSliderMaxlabel(chartId: string): Locator {
        return this.page.locator(`//*[@id="${chartId}"]//ci-customise-slider//label[contains(@class, 'max-slider-label')]`)
    }
    public chartSliderMaxInput(chartId: string): Locator {
        return this.page.locator(`//*[@id="${chartId}"]//ci-customise-slider//input[contains(@class, 'max-slider-input')]`)
    }
    public chartSliderMinlabel(chartId: string): Locator {
        return this.page.locator(`//*[@id="${chartId}"]//ci-customise-slider//label[contains(@class, 'min-slider-label')]`)
    }
    public chartSliderInput(chartId: string): Locator {
        return this.page.locator(`//*[@id="${chartId}"]//ci-customise-slider//input[contains(@class, 'min-slider-input')]`)
    }
}
