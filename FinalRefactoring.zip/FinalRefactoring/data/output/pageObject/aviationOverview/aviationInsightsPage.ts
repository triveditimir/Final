import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';
import { ClientSelectionPopup } from '../ClientSelectionPopup';

export class BlueIAviationInsightsPage extends BasePage {

    constructor(page: Page) {
        super(page);
    }

    private get colleagueLoginLink(): Locator {
        return this.page.locator("//span[normalize-space()='Colleague login']");
    }

    private get insightsButton(): Locator {
        return this.page.locator('//button[normalize-space()="INSIGHTS"][1]');
    }
    private get insightsmat(): Locator {
        return this.page.locator('//body//ci-root//mat-card[1]');
    }

    private get RSM(): Locator {
        return this.page.locator("//div[contains(text(),'RSM')]");
    }

    private get globalHeader(): Locator {
        return this.page.locator('.logo-white-text');
    }

    private get menuHeader(): Locator {
        return this.page.locator('//div[@class="ext-menu"]//div');
    }

    private get section(): Locator {
        return this.page.locator('.card-body');
    }

    private get placementInsightsHeader(): Locator {
        return this.page.locator('text=PLACEMENT INSIGHTS');
    }

    private get placementAnalyticsReports(): Locator {
        return this.page.locator('ci-placement-analytics-reports');
    }

        private get marketInsightsButtonLink(): Locator {
        return this.page.locator("(//button[normalize-space()='MARKET INSIGHTS'])[1]");
    }

    private get prospectsButtonLink(): Locator {
        return this.page.locator("//button[normalize-space()='PROSPECTS']");
    }

    private get placementInsightsButtonLink(): Locator {
        return this.page.locator("(//button[normalize-space()='PLACEMENT INSIGHTS'])[1]");
    }

    private get marketDashboardReports(): Locator {
        return this.page.locator('ci-market-dashboard-reports');
    }

    private get chart1(): Locator {
        return this.page.locator('#chart1');
    }

    private get sliderValueClick(): Locator {
        //return this.page.locator('#chart1').getByRole('slider', { name: 'ngx-slider', exact: true })
        return this.page.locator('//*[@id="chart1"]/div[2]/div[2]/div/ci-customise-slider/div/div/div[1]/label')
    }

    private get sliderValueEnter(): Locator {
        //return this.page.locator('#chart1').getByRole('slider', { name: 'ngx-slider', exact: true })
        return this.page.locator('//*[@id="chart1"]/div[2]/div[2]/div/ci-customise-slider/div/div/div[1]/input')
    }
    private get cardValue(): Locator {
        return this.page.locator('.card-value.pt-1')
    }
    private get aircraftOption(): Locator {
        //return this.page.locator('#chart1').getByRole('slider', { name: 'ngx-slider', exact: true })
        return this.page.getByText('Aircraft')
    }
    private get aviationInsightsLabel(): Locator {

        return this.page.locator('//ci-placement-analytics-header//div[text()=" Aviation Insights "]')
    }
    private get clickonHull(): Locator {

        return this.page.locator("//div[contains(text(),'Hull')]");
    }

    private get clickonFilters(): Locator {

        return this.page.locator("//button[@class='filter-chip d-flex align-items-center flex-row justify-content-center outline-btn']");
    }

    private get clickonApplyFilters(): Locator {

        return this.page.locator("//button[@id='goBtn']");
    }

    private get clickonAverageHullRateButton(): Locator {

        return this.page.locator("//button[normalize-space()='Average Hull Rate']");
    }

    private get marketInsightHullYearOverYearGraph(): Locator {
        return this.page.locator("//div[@id='HullMain']");
    }

    /**
     * Navigates to the login page and clicks on the colleague login link.
     */
    public async loginAsColleague(): Promise<void> {
        await this.waitForVisible(this.colleagueLoginLink);
        await this.colleagueLoginLink.click();
        await this.page.waitForTimeout(15000);


    }

    public async clickonloginAsColleague(): Promise<void> {
        await this.waitForVisible(this.colleagueLoginLink);
        await this.colleagueLoginLink.click();

    }

    /**
     * Validates the presence of key texts in the global header and section.
     */
    public async validateOverviewPage(): Promise<void> {
        await this.waitForVisible(this.globalHeader);
        await expect(this.globalHeader).toContainText(['MY DATA & ANALYTICS'])
        await expect(this.menuHeader).toContainText(['LINQ HOME', 'Aviation Overview', 'INSIGHTS', 'RISK INTAKE']);
        await expect(this.section).toContainText(['Insights', 'Risk Intake']);
    }

    public async verifyDefaultRSMSelected(expectedColor: string = 'rgb(38, 64, 232)') {
        const elementHandle = await this.RSM.elementHandle();
        if (elementHandle) {
            const fontColor = await elementHandle.evaluate((el) => {
                return window.getComputedStyle(el).color;
            });
            expect(fontColor).toBe(expectedColor);
            console.warn('Default RSM is selected');
        } else {
            throw new Error('RSM Element not found for default button');
        }
    }
    /**
     * Clicks on the Insights button and validates the placement insights.
     */
    public async navigateToInsights(): Promise<void> {
        await this.insightsButton.click();
        const clientPopup = new ClientSelectionPopup(this.page);
        // Handle intermittent client selection pop-up if it appears
        if (await clientPopup.isVisible()) {
            await clientPopup.selectClientByName('Scottsdale Inc (Demo)');
            await clientPopup.clickGo();
        }
        await this.page.waitForTimeout(2000);

        await this.waitForVisible(this.placementInsightsHeader);
        await expect(this.placementInsightsHeader).toBeVisible();
        await expect(this.placementAnalyticsReports).toMatchAriaSnapshot(`- text: RSM Market Aircraft Client History UAS Claims`, { timeout: 10000 });
        await this.verifyDefaultRSMSelected();
        await expect(this.placementAnalyticsReports).toMatchAriaSnapshot(`- text: RSM Market Aircraft Client History UAS Claims`, { timeout: 10000 });



        //  await expect(this.placementAnalyticsReports).toContainText(['RSM', 'Market', 'Aircraft', 'Client History', 'UAS', 'Claims']);
    }

    /**
     * Clicks on the Insights button and validates the placement insights.
     */
    public async navigateToInsight(): Promise<void> {
        await this.insightsButton.click();
        const clientPopup = new ClientSelectionPopup(this.page);
        // Handle intermittent client selection pop-up if it appears
        if (await clientPopup.isVisible()) {
            await clientPopup.selectClientByName('Scottsdale Inc (Demo)');
            await clientPopup.clickGo();
        }
        await this.page.waitForTimeout(2000);
        await this.waitForVisible(this.placementInsightsHeader);
        await expect(this.placementInsightsHeader).toBeVisible();
        await expect(this.placementAnalyticsReports).toMatchAriaSnapshot(`- text: RSM Market Aircraft Client History UAS Claims`, { timeout: 10000 });
        await this.verifyDefaultRSMSelected();
        await expect(this.placementAnalyticsReports).toMatchAriaSnapshot(`- text: RSM Market Aircraft Client History UAS Claims`, { timeout: 10000 });



        //  await expect(this.placementAnalyticsReports).toContainText(['RSM', 'Market', 'Aircraft', 'Client History', 'UAS', 'Claims']);
    }

    public async navigateToInsightMenu(): Promise<void> {
        //await this.insightsButton.click();
        await this.insightsmat.click();
        await this.page.waitForTimeout(15000);
    }

    /**
     * Interacts with the chart and validates its snapshot.
     */
    public async interactWithChart(): Promise<void> {
        await expect(this.chart1).toMatchAriaSnapshot(`- button "Net Hull Rate By Insured Value"`);
        await this.page.getByRole('button', { name: 'Net Hull Rate By Insured Value' }).click();
        await expect(this.chart1).toMatchAriaSnapshot(`- button "Net Liability Premium By Limit"`);
    }

    /**
     * Navigates to market insights and validates the market dashboard reports.
     */
    public async navigateToMarketInsights(): Promise<void> {
        await this.prospectsButtonLink.click();
        await this.page.waitForTimeout(15000);
        //await this.marketInsightsButton.click();
        await this.marketInsightsButtonLink.click();
        await this.page.waitForTimeout(15000);

        //await expect(this.marketDashboardReports).toMatchAriaSnapshot(`- text: Hull Liability Market Underwriter MACH Claims`);
        //await expect(this.marketDashboardReports).toContainText(['Hull', 'Liability', 'Market', 'Underwriter', 'MACH', 'Claims']);
    }

    public async markehtGraphImage(): Promise<void> {
        await this.marketInsightHullYearOverYearGraph.screenshot();
        await this.page.waitForTimeout(15000);
    }
    /**
     * Validate the slider value with the table value in Aircraft>Placemet insight using Filter
     */

    public async validateSliderAircraftHull(value) {

        await this.aircraftOption.click()
        await this.sliderValueClick.dblclick()
        await this.sliderValueEnter.fill(value.toString())
        await this.aviationInsightsLabel.click()


        //await expect(this.cardValue.first()).toContainText(newValue)

    }
    public async validateFilterRetention() {
        await this.page.getByRole('button', { name: ' Filters' }).click();
        const filterByPlaneType = this.page.getByRole('radio', { name: 'UAS' });
        await filterByPlaneType.check();
        await this.page.getByRole('button', { name: 'Apply Filters' }).click();
        await this.page.waitForTimeout(5000);
        await this.page.getByText('Market', { exact: true }).click();
        const resFilter = this.page.locator('#filterContainer').getByText('UAS')
        await expect(resFilter).toBeChecked();

    }
    public async filterReset() {
        await this.page.locator('//button[normalize-space()="Reset All"]').click();
        await this.page.locator('//span[normalize-space()="Filters"]').click();
    }

    public async navigateToHullGraph(): Promise<void> {
        await this.clickonHull.click();
        await this.page.waitForTimeout(5000);
        await this.clickonFilters.click();
        await this.clickonApplyFilters.click();
        await this.page.waitForTimeout(5000);
        //await this.clickonAverageHullRateButton.click();
    }
}
