// DataVerifier.ts
import { MongoClient, Db, Collection, Document } from 'mongodb';
import * as dotenv from 'dotenv';
import config from '../../../config/config.json' with { type: "json" };

// Load environment variables
dotenv.config();

const MONGODB_URI = config.mongodb_uri;
//const DBName=config.dbName;
//const collection =config.collectionName;
export class DataVerifier {
  private client: MongoClient;
  private dbName: string;

  constructor(dbName?: string) {
  this.dbName = dbName || config.dbName;  
}

  // Connect to MongoDB, returns Promise
  async connect(): Promise<void> {
    if (!MONGODB_URI) {
      return Promise.reject(new Error("MongoDB URI is not defined in the environment variables."));
    }
    this.client = new MongoClient(MONGODB_URI);
    return this.client.connect().then(() => {});
  }

  // Close connection, returns Promise
  async close(): Promise<void> {
    if (this.client) {
      return this.client.close();
    }
    return Promise.resolve();
  }

  // Get one document
  async getOneDocument<T extends Document>(collectionName: string, query: object,dbName?: string): Promise<T | null> {
  const dbToUse = dbName || this.dbName;
  const db: Db = this.client.db(dbToUse);
  const collection: Collection<T> = db.collection<T>(collectionName);
  return collection.findOne<T>(query);
   
  }

  // Get many documents with optional dbName
  async getManyDocuments<T extends Document>(collectionName: string,query: object,dbName?: string): Promise<T[]> 
  {
    const dbToUse = dbName || this.dbName;
    const db: Db = this.client.db(dbToUse);
    const collection: Collection<T> = db.collection<T>(collectionName);
    return collection.find<T>(query).toArray();
  }

  // Run aggregation pipeline with optional dbName
  async getAggregation(collectionName: string, pipeline: object[], dbName?: string): Promise<any[]>
   {
    const dbToUse = dbName || this.dbName;
    const db: Db = this.client.db(dbToUse);
    const collection: Collection = db.collection(collectionName);
    return collection.aggregate(pipeline).toArray();
  }
}

// This is a standalone exported function
export async function getAggregationDocuments<T extends Document>(
  client: MongoClient,
  dbName: string,
  collectionName: string,
  pipeline: object[]
): Promise<T[]> {
  const db: Db = client.db(dbName);
  const collection: Collection<T> = db.collection<T>(collectionName);
  return collection.aggregate<T>(pipeline).toArray();
}