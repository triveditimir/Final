import { Page, expect } from '@playwright/test';

/**
 * Utility function to validate graph axes labels.
 * @param page Playwright Page object
 * @param expectedXAxis Array of expected x-axis label strings
 * @param expectedYAxis Array of expected y-axis label strings
 * @param chartContainerSelector CSS selector for the chart container (default '#averageHullRateChartId')
 */
export async function validateGraphAxes(
  page: Page,
  expectedXAxis: string[],
  expectedYAxis: string[],
  chartContainerSelector: string 
): Promise<void> {
  const xAxisLabelsLocator = page.locator(`${chartContainerSelector} svg text`).filter({
    hasText: /202\d Q\d/,
  });

  const yAxisLabelsLocator = page.locator(`${chartContainerSelector} svg text`).filter({
    hasText: /^\$\d+\.\d{2}$/,
  });

  const xAxisLabels = await xAxisLabelsLocator.allTextContents();
  const yAxisLabels = await yAxisLabelsLocator.allTextContents();

  // Use expect.arrayContaining to check that actual labels include expected labels
  expect(xAxisLabels).toEqual(expect.arrayContaining(expectedXAxis));
  expect(yAxisLabels).toEqual(expect.arrayContaining(expectedYAxis));
}

/**
 * Utility function to capture x-axis labels dynamically from the graph.
 * @param page Playwright Page object
 * @param chartContainerSelector CSS selector for the chart container (default '#averageHullRateChartId')
 * @returns Array of x-axis label strings
 */
export async function captureXAxisLabels(
  page: Page,
  chartContainerSelector: string 
): Promise<string[]> {
  const xAxisLabelsLocator = page.locator(`${chartContainerSelector} svg text`).filter({
    hasText: /202\d Q\d/,
  });
  const xAxisLabels = await xAxisLabelsLocator.allTextContents();
  return xAxisLabels;
}

/**
 * Utility function to capture y-axis labels dynamically from the graph.
 * @param page Playwright Page object
 * @param chartContainerSelector CSS selector for the chart container (default '#averageHullRateChartId')
 * @returns Array of y-axis label strings
 */
export async function captureYAxisLabels(
  page: Page,
  chartContainerSelector: string 
): Promise<string[]> {
  const yAxisLabelsLocator = page.locator(`${chartContainerSelector} svg text`).filter({
    hasText: /^\$\d+\.\d{2}$/,
  });
  const yAxisLabels = await yAxisLabelsLocator.allTextContents();
  return yAxisLabels;
}
