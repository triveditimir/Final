import { Page, Locator, expect, Download } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import pdfParse from 'pdf-parse';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { pathToFileURL } from 'url';
import { PDFDocument, PDFDict, PDFStream, PDFName } from 'pdf-lib';
import sharp from 'sharp';
import { PNG } from 'pngjs';
import pixelmatch from 'pixelmatch';
import * as zlib from 'zlib';

// Imported winston for sophisticated logging
import winston from 'winston';

// Configure winston logger
const logger = winston.createLogger({
  level: 'info', // Change to 'debug' or 'error' as needed
  format: winston.format.combine(
    winston.format.colorize(),
    winston.format.timestamp({ format: 'DD-MM-YYYY HH:mm:ss' }),
    winston.format.printf(({ timestamp, level, message }) => `[${timestamp}] ${level}: ${message}`)
  ),
  transports: [
    new winston.transports.Console(),
  ],
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configurable download folder path
const DEFAULT_DOWNLOAD_FOLDER = path.resolve('C:/AviationDownloadedPDF_AND_PNG');

export class FileDownload {
  static downloadFolder = DEFAULT_DOWNLOAD_FOLDER;
  readonly page: Page;

  constructor(page: Page) {
        this.page = page;

    console.info('Initializing FileDownload');
    // Ensure download folder exists once during instantiation
    FileDownload.ensureDownloadFolder();
  }

  /**
   * Ensures the download folder exists.
   */
  static ensureDownloadFolder() {
    if (!fs.existsSync(this.downloadFolder)) {
      console.info(`Creating download folder at ${this.downloadFolder}`);
      fs.mkdirSync(this.downloadFolder, { recursive: true });
    } else {
      console.info(`Download folder already exists at ${this.downloadFolder}`);
    }
  }

  /**
   * Saves a download to a specified path.
   */
  private static async saveDownloadToFile(download: Download, filename: string): Promise<string> {
    this.ensureDownloadFolder();
    const savePath = path.join(this.downloadFolder, filename);
    console.info(`Saving download to: ${savePath}`);
    await download.saveAs(savePath);
    console.info(`File saved at ${savePath}`);
    return savePath;
  }

  /**
   * Clicks the download button.
   */
  static async performDownloadClick(locator: Locator): Promise<void> {
    console.info('Waiting for download button to be visible');
    await expect(locator).toBeVisible({ timeout: 70000 });
    console.info('Waiting for download button to be enabled');
    await expect(locator).toBeEnabled({ timeout: 70000 });
    console.info('Clicking download button');
    await locator.click({ timeout: 70000 });
  }

  /**
   * Downloads a file and saves it with a timestamped filename.
   */
  static async downloadAndSaveFile(page: Page, extension: string, prefix = 'AviationInsight'): Promise<string> {
    this.ensureDownloadFolder();
    console.info('Starting download process...');
    const [download] = await Promise.all([page.waitForEvent('download', { timeout: 190000 })]);
    console.info('Download event received.');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `${prefix}__${timestamp}.${extension}`;
    return await this.saveDownloadToFile(download, filename);
  }

  /**
   * Downloads and saves a PDF file.
   */
  async downloadAndSavePDF(): Promise<string> {
    console.info('Downloading and saving PDF...');
    return await FileDownload.downloadAndSaveFile(this.page, 'pdf', 'ReportPDF');
  }

  /**
   * Downloads and saves a PNG file.
   */
  async downloadAndSavePNG(): Promise<string> {
    console.info('Downloading and saving PNG...');
    return await FileDownload.downloadAndSaveFile(this.page, 'png', 'ReportPNG');
  }

  /**
   * Gets the latest PDF file based on modification time.
   */
  static getLatestFile(): string | null {
    if (!fs.existsSync(this.downloadFolder)) {
      console.warn(`Download folder does not exist: ${this.downloadFolder}`);
      return null;
    }
    const files = fs.readdirSync(this.downloadFolder)
      .filter(file => file.endsWith('.pdf'))
      .map(file => ({
        file,
        time: fs.statSync(path.join(this.downloadFolder, file)).mtime.getTime(),
      }))
      .sort((a, b) => b.time - a.time);
    if (files.length > 0) {
      const latestFile = path.join(this.downloadFolder, files[0].file);
      console.info(`Latest PDF file: ${latestFile}`);
      return latestFile;
    } else {
      console.warn('No PDF files found in download folder.');
      return null;
    }
  }

  /**
   * Extracts text from a PDF file.
   */
  static async extractTextFromPDF(filePath: string): Promise<string | null> {
    try {
      console.info(`Extracting text from PDF: ${filePath}`);
      const dataBuffer = fs.readFileSync(filePath);
      const data = await pdfParse(dataBuffer);
      const fullText = data.text;
      const regex = /Generated on:\s*\d{2}\/\d{2}\/\d{4}/;
      const match = fullText.match(regex);
      if (match) {
        console.info(`Found generated date: ${match[0]}`);
        return match[0];
      } else {
        console.warn('Generated on date not found in PDF.');
        return null;
      }
    } catch (error) {
      console.error('Error extracting text from PDF:', error);
      return null;
    }
  }

  /**
   * Extracts the second image embedded in the PDF.
   */
  static async extractSecondImageFromPDF(filePath: string): Promise<Buffer | null> {
    try {
      console.info(`Extracting second image from PDF: ${filePath}`);
      const pdfBytes = fs.readFileSync(filePath);
      const pdfDoc = await PDFDocument.load(pdfBytes);
      let imageCount = 0;

      for (const page of pdfDoc.getPages()) {
        const resources = page.node.Resources();
        if (!resources) continue;

        const xObjectRef = resources.get(PDFName.of('XObject'));
        if (!xObjectRef) continue;

        const xObjectDict = xObjectRef instanceof PDFDict ? xObjectRef : null;
        if (!xObjectDict) continue;

        for (const [key, value] of xObjectDict.entries()) {
          if (value instanceof PDFStream) {
            const subtype = value.dict.get(PDFName.of('Subtype'));
            if (subtype instanceof PDFName && subtype.decodeText() === 'Image') {
              imageCount += 1;
              if (imageCount === 2) {
                const imageBuffer = FileDownload.getImageBufferFromStream(value);
                // Save for debugging
                fs.writeFileSync('extracted_second_image.png', imageBuffer);
                console.info('Extracted second image from PDF.');
                return imageBuffer;
              }
            }
          }
        }
      }
      console.warn('Did not find second image in PDF.');
      return null;
    } catch (error) {
      console.error('Error extracting second image from PDF:', error);
      return null;
    }
  }

  /**
   * Helper to get image buffer from a PDFStream, handling filters.
   */
  static getImageBufferFromStream(stream: PDFStream): Buffer {
    const { dict } = stream;
    const filter = dict.get(PDFName.of('Filter'));
    const decodeParms = dict.get(PDFName.of('DecodeParms'));
    let bytes = stream.getContents();

    if (!bytes) {
      console.error('Stream contents are empty.');
      return Buffer.alloc(0);
    }

    // Handle filters
    if (filter) {
      if (filter instanceof PDFName) {
        const filterName = filter.decodeText();
        if (filterName === 'DCTDecode') {
          return Buffer.from(bytes);
        } else if (filterName === 'FlateDecode') {
          return zlib.unzipSync(Buffer.from(bytes));
        } else if (filterName === 'JXDecode') {
          return Buffer.from(bytes);
        } else {
          console.warn(`Unknown filter: ${filterName}`);
          return Buffer.from(bytes);
        }
      } else if (filter instanceof Array) {
        for (const f of filter) {
          if (f instanceof PDFName) {
            const filterName = f.decodeText();
            if (filterName === 'DCTDecode') {
              return Buffer.from(bytes);
            } else if (filterName === 'FlateDecode') {
              bytes = zlib.unzipSync(Buffer.from(bytes));
            } else if (filterName === 'JXDecode') {
              return Buffer.from(bytes);
            } else {
              console.warn(`Unknown filter in array: ${filterName}`);
            }
          }
        }
        return Buffer.from(bytes);
      }
    }
    return Buffer.from(bytes);
  }

  /**
   * Resize image buffer to specified width and height.
   */
  static async resizeImage(imageBuffer: Buffer, width: number, height: number): Promise<Buffer> {
    if (!imageBuffer || imageBuffer.length === 0) {
      throw new Error('Image buffer is empty or invalid.');
    }
    try {
      console.info(`Resizing image to ${width}x${height}`);
      return await sharp(imageBuffer).resize(width, height).toBuffer();
    } catch (err) {
      console.error('Error resizing image:', err);
      throw err;
    }
  }

  /**
   * Compares two images and returns the number of different pixels.
   */
  static compareImages(imgBuffer1: Buffer, imgBuffer2: Buffer): number {
    const PNG = require('pngjs').PNG;
    const pixelmatch = require('pixelmatch');

    const img1 = PNG.sync.read(imgBuffer1);
    const img2 = PNG.sync.read(imgBuffer2);

    if (img1.width !== img2.width || img1.height !== img2.height) {
      throw new Error('Images dimensions do not match for comparison.');
    }

    const { width, height } = img1;
    const diff = new PNG({ width, height });
    const numDiffPixels = pixelmatch(img1.data, img2.data, diff.data, width, height, { threshold: 0.1 });
    console.info(`Number of different pixels: ${numDiffPixels}`);
    return numDiffPixels;
  }

  /**
   * Main method to compare embedded PDF image with UI screenshot.
   */
  async comparePdfImageWithUIChart(filePath: string, uiSelector: string, threshold = 100): Promise<void> {
    console.info(`Comparing PDF image with UI chart: ${filePath}`);
    const imageBuffer = await FileDownload.extractSecondImageFromPDF(filePath);
    if (!imageBuffer || imageBuffer.length === 0) {
      console.error('Failed to extract image from PDF.');
      throw new Error('Failed to extract image from PDF.');
    }
    fs.writeFileSync('extracted_image.png', imageBuffer);
    console.info('Extracted image saved as extracted_image.png');

    const uiChartBuffer = await this.page.locator(uiSelector).screenshot();
    console.info('Captured UI screenshot.');

    const targetWidth = 800; // Can be made configurable
    const targetHeight = 600;

    const resizedPdfImage = await FileDownload.resizeImage(imageBuffer, targetWidth, targetHeight);
    const resizedUiImage = await FileDownload.resizeImage(uiChartBuffer, targetWidth, targetHeight);

    const diffPixels = FileDownload.compareImages(resizedPdfImage, resizedUiImage);
    console.info(`Difference pixels: ${diffPixels}`);
    expect(diffPixels).toBeLessThanOrEqual(threshold);
  }

  /**
   * Extracts all images embedded in the PDF.
   */
  static async extractAllImagesFromPDF(filePath: string): Promise<Buffer[]> {
    const images: Buffer[] = [];
    try {
      console.info(`Extracting all images from PDF: ${filePath}`);
      const pdfBytes = fs.readFileSync(filePath);
      const pdfDoc = await PDFDocument.load(pdfBytes);

      for (const page of pdfDoc.getPages()) {
        const resources = page.node.Resources();
        if (!resources) continue;

        const xObjectRef = resources.get(PDFName.of('XObject'));
        if (!xObjectRef) continue;

        const xObjectDict = xObjectRef instanceof PDFDict ? xObjectRef : null;
        if (!xObjectDict) continue;

        for (const [key, value] of xObjectDict.entries()) {
          if (value instanceof PDFStream) {
            const subtype = value.dict.get(PDFName.of('Subtype'));
            if (subtype instanceof PDFName && subtype.decodeText() === 'Image') {
              const imageBuffer = FileDownload.getImageBufferFromStream(value);
              images.push(imageBuffer);
            }
          }
        }
      }
    } catch (error) {
      console.error('Error extracting images from PDF:', error);
    }
    return images;
  }

  /**
   * Opens the latest downloaded PDF in a new tab and captures screenshots of all pages.
   * Purpose: To visually verify PDF content.
   */
  /*
  async openLatestPDFCaptureScreenshot(): Promise<void> {
    const latestFilePath = FileDownload.getLatestFile();
    if (!latestFilePath) {
      console.error('No latest PDF file found.');
      throw new Error('No PDF file found to open.');
    }
    const fileUrl = pathToFileURL(latestFilePath).href;
    console.info(`Opening PDF at: ${fileUrl}`);

    // Open a new tab
    const newPage = await this.page.context().newPage();

    try {
      // Navigate to the PDF URL
      console.info('Navigating to PDF URL');
      await newPage.goto(fileUrl);
      await newPage.waitForLoadState('networkidle');

      // Wait for the PDF viewer to load
      console.info('Waiting for PDF viewer to load');
      await newPage.waitForTimeout(15000); // Wait for rendering

      // Get total pages
      const totalPages = await newPage.evaluate(() => {
        if (window['pdfViewer']) {
          return window['pdfViewer'].pdfDocument.numPages;
        }
        return 1; // fallback
      });
      console.info(`Total pages in PDF: ${totalPages}`);

      const screenshots: Buffer[] = [];
      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        // Scroll to page
        console.info(`Scrolling to page ${pageNum}`);
        await newPage.evaluate((page) => {
          if (window['pdfViewer']) {
            window['pdfViewer'].scrollPageIntoView({ pageNumber: page });
          }
        }, pageNum);

        // Wait for rendering
        console.info(`Waiting for page ${pageNum} to render`);
        await newPage.waitForTimeout(2000);

        // Take screenshot
        console.info(`Taking screenshot of page ${pageNum}`);
        const screenshotBuffer = await newPage.screenshot({ fullPage: true });
        const isBlank = await FileDownload.isImageBlank(screenshotBuffer);
        if (isBlank) {
          console.warn(`Page ${pageNum} is blank, skipping.`);
          continue;
        }
        screenshots.push(screenshotBuffer);
      }

      if (screenshots.length === 0) {
        console.warn('No non-blank pages captured.');
      } else {
        // Combine images vertically
        const imagesMetadata = await Promise.all(screenshots.map(buf => sharp(buf).metadata()));
        const totalHeight = imagesMetadata.reduce((sum, meta) => sum + meta.height, 0);
        const maxWidth = Math.max(...imagesMetadata.map(meta => meta.width));

        console.info('Creating combined image.');
        const compositeImage = sharp({
          create: {
            width: maxWidth,
            height: totalHeight,
            channels: 3,
            background: { r: 255, g: 255, b: 255 },
          },
        });

        // Composite images
        let topOffset = 0;
        for (let i = 0; i < screenshots.length; i++) {
          await compositeImage.composite([{ input: screenshots[i], top: topOffset, left: 0 }]);
          topOffset += imagesMetadata[i].height;
        }

        // Save combined image
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const savePath = path.join(FileDownload.downloadFolder, `AviationPDF_${timestamp}.png`);
        await compositeImage.toFile(savePath);
        console.info(`Combined screenshot saved at: ${savePath}`);
      }
    } catch (error) {
      console.error('Error capturing PDF pages:', error);
    } finally {
      // Close the new tab
      if (!newPage.isClosed()) {
        console.info('Closing the PDF tab');
        await newPage.close();
      }
    }

    // Optionally bring back the original page
    const hasFurtherTests = false; // Set true if more tests follow
    if (!hasFurtherTests) {
      if (!this.page.isClosed()) {
        console.info('Bringing original page to front');
        await this.page.bringToFront();
      }
    }
  } 
  */

  /**
   * Helper to check if an image is blank (all white).
   */
  static async isImageBlank(buffer: Buffer): Promise<boolean> {
    const { data, info } = await sharp(buffer).raw().toBuffer({ resolveWithObject: true });
    console.info('Checking if image is blank.');
    for (let i = 0; i < data.length; i += info.channels) {
      if (
        data[i] !== 255 || // R
        data[i + 1] !== 255 || // G
        data[i + 2] !== 255 // B
      ) {
        console.info('Found non-white pixel.');
        return false; // Not blank
      }
    }
    console.info('Image is blank.');
    return true; // All white pixels
  }
}
