
import { Page, expect } from '@playwright/test';
import { normalizeDollarValue } from './commonUtils';

export async function validateChartLegendswithTable(page: Page, containerSelector: string): Promise<void> {
  // Extract legend names and values from the table inside <ci-analysis-table> within the container
  const tableData = await page.$$eval(`${containerSelector} ci-analysis-table table.analysis-table tr`, rows => {
    const data: Record<string, string> = {};
    rows.forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 2) {
        const key = cells[0].textContent?.trim() || '';
        const value = cells[1].textContent?.trim() || '';
        if (key) {
          data[key] = value;
        }
      }
    });
    return data;
  });

  // Extract legend colors from the <section class="legends"> within the container
  // Map legend names to their colors
  const legendColors = await page.$$eval(`${containerSelector} section.legends`, sections => {
    const legendColorMap: Record<string, string> = {};
    sections.forEach(section => {
      const spans = Array.from(section.querySelectorAll('span'));
      for (let i = 0; i < spans.length - 1; i++) {
        const iconSpan = spans[i];
        const textSpan = spans[i + 1];
        if (iconSpan.classList.contains('legend-icon') && textSpan.textContent) {
          // Get computed background color style
          const style = window.getComputedStyle(iconSpan);
          const bgColor = style.backgroundColor;
          // Convert rgb/rgba color to hex format
          function rgbToHex(rgb: string): string {
            const result = /^rgba?\((\d+),\s*(\d+),\s*(\d+)/i.exec(rgb);
            return result
              ? "#" +
                  ("0" + parseInt(result[1], 10).toString(16)).slice(-2) +
                  ("0" + parseInt(result[2], 10).toString(16)).slice(-2) +
                  ("0" + parseInt(result[3], 10).toString(16)).slice(-2)
              : rgb;
          }
          if (bgColor) {
            legendColorMap[textSpan.textContent.trim()] = rgbToHex(bgColor);
          }
          i++; // Skip next span as it is textSpan already processed
        }
      }
    });
    return legendColorMap;
  });

  // Extract chart text values by finding <g> elements with only fill and stroke attributes matching legend colors
  // Inside each <g>, find the <text> tag and then the <tspan> tag to get the value
  const chartData: Record<string, string> = {};
  for (const [legendName, color] of Object.entries(legendColors)) {
    const matchingValues = await page.$$eval(`${containerSelector} svg g`, (groups, color) => {
      const normalize = (c: string | null) => c?.toLowerCase().replace(/\s/g, '') || '';
      return groups
        .filter(g => {
          // Check if g has only fill and stroke attributes and their values equal to color
          const attrs = Array.from(g.attributes);
          if (attrs.length !== 2) return false;
          const fillAttr = g.getAttribute('fill');
          const strokeAttr = g.getAttribute('stroke');
          return normalize(fillAttr) === normalize(color) && normalize(strokeAttr) === normalize(color);
        })
        .map(g => {
          const textElem = g.querySelector('text');
          if (!textElem) return null;
          const tspanElem = textElem.querySelector('tspan');
          return tspanElem?.textContent?.trim() || null;
        })
        .filter(val => val !== null) as string[];
    }, color);

    chartData[legendName] = matchingValues.length > 0 ? matchingValues[0] : null;
  }

  // Assert that all normalized values from tableData and chartData match
  
  for (const legendName of Object.keys(tableData)) {
    const tableValue = tableData[legendName];
    const chartValue = chartData[legendName] || null;

    const normalizedTableValue = normalizeDollarValue(tableValue);
    const normalizedChartValue = normalizeDollarValue(chartValue || '');

    expect(normalizedChartValue).not.toBeNull();
    expect(normalizedTableValue).not.toBeNull();
    expect(normalizedChartValue).toBe(normalizedTableValue);
  }
}
