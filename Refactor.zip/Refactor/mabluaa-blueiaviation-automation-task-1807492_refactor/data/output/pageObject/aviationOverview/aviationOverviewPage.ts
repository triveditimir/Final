import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';


/**
 * LoginPage class that represents the login and overview page.
 */
export class AviationOverviewPage extends BasePage {
  
  constructor(page: Page) {
    super(page);
  }
  public get globalHeader(): Locator {
    return this.page.locator('.logo-white-text');
  }
  public get menuHeader(): Locator {
    return this.page.locator('//div[@class="ext-menu"]//div');
  }
  public get section(): Locator {
    return this.page.locator('.card-body');
  }

  public get footer(): Locator {
    return this.page.locator('linq-global-footer');
  }

  public get contactUsDisclaimer(): Locator {
    return this.page.getByText('Contact Us Disclaimer: Any');
  }
  public get RSM(): Locator {
    return this.page.locator("//div[contains(text(),'RSM')]");
  }

  public get footerDisclaimer(): Locator {
    return this.footer.locator('div').filter({ hasText: 'Disclaimer: Any' }).nth(2);
  }

  public get insightsButton(): Locator {
    return this.page.locator('//button[normalize-space()="INSIGHTS"][1]');
  }

  public get placementInsightsHeader(): Locator {
    return this.page.locator('text=PLACEMENT INSIGHTS');
  }

  public get placementInsightsButtonLink(): Locator {
    return this.page.locator("(//button[normalize-space()='PLACEMENT INSIGHTS'])[1]");
  }

  public get placementInsightsFilter(): Locator {
    return this.page.locator("//button[@class='filter-chip d-flex align-items-center flex-row justify-content-center outline-btn']");
  }

  public get placementAnalyticsReports(): Locator {
    return this.page.locator('ci-placement-analytics-reports');
  }

  public get chart1(): Locator {
    return this.page.locator('#chart1');
  }
}