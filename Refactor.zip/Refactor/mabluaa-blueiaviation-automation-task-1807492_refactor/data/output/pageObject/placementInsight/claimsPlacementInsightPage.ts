import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';
import { ClientSelectionPopup } from '../ClientSelectionPopup';

export class ClaimsPlacementInsight extends BasePage {
    constructor(page: Page) {
        super(page);
    }

    /**
     * Extracts the "Number of Claims" table data inside the div with id "claimCountIncurredChart"
     * and returns it as a JSON object with key-value pairs.
     * @returns Promise resolving to an object with keys as claim types and values as counts
     */
    public async getNumberOfClaimsTableData(labelToMatch: string): Promise<Record<string, number>> {
        const container = this.page.locator('#claimCountIncurredChart');
        const dynamicTables = container.locator('ci-dynamic-table');
        const count = await dynamicTables.count();
        for (let i = 0; i < count; i++) {
            const label = await dynamicTables.nth(i).locator('label.title').textContent();
            if (label?.trim() === labelToMatch) {
                const rows = dynamicTables.nth(i).locator('table tbody tr');
                const rowCount = await rows.count();
                const result: Record<string, number> = {};
                for (let j = 0; j < rowCount; j++) {
                    const key = (await rows.nth(j).locator('td').first().textContent())?.trim() || '';
                    const valueText = (await rows.nth(j).locator('td').nth(1).textContent())?.trim() || '0';
                    const value = Number(valueText.replace(/[$,]/g, '')) || 0;
                    if (key) {
                        result[key] = value;
                    }
                }
                return result;
            }
        }
        return {};
    }

    /**
     * Extracts the legend names and their corresponding values from the pie chart inside #claimCountIncurredChart.
     * Returns a JSON object with legend names as keys and their percentage values as numbers.
     */
    public async getPieChartLegendData(pieCharSelector: string): Promise<Record<string, number>> {
        const container = this.page.locator(pieCharSelector);
        const legendGroup = container.locator('[aria-label="Legend"]');
        const legendItems = legendGroup.locator('tspan');
        const legendCount = await legendItems.count();
        const result: Record<string, number> = {};

        // Map legend names to their colors
        const legendNameToColor: Record<string, string> = {};
        for (let i = 0; i < legendCount; i++) {
            const legendName = (await legendItems.nth(i).textContent())?.trim() || '';
            // Find closest g tag with role switch
            const legendTspan = legendItems.nth(i);
            const switchG = await legendTspan.evaluateHandle((el) => {
                let parent = el.parentElement;
                while (parent && parent.getAttribute('role') !== 'switch') {
                    parent = parent.parentElement;
                }
                return parent;
            });
            if (switchG) {
                // Inside switchG find g tag with fill and stroke attributes and a child path element
                const colorG = await switchG.evaluateHandle((el) => {
                    const children = Array.from(el.querySelectorAll('g'));
                    for (const child of children) {
                        if (child.hasAttribute('fill') && child.hasAttribute('stroke') && child.querySelector('path')) {
                            return child;
                        }
                    }
                    return null;
                });
                if (colorG) {
                    const fill = await colorG.evaluate((el) => el.getAttribute('fill'));
                    if (fill) {
                        legendNameToColor[legendName] = fill;
                    }
                }
            }
        }

        // Get pie chart colors in order
        const seriesGroup = container.locator('g[aria-label="Series"][role="group"]');
        const pieSlices = seriesGroup.locator('g[role="menuitem"][fill]');
        const pieSliceCount = await pieSlices.count();
        const pieColors: string[] = [];
        for (let i = 0; i < pieSliceCount; i++) {
            const fill = await pieSlices.nth(i).getAttribute('fill');
            if (fill) {
                pieColors.push(fill);
            }
        }

        // Get all tspan text content inside g tags that have child text tags
        const textGroups = container.locator('g:has(text tspan)');
        const textGroupCount = await textGroups.count();
        const pieValues: string[] = [];
        for (let i = 0; i < textGroupCount; i++) {
            const tspan = textGroups.nth(i).locator('text tspan');
            const tspanCount = await tspan.count();
            for (let j = 0; j < tspanCount; j++) {
                const text = (await tspan.nth(j).textContent())?.trim() || '';
                if (text) {
                    pieValues.push(text);
                }
            }
        }

        // Create JSON mapping legend names to values based on order of pieColors and pieValues
        const legendNames = Object.keys(legendNameToColor);
        const resultJson: Record<string, number> = {};
        for (let i = 0; i < legendNames.length; i++) {
            const name = legendNames[i];
            const valueText = pieValues[i] || '0';
            const value = parseFloat(valueText.replace('%', '')) || 0;
            resultJson[name] = value;
        }

        return resultJson;
    }

    //  * Validates if the percentages in legendData are correctly calculated based on tableData.
    //  * Considers only keys present in legendData for calculation.
    //  * Rounds percentages to 1 decimal place for comparison.
    //  * @param legendData - Object with keys as legend names and values as percentage values
    //  * @param tableData - Object with keys as legend names and values as absolute counts
    //  * @returns true if all percentages match correctly, false otherwise
    //  */
    public validateLegendPercentages(legendData: Record<string, number>, tableData: Record<string, number>): boolean {
        // Calculate total of relevant keys in tableData (keys present in legendData)
        const relevantKeys = Object.keys(legendData);
        const total = relevantKeys.reduce((sum, key) => sum + (tableData[key] || 0), 0);

        // Check each key's percentage
        for (const key of relevantKeys) {
            const absoluteValue = tableData[key] || 0;

            const expectedPercentage = total === 0 ? 0 : (absoluteValue / total) * 100;
            const roundedExpected = Math.round(expectedPercentage * 10) / 10; // 1 decimal place
            const actual = legendData[key];
            if (roundedExpected !== actual) {
                return false;
            }
        }
        return true;
    }

    public get claimsMain(): Locator {
        return this.page.locator('#claimsMain');
    }

    public get claimCountIncurredChart(): Locator {
        return this.page.locator('#claimCountIncurredChart');
    }

    public get occuranceCountTriangle(): Locator {
        return this.page.locator("//span[normalize-space()='Occurrence Count Triangle']");
    }

    public get insightsButton(): Locator {
        return this.page.getByRole('button', { name: 'INSIGHTS' });
    }

    public marketInsightsButton(): Locator {
        return this.page.locator('//button[contains(text(),"MARKET INSIGHTS")]');
    }

    public placementInsightsButton(): Locator {
        return this.page.locator('//button[contains(text(),"PLACEMENT INSIGHTS")]');
    }

    public claimsButton(): Locator {
        return this.page.locator('//div[contains(text(),"Claims")]');
    }

    public get marketButton(): Locator {
        return this.page.locator('//div[contains(text(),"Market")]')
    }

    public get claimcards(): Locator {
        return this.page.locator('//*[@id="claimsMain"]//ci-card-view');
    }

    public get claimsSummaryView(): Locator {
        return this.page.locator('//*[@id="claimCountIncurredChart"]//ci-toggle-button');

    }

    public get paidAnalysisBtn(): Locator {
        return this.page.locator('//button[text()=" Paid Analysis "]');

    }

    public get claimsDetailedViewBtn(): Locator {
        return this.page.locator("//button[normalize-space()='Detailed View']");

    }

    public get claimsSummaryViewBtn(): Locator {
        return this.page.locator("//button[normalize-space()='Summary View']");
    }
    public get pdfDownload(): Locator {
        return this.page.locator("//label[normalize-space()='Download as PDF']");
    }

    public get pngDownload(): Locator {
        return this.page.locator("//label[normalize-space()='Download as PNG']");
    }


    public get claimCountBtn(): Locator {
        return this.page.locator("//button[normalize-space()='Claim Count']");
    }

    public get claimIncurredBtn(): Locator {
        return this.page.locator("//button[normalize-space()='Claim Incurred']");
    }

    public get reserveAnalysisBtn(): Locator {
        return this.page.locator("//button[normalize-space()='Reserve Analysis']");
    }
    public get claimSummarybyPolicyYearbtn(): Locator {
        return this.page.locator("//span[normalize-space()='Claim Summary by Policy Year']");

    }
    public get occurrenceCountTrianglebtn(): Locator {
        return this.page.locator("//span[normalize-space()='Occurrence Count Triangle']");

    }

    public get byValuebtn(): Locator {
        return this.page.locator("//button[normalize-space()='By Value']");

    }

    public get byCountbtn(): Locator {
        return this.page.locator("//button[normalize-space()='By Count']");

    }

    public get claimValueDistributonDownload(): Locator {
        return this.page.locator("//*[@id='claimValuesDistributionReport']/ci-claim-summary-by-market/div/div[1]/div/div[2]/ci-menu-card/div");

    }

    public get lossPerilByYearDownload(): Locator {
        return this.page.locator("//*[@id='lossPerilByYearReport']/div/ci-menu-card/div");

    }
    public get lossPerilDownload(): Locator {
        return this.page.locator("//*[@id='perilCountReport']/ci-loss-peril-count-value-view/div/div[1]/div/div[3]/ci-menu-card/div");

    }


    public get incurredLossTrianglebtn(): Locator {
        return this.page.locator("//span[normalize-space()='Incurred Loss Triangle']");

    }

    public get claimCountAndIncurredDownload(): Locator {
        return this.page.locator("//*[@id='claimCountIncurredChart']/div[1]/div/ci-menu-card/div");

    }
    public get reserveAndPaidDownload(): Locator {
        return this.page.locator("//*[@id='analysisReport']/div/ci-reserve-paid-analysis-report/div/div[1]/ci-menu-card/div");
    }
    public get claimOccurrenceIncurredDownload(): Locator {
        return this.page.locator("//*[@id='claimSummaryByPolicyYearChart']/div/ci-menu-card/div");
    }

    public get claimSummaryByMarketDownload(): Locator {
        return this.page.locator("//*[@id='claimByMarketChart']/ci-claim-summary-by-market/div/div[1]/div/div/ci-menu-card/div");
    }

       public get claimValueDistributionLabel(): Locator {
        return this.page.locator("//label[normalize-space()='Claim Values Distribution']");

    }

    public get claimValueDistributionClaimIncurredLabel(): Locator {
        return this.page.locator("//label[normalize-space()='Total Incurred']");

    }

    public getClaimSummaryTableToggleButton(): Locator {
        return this.page.locator(`//*[@id="claimSummaryByPolicyYearChart"]//ci-customised-toggle-button//li`)
    }

    public claimsToggleButton(buttonText: string): Locator {
        return this.page.locator(`//ci-toggle-button//button[normalize-space()='${buttonText}']`)
    }

    public get claimSummaryTable(): Locator {
        return this.page.locator(`//*[@id="claimSummaryByPolicyYearChart"]//table[@role="table"]`)
    }

    public get claimSummaryTableDownloadButton(): Locator {
        return this.page.locator('//*[@id="claimSummaryByPolicyYearChart"]/div/ci-menu-card/div/img')
    }
    
    /**
    * Clicks on the insights and placement insights buttons.
    */
    public async navigateToPlacementInsights(): Promise<void> {
        //Todo: Need to work around these timeouts, currently this is a workaround
        await this.insightsButton.click();
        const clientPopup = new ClientSelectionPopup(this.page);
        // Handle intermittent client selection pop-up if it appears
        if (await clientPopup.isVisible()) {
            await clientPopup.selectClientByName('Scottsdale Inc (Demo)');
            await clientPopup.clickGo();
        }
        await this.page.waitForTimeout(10000);

        const placementInsightBtn = await this.page.locator('//button[contains(text(),"PLACEMENT INSIGHTS")]');
        await this.waitForVisible(placementInsightBtn);
        await placementInsightBtn.click();
        await this.page.waitForTimeout(5000);
        await this.marketInsightsButton().click();
         await this.page.waitForTimeout(5000)
         await placementInsightBtn.click();

    }

}
