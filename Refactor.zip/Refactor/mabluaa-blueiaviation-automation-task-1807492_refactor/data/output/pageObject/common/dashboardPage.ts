import { Locator, Page } from '@playwright/test';
import { BasePage } from '../BasePage';

export class DashboardPage extends BasePage {

    constructor(page: Page) {
        super(page)
    }

    public get dashboardMenu(): Locator {
        return this.page.locator("//ci-market-dashboard-reports//div[contains(@class, 'market-dashboard-menu-container')]")
    }

     public get placementDashboardMenu(): Locator {
        return this.page.locator("//ci-placement-analytics-reports//div[contains(@class, 'market-dashboard-menu-container')]")
    }


    
}
