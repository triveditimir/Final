import { Page, Locator, expect } from '@playwright/test';
import fs from 'fs';
import { BasePage } from '../BasePage';
//import { FileDownload } from '../../../src/ui/utils/fileDownload';


enum DownloadFormat {
    PNG = 'PNG',
    PDF = 'PDF'
}

/**
 * Abstract base class for common page functionalities.
 * Purpose: To provide shared methods like waitForVisible and getTooltipText.
 * Arguments: page (Page) - Playwright Page object.
 * Returns: None.
 */







/**
 * Retrieves tooltip text if visible.
 * Purpose: To get the tooltip text for validation or info.
 * Arguments: None.
 * Returns: Promise<string> - Tooltip text or empty string.
 */



/**
 * Class representing the Market Insights Page.
 * Purpose: To encapsulate all interactions and verifications on the page.
 * Arguments: page (Page) - Playwright Page object.
 * Returns: None.
 */
export class MarketInsightsPage extends BasePage {
    constructor(page: Page) {
        super(page);
        console.info('MarketInsightsPage initialized');
    }
    // fileDownload = new FileDownload(this.page);

    public filterContainer(filterName: string): Locator {
        return this.page.locator(`//*[@id="filterContainer"]//span[text()="${filterName}"]/parent::div`);
    }

    public filterContainerLocator(): Locator {
        return this.page.locator('#filterContainer');
    }

    public get filtersButton(): Locator {
        return this.page.locator('//av-filter-chips//button//span[text()="Filters"]');
    }

    public applyFilterButton(): Locator {
        return this.page.locator('#goBtn');
    }

    public get liabilityButton(): Locator {
        return this.page.locator('//div[contains(text(),"Liability")]')
    }

    public get marketButton(): Locator {
        return this.page.locator('//div[contains(text(),"Market")]')
    }

    public get warningMsg(): Locator {
        return this.page.locator("//div[contains(@class, 'warning-message') and contains(text(), 'Insufficient Data')]")
    }


    public async uncheckCommercialBusinessType(): Promise<void> {
        const filterByBusinessType = this.page.locator('//input[@value="Commercial"]/parent::label')
        await filterByBusinessType.click();
        await this.page.waitForTimeout(5000);
        await this.page.locator('//button[text()="Apply Filters"]').click();
    }

    public async checkCommercialBusinessType(): Promise<void> {
        const filterByBusinessType = this.page.locator('//input[@value="Commercial"]/parent::label')
        await filterByBusinessType.click();
        await this.page.locator('//button[text()="Apply Filters"]').click();
    }

    // Element locators with logs
    public get colleagueLoginLink(): Locator {
        console.info('Locating Colleague Login Link');
        return this.page.locator("//span[normalize-space()='Colleague login']");
    }

    public get insightsButton(): Locator {
        console.info('Locating Insights Button');
        return this.page.locator('//button[normalize-space()="INSIGHTS"][1]');
    }

    public get insightsmat(): Locator {
        console.info('Locating Insights Mat');
        return this.page.locator('//body//ci-root//mat-card[1]');
    }

    public get globalHeader(): Locator {
        console.info('Locating Global Header');
        return this.page.locator('.logo-white-text');
    }

    public get buttonAverageCommissionLevelAgainstTarget(): Locator {
        console.info('Locating Button: Average Commission Level Against Target');
        return this.page.locator(""); // Placeholder, add actual locator
    }

    public async clickResetAllFilterButton(): Promise<void> {
        await this.resetAllFilterButton.click()
        await this.page.waitForTimeout(8000);
    }
    // Example method for a radio button
    public async getRadioPlus(): Promise<void> {
        console.info('Locating Radio: "+"');
        await this.page.locator("//input[@value='2+']").click;
    }

    // Example method for "Industrial Aid" checkbox
    public async getCheckboxIndustrialAid(): Promise<void> {
        console.info('Locating Checkbox: Industrial Aid');
        await this.page.locator("//input[@value='Industrial Aid']").click;
    }

    // Example method for "Commercial" checkbox
    public async getCheckboxCommercial(): Promise<void> {
        console.info('Locating Checkbox: Commercial');
        await this.page.locator("//input[@value='Commercial']").click;
    }

    // Method for "Jet Engine" checkbox
    public async getCheckboxJetEngine(): Promise<void> {
        console.info('Locating Checkbox: Jet Engine');
        await this.page.locator("//input[@value='Jet Engine']").click;
    }

    // Method for "2024" checkbox
    public async getCheckbox2024(): Promise<void> {
        console.info('Locating Checkbox: 2024');
        await this.page.locator("//input[@value='2024']").click;
    }

    // Method for "2025" checkbox
    public async getCheckbox2025(): Promise<void> {
        console.info('Locating Checkbox: 2025');
        await this.page.locator("//input[@value='2025']").click;
    }

    // Method for "Q1" checkbox
    public async getCheckboxQ1(): Promise<void> {
        console.info('Locating Checkbox: Q1');
        await this.page.locator("//input[@value='Q1']").click;
    }

    /**
     * Gets the "Starr" text from Graph.
     * Arguments: None.
     * Returns: Promise<Locator>
     */
    public async getHullStarr(): Promise<Locator> {
        console.info('Getting Market Business Breakdown button');
        return this.page.locator("//div[@id='yearChangeHullRate']//div//*[name()='svg']//*[name()='g']//*[name()='g']//*[name()='g' and contains(@role,'region')]//*[name()='g' and contains(@transform,'translate(')]//*[name()='g']//*[name()='g']//*[name()='g' and contains(@role,'group')]//*[name()='g']//*[name()='g' and contains(@role,'switch')]//*[name()='g' and contains(@transform,'translate(')]//*[name()='g' and contains(@fill,'#000000')]//*[name()='text']//*[name()='tspan' and text()='Starr']");
    }

    /**
     * Gets the "Market Business Breakdown" button.
     * Purpose: To interact with the button for navigation or actions.
     * Arguments: None.
     * Returns: Promise<Locator>
     */
    public get buttonMarketBusinessBreakdown(): Locator {
        console.info('Getting Market Business Breakdown button');
        return this.page.locator("//button[normalize-space()='Market Business Breakdown']");
    }

    /**
     * Gets the "Market Distribution by Premium" button.
     * Purpose: To interact with the button for navigation or actions.
     * Arguments: None.
     * Returns: Promise<Locator>
     */
    public get buttonMarketDistributtonbyPremium(): Locator {
        console.info('Getting Market Distribution by Premium button');
        return this.page.locator("//button[normalize-space()='Market Distribution by Premium']");
    }




    // Additional locators with logs
    public get hullPageHeading(): Locator {
        console.info('Locating Hull Page Heading');
        return this.page.locator("//*[@id='HullMain']/div[1]/ci-placement-analytics-header/div/div[1][contains(text(), 'Aviation Insights')]");
    }

    public get underWriterPageHeading(): Locator {
        console.info('Locating UnderWriter Page Heading');
        return this.page.locator("//*[@id='UnderWriterMain']/div[1]/ci-placement-analytics-header/div/div[1][contains(text(), 'Aviation Insights')]");
    }

    public get hullGraphHeading(): Locator {
        console.info('Locating Hull Graph Heading');
        return this.page.locator("//label[normalize-space()='Year over Year Change Hull Rate'][contains(text(), 'Year over Year Change Hull Rate')]");
    }

    public get hullYears(): Locator {
        console.info('Locating Hull Years');
        return this.page.locator("//span[contains(text(),'2024')]");
    }

    public get hullRateAverage_GraphHeading(): Locator {
        console.info('Locating Hull Rate Average Graph Heading');
        return this.page.locator("//label[normalize-space()='Hull Rate Average'][contains(text(), 'Hull Rate Average')]");
    }

    public get hullRateAverageBottom_GraphHeading(): Locator {
        console.info('Locating Hull Rate Δ % Average Graph Heading');
        return this.page.locator("//label[contains(text(),'Hull Rate Δ % Average')][contains(text(), 'Hull Rate Δ % Average')]");
    }

    public get button_LostBusinessByMarket(): Locator {
        console.info('Locating Lost Business By Market Button');
        return this.page.locator("//button[normalize-space()='Lost Business By Market']");
    }

    public get chartSelectionDropDownfirst(): Locator {
        console.info('Locating Chart Selection');
        return this.page.locator("//*[@id='chart1']/div[2]/div/p-dropdown/div/div[2]");
    }

    public get chartAirCraftLost(): Locator {
        console.info('Locating Air Craft Lost Chart');
        return this.page.locator("//span[normalize-space()='Aircraft Lost By Market']");
    }

    public get chartClientLost(): Locator {
        console.info('Locating Clients Lost By Market Chart');
        return this.page.locator("//span[normalize-space()='Clients Lost By Market']");
    }

    public get chartLostBusiness(): Locator {
        console.info('Locating Lost Business By Market Chart');
        return this.page.locator("//span[normalize-space()='Lost Business By Market']");
    }

    public get chartTotalPremium(): Locator {
        console.info('Locating Total Premium Lost By Market Chart');
        return this.page.locator("//span[normalize-space()='Total Premium Lost By Market']");
    }

    public get chartQuotaShareAverageLineSize(): Locator {
        console.info('Locating Quota Share Average Line Size');
        return this.page.locator("//span[normalize-space()='Quota Share Average Line Size']");
    }

    public get chartQuotaShareMedianLineSize(): Locator {
        console.info('Locating Quota Share Median Line Size');
        return this.page.locator("//span[normalize-space()='Quota Share Median Line Size']");
    }

    public get chartLeadMarketsByMarket(): Locator {
        console.info('Locating Lead Markets By Market Chart');
        return this.page.locator("//span[normalize-space()='Lead Markets By Market']");
    }

    public get chartTotalQSPremiumbyMarket(): Locator {
        console.info('Locating Total QS Premium by Market Chart');
        return this.page.locator("//span[normalize-space()='Total QS Premium by Market']");
    }

    public get chartAvgQSPremiumbyMarket(): Locator {
        console.info('Locating Avg QS Premium by Market Chart');
        return this.page.locator("//span[normalize-space()='Avg QS Premium by Market']");
    }
    public get chartQSParticipantsbyTotalQSAircraft(): Locator {
        console.info('Locating QS Participants by Total QS Aircraft Chart');
        return this.page.locator("//span[normalize-space()='QS Participants by Total QS Aircraft']");
    }
    public get chartQSParticipantsbyClient(): Locator {
        console.info('Locating Avg QS Premium by Market Chart');
        return this.page.locator("//span[normalize-space()='QS Participants by Client']");
    }


    public get chartMarketDistributionbyAircraftPercent(): Locator {
        console.info('Locating Total Premium Lost By Market Chart');
        return this.page.locator("//span[normalize-space()='Market Distribution by Aircraft Percent']");
    }

    public get downloadsecond(): Locator {
        console.info('Locating Total Premium Lost By Market Chart');
        return this.page.locator("//*[@id='chart2']/div[1]/ci-menu-card/div/img");
    }



    public get downloadfirst(): Locator {
        console.info('Locating Download Option');
        return this.page.locator("//*[@id='chart1']/div[1]/ci-menu-card/div/img");
    }

    public get chartSelectionDropDownSecond(): Locator {
        console.info('Locating Chart Selection');
        return this.page.locator("//*[@id='chart2']/div[2]/div/p-dropdown/div/div[2]");
    }

    public get marketPageHeading(): Locator {
        console.info('Locating Market Page Heading');
        return this.page.locator("//*[@id='MarketMain']/div[1]/ci-placement-analytics-header/div/div[1][contains(text(), 'Aviation Insights')]");
    }

    public get menuHeader(): Locator {
        console.info('Locating Menu Header');
        return this.page.locator('//div[@class="ext-menu"]//div');
    }

    public get section(): Locator {
        console.info('Locating Section');
        return this.page.locator('.card-body');
    }

    public get placementInsightsHeader(): Locator {
        console.info('Locating Placement Insights Header');
        return this.page.locator('text=PLACEMENT INSIGHTS');
    }

    public get downloadButtonPrimary(): Locator {
        console.info('Locating Primary Download Button');
        return this.page.locator("//*[@id='chart1']/div/ci-menu-card/div/img");
    }

    public get downloadButtonSecondary(): Locator {
        console.info('Locating Secondary Download Button');
        return this.page.locator("//*[@id='chart2']/div/ci-menu-card/div/img");
    }

    public get downloadButtonclaimCountIncurredChart(): Locator {
        console.info('Locating Market Primary Download Button');
        return this.page.locator("//*[@id='claimCountIncurredChart']/div[1]/div/ci-menu-card/div[1]");
    }

    public get downloadButtonanalysisReport(): Locator {
        console.info('Locating Market Primary Download Button');
        return this.page.locator("//*[@id='analysisReport']/div/ci-reserve-paid-analysis-report/div/div[1]/ci-menu-card/div");
    }

    public get downloadButtonclaimSummaryByPolicyYearChart(): Locator {
        console.info('Locating Market Primary Download Button');
        return this.page.locator("//*[@id='claimSummaryByPolicyYearChart']/div/ci-menu-card/div");
    }

    public get downloadButtonclaimByMarketChart(): Locator {
        console.info('Locating Market Primary Download Button');
        return this.page.locator("//*[@id='claimByMarketChart']/ci-claim-summary-by-market/div/div[1]/div/div/ci-menu-card/div");
    }

    public get downloadButtonMarketPrimary(): Locator {
        console.info('Locating Market Primary Download Button');
        return this.page.locator("//*[@id='chart1']/div[1]/ci-menu-card/div/img");
    }

    public get downloadButtonMarketSecondary(): Locator {
        console.info('Locating Market Secondary Download Button');
        return this.page.locator("//*[@id='chart2']/div[1]/ci-menu-card/div/img");
    }
    public get downloadButtonUnderwritePrimary(): Locator {
        console.info('Locating Underwrite Primary Download Button');
        return this.page.locator("//*[@id='chart1']/div/div[2]/ci-menu-card/div/img");
    }
    public get downloadButtonProspects(): Locator {
        console.info('Locating Prospects Primary Download Button');
        return this.page.locator("//*[@id='prospectMain']/div[1]/ci-placement-analytics-header/div/div[2]/div/div/button/ci-menu-card/div/img");
    }

    public get downloadButtonUnderwriteSecondary(): Locator {
        console.info('Locating Underwrite Secondary Download Button');
        return this.page.locator("//*[@id='chart2']/div/div[2]/ci-menu-card/div/img");
    }
    public get downloadButtonLiabilityPrimary(): Locator {

        console.info('Locating Market Primary Download Button');
        return this.page.locator("//*[@id='chart1']/div[1]/ci-menu-card/div");
    }

    public get downloadButtonLiabilitySecondary(): Locator {
        console.info('Locating Market Secondary Download Button');
        return this.page.locator("//*[@id='chart2']/div[1]/ci-menu-card/div");
    }

    public get downloadButtonperilCountReport(): Locator {
        console.info('Locating Market Secondary Download Button');
        return this.page.locator("//*[@id='perilCountReport']/ci-loss-peril-count-value-view/div/div[1]/div/div[3]/ci-menu-card/div");
    }
    public get downloadButtonclaimValuesDistributionReport(): Locator {
        console.info('Locating Market Secondary Download Button');
        return this.page.locator("//*[@id='claimValuesDistributionReport']/ci-claim-summary-by-market/div/div[1]/div/div[2]/ci-menu-card/div");
    }
    public get downloadButtonlossPerilByYearReport(): Locator {
        console.info('Locating Market Secondary Download Button');
        return this.page.locator("//*[@id='lossPerilByYearReport']/div/ci-menu-card/div");
    }




    public get downloadPNGButton(): Locator {
        console.info('Locating Download PNG Button');
        return this.page.locator("//label[normalize-space()='Download as PNG']");
    }

    public get downloadPDFButton(): Locator {
        console.info('Locating Download PDF Button');
        return this.page.locator("//label[normalize-space()='Download as PDF']");
    }

    public get selectClient(): Locator {
        console.info('Locating Client Selection Input');
        return this.page.locator("//input[@name='companyData']");
    }

    public get goClient(): Locator {
        console.info('Locating Go Button for Client');
        return this.page.locator("//button[contains(text(), 'Go')]");
    }

    public get placementAnalyticsReports(): Locator {
        console.info('Locating Placement Analytics Reports');
        return this.page.locator('ci-placement-analytics-reports');
    }

    public get marketInsightsButton(): Locator {
        console.info('Locating Market Insights Button');
        return this.page.getByRole('button', { name: 'MARKET INSIGHTS' });
    }

    public get prospectsButtonLink(): Locator {
        console.info('Locating Prospects Button Link');
        return this.page.locator("(//button[normalize-space()='PROSPECTS'])[1]");
    }

    public get placementInsightsButtonLink(): Locator {
        console.info('Locating Placement Insights Button Link');
        return this.page.locator("(//button[normalize-space()='PLACEMENT INSIGHTS'])[1]");
    }

    public get marketDashboardReports(): Locator {
        console.info('Locating Market Dashboard Reports');
        return this.page.locator('ci-market-dashboard-reports');
    }

    public get chart1(): Locator {
        console.info('Locating Chart 1');
        return this.page.locator('#chart1');
    }

    public get sliderValueClick(): Locator {
        console.info('Locating Slider Value Click');
        return this.page.locator('//*[@id="chart1"]/div[2]/div[2]/div/ci-customise-slider/div/div/div[1]/label');
    }

    public get sliderValueEnter(): Locator {
        console.info('Locating Slider Value Input');
        return this.page.locator('//*[@id="chart1"]/div[2]/div[2]/div/ci-customise-slider/div/div/div[1]/input');
    }

    public get cardValue(): Locator {
        console.info('Locating Card Value');
        return this.page.locator('.card-value.pt-1');
    }

    public get aircraftOption(): Locator {
        console.info('Locating Aircraft Option');
        return this.page.getByText('Aircraft');
    }

    public get aviationInsightsLabel(): Locator {
        console.info('Locating Aviation Insights Label');
        return this.page.locator('//ci-placement-analytics-header//div[text()=" Aviation Insights "]');
    }

    public get clickonHull(): Locator {
        console.info('Locating Hull Button');
        return this.page.locator("//div[contains(text(),'Hull')]");
    }

    public get clickonMarket(): Locator {
        console.info('Locating Market Button');
        return this.page.locator("//div[contains(text(),'Market')]");
    }

    public get marketInsightToggleBtn(): Locator {
        return this.page.locator("//ci-toggle-button//button")
    }

    public get hullInsightToggleBtn(): Locator {
        return this.page.locator("//ci-toggle-button//button")
    }

    public get liabilityPremiumToggleBtn(): Locator {
        return this.page.locator("//ci-toggle-button//button[normalize-space()='Liability Premium']")
    }

    public get clickonUnderwriter(): Locator {
        console.info('Locating Underwriter Button');
        return this.page.locator("//div[contains(text(),'Underwriter')]");
    }

    public get underWriterToggleBtn(): Locator {
        return this.page.locator("//ci-toggle-button//button")
    }

    public get hull(): Locator {
        console.info('Locating Hull Element');
        return this.page.locator("//div[contains(text(),'Hull')]");
    }

    public get RSM(): Locator {
        console.info('Locating RSM Element');
        return this.page.locator("//div[contains(text(),'RSM')]");
    }

    /**
     * Gets the "Annual Hull Rate Trend" button.
     * Purpose: To interact with the button for navigation.
     * Arguments: None.
     * Returns: Promise<Locator>
     */
    public async getButtonAnnualHullRateTrend(): Promise<Locator> {
        console.info('Getting Annual Hull Rate Trend button');
        return this.page.locator("//button[normalize-space()='Annual Hull Rate Trend']");
    }

    /**
     * Gets the "Average Commission Level Against Target" button.
     * Purpose: To interact with the button for navigation.
     * Arguments: None.
     * Returns: Promise<Locator>
     */
    public get buttonMarketverageCommissionLevelTaret(): Locator {
        console.info('Getting Average Commission Level Against Target button');
        return this.page.locator("//button[normalize-space()='Average Commission Level Against Target (17.5%)']");
    }

    public get buttonAnnualAverageNetLiability(): Locator {
        console.info('Getting AnnualAverageNetLiability button');
        return this.page.locator("//button[normalize-space()='Annual Average Net Liability']");
    }






    /**
     * Gets the "Average Hull Rate" button.
     * Purpose: To interact with the button for navigation.
     * Arguments: None.
     * Returns: Promise<Locator>
     */
    public async getButtonAverageHullRate(): Promise<Locator> {
        console.info('Getting Average Hull Rate button');
        return this.page.locator("//button[normalize-space()='Average Hull Rate']");
    }
    public get buttonLiabilityPremium(): Locator {
        console.info('Getting Annual Hull Rate Trend button');
        return this.page.locator("(//button[normalize-space(text())='Liability Premium'])[1]");
    }

    public async getButtonLiabilityPremiumSecondary(): Promise<Locator> {
        console.info('Getting Annual Hull Rate Trend button');
        return this.page.locator("(//button[normalize-space(text())='Liability Premium'])[2]");
    }

    public get filterButton(): Locator {
        console.info('Locating Filter Button');
        return this.page.locator("//div[@class='filter-chips-wrapper d-flex flex-wrap']//button[contains(.,'Filters')]");
    }

    public get sliderHullValueFilter(): Locator {
        console.info('Locating Hull Value Filter Slider');
        return this.page.locator("//*[@id='filterOption.keyValue']/div/div/div[1]/label");
    }

    public get sliderValuefill(): Locator {
        console.info('Locating Slider Value Input');
        return this.page.locator("//*[@id='filterOption.keyValue']/div/div/div[1]/input");
    }

    public get clickonHulllValue(): Locator {
        console.info('Locating Hull Value Button');
        return this.page.locator("//span[normalize-space()='Hull Value']");
    }

    public get filterOption(): Locator {
        console.info('Locating Filter Option Container');
        return this.page.locator("//div[@id='filterContainer']");
    }
    public get clickonFilters(): Locator {
        console.info('Locating Filters Button');
        return this.page.locator("//button[@class='filter-chip d-flex align-items-center flex-row justify-content-center outline-btn']");
    }

    public async clickonFilter(): Promise<void> {
        console.info('Hull clicking ');
        await this.page.locator("//button[@class='filter-chip d-flex align-items-center flex-row justify-content-center outline-btn']").click();
    }

    public get clickonApplyFilters(): Locator {
        console.info('Locating Apply Filters Button');
        return this.page.locator("//button[@id='goBtn']");
    }

    public get allFilterButtons(): Locator {
        console.info('Locating All Filter Buttons');
        return this.page.locator("//div[@class='filter-chips-wrapper d-flex flex-wrap']//button");
    }

    /**
     * Downloads a chart in specified format.
     * Purpose: To automate chart download process.
     * Arguments:
     *  - format (DownloadFormat): PNG or PDF.
     *  - chartSelector (string): XPath selector for the chart.
     *  - downloadButton (any): Locator or element for download button.
     *  - downloadLabelSelector (string): XPath for download label.
     *  - downloadMethod (function): Function to perform download.
     * Returns: Promise<string> - Path to downloaded file.
     */

    // public async downloadChart(
    //     format: DownloadFormat,
    //     chartSelector: string,
    //     downloadButton: any,
    //     downloadLabelSelector: string,
    //     downloadMethod: () => Promise<string>
    // ): Promise<string> {
    //     console.info(`Starting download of chart in format: ${format}`);
    //     if (!this.fileDownload) {
    //         console.warn('FileDownload is not initialized');
    //         throw new Error('FileDownload is not initialized');
    //     }

    //     // Wait for the chart element
    //     console.info(`Waiting for chart element: ${chartSelector}`);
    //     await this.page.waitForSelector(chartSelector, { timeout: 10000 });

    //     // Click the main download button
    //     console.info('Clicking main download button');
    //     await this.fileDownload.performDownloadClick(downloadButton);

    //     // Create a locator for the label
    //     const labelLocator = this.page.locator(`//label[normalize-space()='Download as ${format}']`);
    //     console.info(`Waiting for download label: Download as ${format}`);
    //     await labelLocator.waitFor({ timeout: 10000 });

    //     // Click the format-specific download option
    //     console.info(`Clicking download label for format: ${format}`);
    //     await this.fileDownload.performDownloadClick(labelLocator);

    //     // Call the download method
    //     const filePath = await downloadMethod.call(this.fileDownload);
    //     console.info(`Downloaded file path: ${filePath}`);

    //     // Wait for the file to exist
    //     await this.waitForFileExistence(filePath);
    //     console.info(`File exists: ${filePath}`);

    //     return filePath;
    // }

    /**
     * Utility to wait for a file to exist.
     * Arguments:
     *  - filePath (string): Path to file.
     *  - retries (number): Number of retries.
     *  - delayMs (number): Delay between retries in ms.
     * Returns: Promise<void>
     */
    public async waitForFileExistence(filePath: string, retries = 10, delayMs = 500): Promise<void> {
        console.info(`Waiting for file existence: ${filePath}`);
        for (let i = 0; i < retries; i++) {
            if (fs.existsSync(filePath)) {
                console.info(`File found: ${filePath}`);
                return;
            }
            console.warn(`File not found, retry ${i + 1}/${retries}`);
            await new Promise(res => setTimeout(res, delayMs));
        }
        console.error(`File not found after retries: ${filePath}`);
        throw new Error(`File not found after retries: ${filePath}`);
    }

    // /**
    //  * Downloads a chart as PDF based on choice.
    //  * Arguments:
    //  *  - choice ('chart1' | 'chart2' | 'chart3' | 'chart4'): Which chart to download.
    //  * Returns: Promise<void>
    //  */
    // public async downloadChartPDF(choice: 'chart1' | 'chart2' | 'chart3' | 'chart4' | 'chart5' | 'chart6' | 'chart7' | 'chart8' | 'chart9' | 'chart10'| 'chart11'| 'chart12'| 'chart13'| 'chart14'| 'chart15'| 'chart16'): Promise<void> {
    //     console.info(`Downloading chart PDF for choice: ${choice}`);
    //     // Define the XPaths and buttons
    //     const chart1XPath = "//*[@id='chart1']/div/ci-menu-card/div/img";
    //     const chart2XPath = "//*[@id='chart2']/div/ci-menu-card/div/img";
    //     const chart3xpath = "//*[@id='chart1']/div[1]/ci-menu-card/div/img";
    //     const chart4xpath = "//*[@id='chart2']/div[1]/ci-menu-card/div/img";
    //     const chart5xpath = "//*[@id='chart1']/div/div[2]/ci-menu-card/div/img";
    //     const chart6xpath = "//*[@id='chart2']/div/div[2]/ci-menu-card/div/img";
    //     const chart7xpath = "//*[@id='prospectMain']/div[1]/ci-placement-analytics-header/div/div[2]/div/div/button/ci-menu-card/div/img";
    //     const chart8xpath = "//*[@id='chart1']/div[1]/ci-menu-card/div";
    //     const chart9xpath = "//*[@id='chart2']/div[1]/ci-menu-card/div";
    //     const chart10xpath = "//*[@id='claimCountIncurredChart']/div[1]/div/ci-menu-card/div[1]";
    //     const chart11xpath = "//*[@id='analysisReport']/div/ci-reserve-paid-analysis-report/div/div[1]/ci-menu-card/div";
    //     const chart12xpath = "//*[@id='claimSummaryByPolicyYearChart']/div/ci-menu-card/div";
    //     const chart13xpath ="//*[@id='claimByMarketChart']/ci-claim-summary-by-market/div/div[1]/div/div/ci-menu-card/div";
    //     const chart14xpath ="//*[@id='perilCountReport']/ci-loss-peril-count-value-view/div/div[1]/div/div[3]/ci-menu-card/div";
    //     const chart15xpath ="//*[@id='claimValuesDistributionReport']/ci-claim-summary-by-market/div/div[1]/div/div[2]/ci-menu-card/div";
    //     const chart16xpath="//*[@id='lossPerilByYearReport']/div/ci-menu-card/div";


    //     let filePath: string;

    //     switch (choice) {
    //         case 'chart1':
    //             {
    //                 console.info('Processing Chart 1');
    //                 const chart1Element = await this.page.$(chart1XPath);
    //                 if (chart1Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart1XPath,
    //                         this.downloadButtonPrimary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 1 PDF...');
    //                 } else {
    //                     console.warn('Chart 1 not found on the page.');
    //                     throw new Error('Chart 1 not found on the page.');
    //                 }
    //             }
    //             break;

    //         case 'chart2':
    //             {
    //                 console.info('Processing Chart 2');
    //                 const chart2Element = await this.page.$(chart2XPath);
    //                 if (chart2Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart2XPath,
    //                         this.downloadButtonSecondary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 2 PDF...');
    //                 } else {
    //                     console.warn('Chart 2 not found on the page.');
    //                     throw new Error('Chart 2 not found on the page.');
    //                 }
    //             }
    //             break;

    //         case 'chart3':
    //             {
    //                 console.info('Processing Chart 3');
    //                 const chart3Element = await this.page.$(chart3xpath);
    //                 if (chart3Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart3xpath,
    //                         this.downloadButtonMarketPrimary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 3 PDF...');
    //                 } else {
    //                     console.warn('Chart 3 not found on the page.');
    //                     throw new Error('Chart 3 not found on the page.');
    //                 }
    //             }
    //             break;

    //         case 'chart4':
    //             {
    //                 console.info('Processing Chart 4');
    //                 const chart4Element = await this.page.$(chart4xpath);
    //                 if (chart4Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart4xpath,
    //                         this.downloadButtonMarketSecondary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 4 PDF...');
    //                 } else {
    //                     console.warn('Chart 4 not found on the page.');
    //                     throw new Error('Chart 4 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart5':
    //             {
    //                 console.info('Processing Chart 5');
    //                 const chart5Element = await this.page.$(chart5xpath);
    //                 if (chart5Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart5xpath,
    //                         this.downloadButtonUnderwritePrimary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 5 PDF...');
    //                 } else {
    //                     console.warn('Chart 5 not found on the page.');
    //                     throw new Error('Chart 5 not found on the page.');
    //                 }
    //             }
    //             break;

    //         case 'chart6':
    //             {
    //                 console.info('Processing Chart 6');
    //                 const chart6Element = await this.page.$(chart6xpath);
    //                 if (chart6Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart6xpath,
    //                         this.downloadButtonUnderwriteSecondary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 6 PDF...');
    //                 } else {
    //                     console.warn('Chart 6 not found on the page.');
    //                     throw new Error('Chart 6 not found on the page.');
    //                 }
    //             }
    //             break;

    //         case 'chart7':
    //             {
    //                 console.info('Processing Chart 7');
    //                 const chart7Element = await this.page.$(chart7xpath);
    //                 if (chart7Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart7xpath,
    //                         this.downloadButtonProspects,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 7 PDF...');
    //                 } else {
    //                     console.warn('Chart 7 not found on the page.');
    //                     throw new Error('Chart 7 not found on the page.');
    //                 }
    //             }
    //             break;

    //         case 'chart8':
    //             {
    //                 console.info('Processing Chart 8');
    //                 const chart8Element = await this.page.$(chart8xpath);
    //                 if (chart8Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart8xpath,
    //                         this.downloadButtonLiabilityPrimary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 8 PDF...');
    //                 } else {
    //                     console.warn('Chart 8 not found on the page.');
    //                     throw new Error('Chart 8 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart9':
    //             {
    //                 console.info('Processing Chart 9');
    //                 const chart9Element = await this.page.$(chart9xpath);
    //                 if (chart9Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart9xpath,
    //                         this.downloadButtonLiabilitySecondary,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 9 PDF...');
    //                 } else {
    //                     console.warn('Chart 9 not found on the page.');
    //                     throw new Error('Chart 9 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart10':
    //             {
    //                 console.info('Processing Chart 9');
    //                 const chart10Element = await this.page.$(chart10xpath);
    //                 if (chart10Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart10xpath,
    //                         this.downloadButtonclaimCountIncurredChart,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 10 PDF...');
    //                 } else {
    //                     console.warn('Chart 10 not found on the page.');
    //                     throw new Error('Chart 10 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart11':
    //             {
    //                 console.info('Processing Chart 9');
    //                 const chart11Element = await this.page.$(chart11xpath);
    //                 if (chart11Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart11xpath,
    //                         this.downloadButtonanalysisReport,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 11 PDF...');
    //                 } else {
    //                     console.warn('Chart 11 not found on the page.');
    //                     throw new Error('Chart 11 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart12':
    //             {
    //                 console.info('Processing Chart 12');
    //                 const chart12Element = await this.page.$(chart12xpath);
    //                 if (chart12Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart12xpath,
    //                         this.downloadButtonclaimSummaryByPolicyYearChart,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 12 PDF...');
    //                 } else {
    //                     console.warn('Chart 12 not found on the page.');
    //                     throw new Error('Chart 12 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart13':
    //             {
    //                 console.info('Processing Chart 13');
    //                 const chart13Element = await this.page.$(chart13xpath);
    //                 if (chart13Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart13xpath,
    //                         this.downloadButtonclaimByMarketChart,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 13 PDF...');
    //                 } else {
    //                     console.warn('Chart 13 not found on the page.');
    //                     throw new Error('Chart 13 not found on the page.');
    //                 }
    //             }
    //             break;

    //             case 'chart14':
    //             {
    //                 console.info('Processing Chart 14');
    //                 const chart14Element = await this.page.$(chart14xpath);
    //                 if (chart14Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart14xpath,
    //                         this.downloadButtonperilCountReport,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 14 PDF...');
    //                 } else {
    //                     console.warn('Chart 14 not found on the page.');
    //                     throw new Error('Chart 14 not found on the page.');
    //                 }
    //             }
    //             break;
    //             case 'chart15':
    //             {
    //                 console.info('Processing Chart 15');
    //                 const chart15Element = await this.page.$(chart15xpath);
    //                 if (chart15Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart15xpath,
    //                         this.downloadButtonclaimValuesDistributionReport,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 15 PDF...');
    //                 } else {
    //                     console.warn('Chart 15 not found on the page.');
    //                     throw new Error('Chart 15 not found on the page.');
    //                 }
    //             }
    //             break;
    //             case 'chart16':
    //             {
    //                 console.info('Processing Chart 16');
    //                 const chart16Element = await this.page.$(chart16xpath);
    //                 if (chart16Element) {
    //                     filePath = await this.downloadChart(
    //                         DownloadFormat.PDF,
    //                         chart16xpath,
    //                         this.downloadButtonlossPerilByYearReport,
    //                         "//label[normalize-space()='Download as PDF']",
    //                         this.fileDownload.downloadAndSavePDF
    //                     );
    //                     console.info('Downloading Chart 16 PDF...');
    //                 } else {
    //                     console.warn('Chart 16 not found on the page.');
    //                     throw new Error('Chart 16 not found on the page.');
    //                 }
    //             }
    //             break;
    //         default:
    //             console.error('Invalid choice provided for PDF download');
    //             throw new Error('Invalid choice provided.');
    //     }

    //     // Validate PDF content
    //     const pdfText = await FileDownload.extractTextFromPDF(filePath);
    //     const generatedText = this.getGeneratedOnDateString();
    //     expect(pdfText).toContain(generatedText);
    //     console.info('PDF contains generated date:', generatedText);

    //     // Capture screenshot of latest PDF pages
    //     //await this.fileDownload.openLatestPDFCaptureScreenshot();
    //     await this.page.waitForTimeout(5000);
    // }

    // /**
    //  * Downloads a chart as PNG based on choice.
    //  * Arguments:
    //  *  - choice ('chart1' | 'chart2' | 'chart3' | 'chart4'): Which chart to download.
    //  * Returns: Promise<string> - Path to the PNG file.
    //  */
    // public async downloadChartPNG(choice: 'chart1' | 'chart2' | 'chart3' | 'chart4' | 'chart5' | 'chart6' | 'chart7'| 'chart8'| 'chart9' | 'chart10'| 'chart11'| 'chart12'| 'chart13'| 'chart14'| 'chart15'| 'chart16'): Promise<string> {
    //     console.info(`Downloading chart PNG for choice: ${choice}`);
    //     // Define the XPaths for each chart
    //     const chart1XPath = "//*[@id='chart1']/div/ci-menu-card/div/img";
    //     const chart2XPath = "//*[@id='chart2']/div/ci-menu-card/div";
    //     const chart3xpath = "//*[@id='chart1']/div[1]/ci-menu-card/div/img";
    //     const chart4xpath = "//*[@id='chart2']/div[1]/ci-menu-card/div/img";
    //     const chart5xpath = "//*[@id='chart1']/div/div[2]/ci-menu-card/div/img";
    //     const chart6xpath = "//*[@id='chart2']/div/div[2]/ci-menu-card/div/img";
    //     const chart7xpath = "//*[@id='prospectMain']/div[1]/ci-placement-analytics-header/div/div[2]/div/div/button/ci-menu-card/div/img";
    //     const chart8xpath = "//*[@id='chart1']/div[1]/ci-menu-card/div";
    //     const chart9xpath = "//*[@id='chart2']/div[1]/ci-menu-card/div";
    //     const chart10xpath = "//*[@id='claimCountIncurredChart']/div[1]/div/ci-menu-card/div[1]";
    //     const chart11xpath = "//*[@id='analysisReport']/div/ci-reserve-paid-analysis-report/div/div[1]/ci-menu-card/div";
    //     const chart12xpath= "//*[@id='claimSummaryByPolicyYearChart']/div/ci-menu-card/div";
    //     const chart13xpath="//*[@id='claimByMarketChart']/ci-claim-summary-by-market/div/div[1]/div/div/ci-menu-card/div";
    //     const chart14xpath ="//*[@id='perilCountReport']/ci-loss-peril-count-value-view/div/div[1]/div/div[3]/ci-menu-card/div";
    //     const chart15xpath ="//*[@id='claimValuesDistributionReport']/ci-claim-summary-by-market/div/div[1]/div/div[2]/ci-menu-card/div";
    //     const chart16xpath="//*[@id='lossPerilByYearReport']/div/ci-menu-card/div";


    //     switch (choice) {
    //         case 'chart1':
    //             {
    //                 console.info('Processing Chart 1');
    //                 const chartSelector = chart1XPath;
    //                 const mainButton = this.downloadButtonPrimary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }
    //         case 'chart2':
    //             {
    //                 console.info('Processing Chart 2');
    //                 const chartSelector = chart2XPath;
    //                 const mainButton = this.downloadButtonSecondary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }
    //         case 'chart3':
    //             {
    //                 console.info('Processing Chart 3');
    //                 const chartSelector = chart3xpath;
    //                 const mainButton = this.downloadButtonMarketPrimary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }
    //         case 'chart4':
    //             {
    //                 console.info('Processing Chart 4');
    //                 const chartSelector = chart4xpath;
    //                 const mainButton = this.downloadButtonMarketSecondary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             } 
    //         case 'chart5':
    //             {
    //                 console.info('Processing Chart 5');
    //                 const chartSelector = chart5xpath;
    //                 const mainButton = this.downloadButtonUnderwritePrimary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }
    //         case 'chart6':
    //             {
    //                 console.info('Processing Chart 6');
    //                 const chartSelector = chart6xpath;
    //                 const mainButton = this.downloadButtonUnderwriteSecondary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }    
    //         case 'chart7':
    //             {
    //                 console.info('Processing Chart 7');
    //                 const chartSelector = chart7xpath;
    //                 const mainButton = this.downloadButtonProspects;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }
    //         case 'chart8':
    //             {
    //                 console.info('Processing Chart 8');
    //                 const chartSelector = chart8xpath;
    //                 const mainButton = this.downloadButtonLiabilityPrimary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );
    //             }

    //         case 'chart9':
    //             {
    //                 console.info('Processing Chart 9');
    //                 const chartSelector = chart9xpath;
    //                 const mainButton = this.downloadButtonLiabilitySecondary;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //         case 'chart10':
    //             {
    //                 console.info('Processing Chart 10');
    //                 const chartSelector = chart10xpath;
    //                 const mainButton = this.downloadButtonclaimCountIncurredChart;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //         case 'chart11':
    //             {
    //                 console.info('Processing Chart 11');
    //                 const chartSelector = chart11xpath;
    //                 const mainButton = this.downloadButtonanalysisReport;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //         case 'chart12':
    //             {
    //                 console.info('Processing Chart 12');
    //                 const chartSelector = chart12xpath;
    //                 const mainButton = this.downloadButtonclaimSummaryByPolicyYearChart;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //         case 'chart13':
    //             {
    //                 console.info('Processing Chart 13');
    //                 const chartSelector = chart13xpath;
    //                 const mainButton = this.downloadButtonclaimByMarketChart;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //             case 'chart14':
    //             {
    //                 console.info('Processing Chart 14');
    //                 const chartSelector = chart14xpath;
    //                 const mainButton = this.downloadButtonperilCountReport;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //             case 'chart15':
    //             {
    //                 console.info('Processing Chart 15');
    //                 const chartSelector = chart15xpath;
    //                 const mainButton = this.downloadButtonclaimValuesDistributionReport;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //             case 'chart16':
    //             {
    //                 console.info('Processing Chart 16');
    //                 const chartSelector = chart16xpath;
    //                 const mainButton = this.downloadButtonlossPerilByYearReport;
    //                 return await this.downloadChart(
    //                     DownloadFormat.PNG,
    //                     chartSelector,
    //                     mainButton,
    //                     "//label[normalize-space()='Download as PNG']",
    //                     this.fileDownload.downloadAndSavePNG
    //                 );

    //             }
    //         default:
    //             console.error('Invalid choice for PNG download');
    //             throw new Error('Invalid choice');
    //     }
    // }

    /**
     * Verifies default Hull button is selected (color check).
     * Purpose: To ensure default selection is correct.
     * Arguments:
     *  - expectedColor (string): Expected CSS color value.
     * Returns: Promise<void>
     */
    public async verifyDefaultHullSelected(expectedColor: string = 'rgb(38, 64, 232)') {
        console.info('Verifying default Hull button selection');
        const elementHandle = await this.hull.elementHandle();
        if (elementHandle) {
            const fontColor = await elementHandle.evaluate((el) => {
                return window.getComputedStyle(el).color;
            });
            console.info(`Hull button font color: ${fontColor}`);
            expect(fontColor).toBe(expectedColor);
        } else {
            console.warn('Hull element not found');
            throw new Error('Element not found for default Hull Rate button');
        }
    }

    /**
     * Verifies default RSM button is selected (color check).
     * Purpose: To ensure default RSM selection.
     * Arguments:
     *  - expectedColor (string): Expected CSS color value.
     * Returns: Promise<void>
     */
    public async verifyDefaultRSMSelected(expectedColor: string = 'rgb(38, 64, 232)') {
        console.info('Verifying default RSM button selection');
        const elementHandle = await this.RSM.elementHandle();
        if (elementHandle) {
            const fontColor = await elementHandle.evaluate((el) => {
                return window.getComputedStyle(el).color;
            });
            console.info(`RSM button font color: ${fontColor}`);
            expect(fontColor).toBe(expectedColor);
            console.warn('Default RSM is selected');
        } else {
            console.warn('RSM element not found');
            throw new Error('RSM Element not found for default button');
        }
    }

    /**
     * Verifies that the default filter button is not clicked (background color check).
     * Purpose: To confirm default state of filter button.
     * Arguments:
     *  - expectedColor (string): Expected background color.
     * Returns: Promise<void>
     */
    public async verifyDefaultFilterButtonNotClicked(expectedColor: string = 'rgba(0, 0, 0, 0)') {
        console.info('Verifying default filter button is not clicked');
        const elementHandle = await this.filterButton.elementHandle();
        if (elementHandle) {
            const backgroundColor = await elementHandle.evaluate((el) => {
                return window.getComputedStyle(el).backgroundColor;
            });
            console.info(`Filter button background color: ${backgroundColor}`);
            expect(backgroundColor).toBe(expectedColor);
        } else {
            console.warn('Filter button element not found');
            throw new Error('Element not found for default FilterSelected');
        }
    }

    /**
     * Returns a Locator for the filter container element based on filter name.
     * Purpose: To locate specific filter containers.
     * Arguments:
     *  - filterName (string): Name of the filter.
     * Returns: Promise<Locator>
     */


    /**
     * Verifies a specific filter's presence and matches snapshot.
     * Purpose: To validate filter UI.
     * Arguments:
     *  - filterName (string): Name of the filter.
     *  - expectedSnapshot (string): Snapshot string for comparison.
     * Returns: Promise<void>
     */
    public async verifyFilter(filterName: string, expectedSnapshot: string): Promise<void> {
        console.info(`Verifying filter: ${filterName}`);
        const filterLocator = await this.filterContainer(filterName);
        await this.waitForVisible(filterLocator);
        await expect(filterLocator).toMatchAriaSnapshot(expectedSnapshot);
    }

    /**
     * Verifies multiple filters' UI elements.
     * Purpose: To ensure filters are correctly displayed.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async verifyFilters(): Promise<void> {
        console.info('Verifying filters UI');
        const CrewTypeLocator = await this.filterContainer("Crew");
        const BusinessTypeLocator = await this.filterContainer("Business Type");
        const planeTypeLocator = await this.filterContainer("Plane Type");
        const marketLocator = await this.filterContainer("Market");
        const yearLocator = await this.filterContainer("Year");
        const yearquarterLocator = await this.filterContainer("Year Quarter");
        const quotaShareLocator = await this.filterContainer("Quota Share");
        await expect(planeTypeLocator).toMatchAriaSnapshot(`
                - text: Plane Type  
                - textbox "Enter search term"
                - text: Select All
                - checkbox "Jet Engine" [checked]
                - text: Jet Engine
                - checkbox "UAS"
                - text: UAS
               
            `);

        await expect(marketLocator).toMatchAriaSnapshot(`
                - text: Market  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Starr" [checked]
                - text: Starr
            `);

        await expect(yearLocator).toMatchAriaSnapshot(`
                - text: Year  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "2025" [checked]
                - text: "2025"
            `);

        await expect(yearquarterLocator).toMatchAriaSnapshot(`
                - text: Year Quarter  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Q1" [checked]
                - text: Q1
            `);
        await expect(quotaShareLocator).toMatchAriaSnapshot(`
                - text: Quota Share  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Quota Share" [checked]
                - text: "Quota Share"
            `);
        await expect(BusinessTypeLocator).toMatchAriaSnapshot(`
                - text: Business Type          
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Commercial" [checked]
                - text: Commercial
                - checkbox "Industrial Aid" [checked]
                - text: Industrial Aid
            `);
        await expect(CrewTypeLocator).toMatchAriaSnapshot(`
            - text: Crew 
            - radio "All" [checked]
            - text: All
            - radio "2+"
            - text: "2+"
                       
        `);
        console.info('Filters UI verified');
    }

    /**
        * Verifies multiple filters' UI elements.
        * Purpose: To ensure filters are correctly displayed.
        * Arguments: None.
        * Returns: Promise<void>
        */
    /**
    * Verifies the filters types in the filter container.
    */

    public async verifyUnderwriteFilters(): Promise<void> {
        console.info('Verifying Underwriter filters');
        const marketLocator = await this.filterContainer("Market")
        const yearquarterLocator = await this.filterContainer("Year Quarter")
        const CrewTypeLocator = await this.filterContainer("Crew");
        const BusinessTypeLocator = await this.filterContainer("Business Type");
        const planeTypeLocator = await this.filterContainer("Plane Type");
        const yearLocator = await this.filterContainer("Year");
        const quotaShareLocator = await this.filterContainer("Quota Share");
        const liabilityLimitLocator = await this.filterContainer("Liability Limit");

        console.info('Verifying Underwriter  filters');

        await expect(liabilityLimitLocator).toMatchAriaSnapshot(`
                - text: Liability Limit          
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "$100,000,000" [checked]
                - text: $100,000,000
                - checkbox "$300,000,000" [checked]
                - text: $300,000,000
            `);

        await expect(planeTypeLocator).toMatchAriaSnapshot(`
                - text: Plane Type  
                - textbox "Enter search term"
                - text: Select All
                - checkbox "Jet Engine" [checked]
                - text: Jet Engine
                - checkbox "UAS"
                - text: UAS

                               
            `);
        await expect(marketLocator).toMatchAriaSnapshot(`
                - text: Market  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Starr" [checked]
                - text: Starr
            `);
        await expect(quotaShareLocator).toMatchAriaSnapshot(`
                - text: Quota Share  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Quota Share" [checked]
                - text: "Quota Share"
            `);

        await expect(yearLocator).toMatchAriaSnapshot(`
                - text: Year  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "2025" [checked]
                - text: "2025"
            `);
        await expect(BusinessTypeLocator).toMatchAriaSnapshot(`
                - text: Business Type          
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Commercial" [checked]
                - text: Commercial
                - checkbox "Industrial Aid" [checked]
                - text: Industrial Aid
            `);
        await expect(CrewTypeLocator).toMatchAriaSnapshot(`
            - text: Crew 
            - radio "All" [checked]
            - text: All
            - radio "2+"
            - text: "2+"
                       
        `);
        console.info('Underwrite Insights filters verified');
    }


    /**
     * Verifies Market Insights filters UI.
     * Purpose: To validate filters specific to Market Insights.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async verifyMarketInsighFilters(): Promise<void> {
        console.info('Verifying Market Insights filters');
        const CrewTypeLocator = await this.filterContainer("Crew");
        const BusinessTypeLocator = await this.filterContainer("Business Type");
        const planeTypeLocator = await this.filterContainer("Plane Type");
        const yearLocator = await this.filterContainer("Year");
        const quotaShareLocator = await this.filterContainer("Quota Share");
        await expect(planeTypeLocator).toMatchAriaSnapshot(`
                - text: Plane Type  
                - textbox "Enter search term"
                - text: Select All
                - checkbox "Jet Engine" [checked]
                - text: Jet Engine
                - checkbox "UAS"
                - text: UAS

                               
            `);

        await expect(quotaShareLocator).toMatchAriaSnapshot(`
                - text: Quota Share  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Quota Share" [checked]
                - text: Quota Share
            `);

        await expect(yearLocator).toMatchAriaSnapshot(`
                - text: Year  
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "2025" [checked]
                - text: "2025"
            `);
        await expect(BusinessTypeLocator).toMatchAriaSnapshot(`
                - text: Business Type          
                - textbox "Enter search term"
                - text: Clear All
                - checkbox "Commercial" [checked]
                - text: Commercial
                - checkbox "Industrial Aid" [checked]
                - text: Industrial Aid
            `);
        await expect(CrewTypeLocator).toMatchAriaSnapshot(`
            - text: Crew 
            - radio "All" [checked]
            - text: All
            - radio "2+"
            - text: "2+"
                       
        `);
        console.info('Market Insights filters verified');
    }

    /**
     * Generates a string with the current date for "Generated on" info.
     * Purpose: To create a timestamp string.
     * Arguments: None.
     * Returns: string
     */
    public getGeneratedOnDateString(): string {
        const now = new Date();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const year = now.getFullYear();
        return `Generated on: ${month}/${day}/${year}`;
    }

    /**
     * Navigates to Hull Graph, applies filters, and verifies.
     * Purpose: To automate navigation and filter application.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async navigateToHullGraph(): Promise<void> {
        console.info('Navigating to Hull Graph');
        await this.clickonHull.click();
        await this.page.waitForTimeout(5000);
        await this.clickonFilters.click();
        await this.clickonApplyFilters.click();
        await this.page.waitForTimeout(5000);
        (await this.getButtonAverageHullRate()).click();
        console.info('Hull Graph navigation complete');
    }

    /**
     * Verifies elements on Hull tab.
     * Purpose: To validate default selections and filters.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async seeAvailableElementsonHullTab(): Promise<void> {
        console.info('Verifying Hull tab elements');
        await this.verifyDefaultHullSelected();
        await this.verifyDefaultFilterButtonNotClicked();
        await this.waitForVisible(this.hullPageHeading);
        await expect(this.hullPageHeading).toContainText('Aviation Insights');
        await this.waitForVisible(this.hullGraphHeading);
        await expect(this.hullGraphHeading).toContainText('Year over Year Change Hull Rate');
        await this.filterButton.click();
        await this.clickonApplyFilters.click();
        await this.verifyFilters();

        // Additional filter button interactions
        await this.getFilterButton('collapse').click();
        await this.getFilterButton('expand').click();
        await this.getFilterButton('reset').click();
        console.info('Hull tab elements verified');
    }

    /**
     * Gets specific filter button based on type.
     * Purpose: To locate filter control buttons.
     * Arguments:
     *  - buttonType ('collapse' | 'expand' | 'reset'): Button type.
     * Returns: Locator
     */
    public getFilterButton(buttonType: 'collapse' | 'expand' | 'reset'): Locator {
        switch (buttonType) {
            case 'collapse':
                console.info('Locating collapse button');
                return this.page.locator("//button[@id='filter-collapse-toggle']");
            case 'expand':
                console.info('Locating expand button');
                return this.page.locator("//button[@id='filter-collapse-toggle']");
            case 'reset':
                console.info('Locating reset button');
                return this.page.locator("//button[normalize-space()='Reset All']");
            default:
                console.warn(`Unknown button type: ${buttonType}`);
                throw new Error(`Unknown button type: ${buttonType}`);
        }
    }

    /**
     * Verifies elements on Market tab.
     * Purpose: To validate default and filter interactions.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async seeAvailableElementsonMarketTab(): Promise<void> {
        console.info('Verifying Market tab elements');
        await this.clickonMarket.click();
        await this.waitForVisible(this.marketPageHeading);
        await expect(this.marketPageHeading).toContainText('Aviation Insights');
        await expect(this.page.getByRole('button', { name: 'Lost Business By Market' })).toBeVisible();
        await this.verifyDefaultFilterButtonNotClicked();
        await this.filterButton.click();
        await this.clickonApplyFilters.click();
        await this.verifyMarketInsighFilters();

        // Additional filter button interactions
        await this.getFilterButton('collapse').click();
        await this.getFilterButton('expand').click();
        await this.getFilterButton('reset').click();
        console.info('Market tab elements verified');
    }

    /**
     * Verifies elements on Underwriter tab.
     * Purpose: To validate default selections and filters.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async seeAvailableElementsonUnderwriterTab(): Promise<void> {
        console.info('Verifying Underwriter tab elements');
        await this.clickonUnderwriter.click();
        await this.waitForVisible(this.underWriterPageHeading);
        await expect(this.underWriterPageHeading).toContainText('Aviation Insights');

        await this.waitForVisible(this.hullRateAverage_GraphHeading);
        await expect(this.hullRateAverage_GraphHeading).toContainText('Hull Rate Average');

        await this.waitForVisible(this.hullRateAverageBottom_GraphHeading);
        await expect(this.hullRateAverageBottom_GraphHeading).toContainText('Hull Rate Δ % Average');

        await this.verifyDefaultFilterButtonNotClicked();

        await this.filterButton.click();
        await this.clickonApplyFilters.click();
        await this.verifyUnderwriteFilters();
        // Verify filter buttons
        await this.allFilterButtons;
        console.info('Underwriter tab elements verified');
    }

    /**
     * Validates the slider for Hull Value.
     * Purpose: To test slider functionality.
     * Arguments:
     *  - value (number): Value to set.
     * Returns: Promise<void>
     */
    public async validateSliderHullValueFilter(value: number): Promise<void> {
        console.info(`Setting Hull Value slider to: ${value}`);
        await this.sliderHullValueFilter.dblclick();
        await this.sliderValuefill.clear();
        await this.sliderValuefill.fill(value.toString());
        await this.clickonHulllValue.click();
    }

    /**
     * Validates filter retention after applying filters.
     * Purpose: To ensure filters are retained.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async validateFilterRetention(): Promise<void> {
        console.info('Validating filter retention');
        await this.page.getByRole('button', { name: ' Filters' }).click();
        const filterByPlaneType = this.page.getByRole('radio', { name: 'UAS' });
        await filterByPlaneType.check();
        await this.page.getByRole('button', { name: 'Apply Filters' }).click();
        await this.page.waitForTimeout(5000);
        await this.page.getByText('Market', { exact: true }).click();

        const resFilter = this.page.locator('#filterContainer').getByText('UAS');
        await expect(resFilter).toBeChecked();
        console.info('Filter retention verified');
    }

    /**
     * Resets all filters.
     * Purpose: To clear filters.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async filterReset(): Promise<void> {
        console.info('Resetting filters');
        await this.page.locator('//button[normalize-space()="Reset All"]').click();
        await this.page.locator('//span[normalize-space()="Filters"]').click();
    }


    /**
     * Gets a filter chip locator by name.
     * Purpose: To locate specific filter chips.
     * Arguments:
     *  - filterName (string): Name of the filter.
     * Returns: Locator
     */
    public filterChips(filterName: string): Locator {
        console.info(`Getting filter chip for: ${filterName}`);
        return this.page.locator(`//av-filter-chips//button[contains(text(), "${filterName}")]`);
    }

    /**
     * Validates filter chips' tooltips.
     * Purpose: To ensure filter chips show correct tooltip info.
     * Arguments: None.
     * Returns: Promise<void>
     */
    public async validatefilterChips(): Promise<void> {
        console.info('Validating filter chips tooltips');
        const checkedBoxes = this.page.locator('#filterContainer input[type="checkbox"]:checked');
        for (let i = 0; i < await checkedBoxes.count(); i++) {
            const label = await checkedBoxes.nth(i).evaluate(el =>
                el.closest('label')?.textContent?.trim()
            );
            const filterName = await checkedBoxes.nth(i).evaluate((el) => {
                const showPanel = el.closest('div[class*="show-panel"]');
                const parent = showPanel?.parentElement;
                const header = parent?.querySelector('[class*="filter-option-header"]');
                return header?.textContent?.trim() || null;
            });
            await this.filterChips(filterName).hover();
            const tooltipText = await this.getTooltipText();
            console.info(`Tooltip for filter "${filterName}": ${tooltipText}`);
            expect(tooltipText).toContain(label?.trim());
        }
    }
    public async clickHull(): Promise<void> {
        console.info('Hull clicking ');
        await this.page.locator("//div[contains(text(),'Hull')]").click();
    }
    public async clickLiabilityPremiumButton(button: string): Promise<void> {
        await this.page.locator("(//button[contains(text(),'Liability Premium')])[1]");
    }

    public get clickLiabilitySecondaryButton(): Locator {
        console.info('Liability Premium Button clicking ');
        return this.page.locator("(//button[contains(text(),'Liability Premium')])[2]");
    }
    public get clickunderWriterPrimaryDownlaod(): Locator {
        console.info('underWriter Primary Downlaod clicking ');
        return this.page.locator("//*[@id='chart1']/div/div[2]/ci-menu-card/div/img");
    }

    public get clickunderWriterSecondaryDownlaod(): Locator {
        console.info('underWriter Secondary Downlaod clicking ');
        return this.page.locator("//*[@id='chart2']/div/div[2]/ci-menu-card/div/img");
    }

    public get clickunderWriterPremiumdropDown(): Locator {
        console.info('underWriter Premium Drop Down clicking ');
        return this.page.locator("//*[@id='chart1']/div/div[2]/p-dropdown/div/div[2]");
    }
    public get clickunderWriterAveragedropDown(): Locator {
        console.info('underWriter Average Drop Down clicking ');
        return this.page.locator("//*[@id='chart2']/div/div[2]/p-dropdown/div/div[2]")
    }



    public get clickunderWriterPremiumAverage(): Locator {
        console.info('underWriter Premium Avergae clicking ');
        return this.page.locator("//span[normalize-space()='Average']");
    }

    public get clickunderWriterSecondaryAverage(): Locator {
        console.info('underWriter Secondary Avergae clicking ');
        return this.page.locator("//span[normalize-space()='% Average']");
    }
    public get clickunderWriterPremiumMaximum(): Locator {
        console.info('underWriter Premium Maximum clicking ');
        return this.page.locator("//span[normalize-space()='Maximum']");
    }
    public get clickunderWriterSecondaryMaximum(): Locator {
        console.info('underWriter Secondary Maximum clicking ');
        return this.page.locator("//span[normalize-space()='% Maximum']");
    }

    public get clickunderWriterPremiumMedian(): Locator {
        console.info('underWriter Premium Median clicking ');
        return this.page.locator("//span[normalize-space()='Median']");
    }

    public get clickunderWriterSecondaryMedian(): Locator {
        console.info('underWriter Secondary Median clicking ');
        return this.page.locator("//span[normalize-space()='% Median']");
    }

    public get clickunderWriterPremiumAircraftCount(): Locator {
        console.info('underWriter Premium Aircraft Count clicking ');
        return this.page.locator("//span[normalize-space()='Aircraft Count']");
    }

    public get clickHullRateButton(): Locator {
        console.info('Hull Rate Button clicking ');
        return this.page.locator("(//button[contains(text(),'Hull Rate')])[1]");
    }

    public async hullRateButtonClick(): Promise<void> {
        console.info('Hull Rate Button clicking ');
        await this.page.locator("(//button[contains(text(),'Hull Rate')])[2]").click();
    }

    public get clickhullPrimaryDownlaod(): Locator {
        console.info('underWriter Primary Downlaod clicking ');
        return this.page.locator("//*[@id='chart1']/div/ci-menu-card/div");
    }

    public get clickAnnualHullRateTrend(): Locator {
        console.info('Annual Hull Rate clicking ');
        return this.page.locator("//button[normalize-space()='Annual Hull Rate Trend']");
    }

    public get clickhullSecondaryDownlaod(): Locator {
        return this.page.locator("//*[@id='chart2']/div/ci-menu-card/div");
    }
    public get clickAverageHullRate(): Locator {
        return this.page.locator("//button[normalize-space()='Average Hull Rate']");
    }

    public get clickAverageHullRatedropdown(): Locator {
        return this.page.locator("//*[@id='chart2']/div[2]/div/p-dropdown/div/div[2]/span");
    }

    public get averageHullRateTable(): Locator {
        return this.page.locator(`//*[@id="legend-table"]//table[@role="table"]`)
    }



    public get clickMedianHullRate(): Locator {
        return this.page.locator("//span[normalize-space()='Median Hull Rate']");
    }
    public get clickAverageHull(): Locator {
        return this.page.locator("//span[contains(text(),'Average % Δ Hull Rate')]");
    }

    public get clickMedianHull(): Locator {
        return this.page.locator("//span[contains(text(),'Median % Δ Hull Rate')]");
    }

    public get clickAverageHullValue(): Locator {
        return this.page.locator("//span[contains(text(),'Average % Δ Hull Value')]");
    }
    public get clickMedianHullValue(): Locator {
        return this.page.locator("//span[contains(text(),'Median % Δ Hull Value')]");
    }

    public get clickAirCraftValue(): Locator {
        return this.page.locator("//span[normalize-space()='Aircraft Count']");
    }
    public get percentPlacementYoYRange(): Locator {
        return this.page.locator("//div[@id='yearChangeHullRate']//div//*[name()='svg']//*[name()='text']//*[name()='tspan' and text()='0% to 10%']");
    }

    public get percentPlacementYoYRangemarket(): Locator {
        return this.page.locator("//div[@id='yearChangeHullRate']//div//*[name()='svg']//*[name()='g']//*[name()='g']//*[name()='g' and contains(@role,'region')]//*[name()='g'][1]/*[name()='g']//*[name()='g']//*[name()='g']//*[name()='g']//*[name()='g' and contains(@transform,'translate(')]//*[name()='g' and contains(@transform,'translate(')]//*[name()='g' and contains(@aria-hidden,'true')]//*[name()='g']//*[name()='g']//*[name()='g']//*[name()='g'][2]/*[name()='g' and contains(@transform,'translate(')]//*[name()='text'][1]/*[name()='tspan'][1]");
    }

}
