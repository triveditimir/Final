import { Page, Locator, expect } from '@playwright/test';
import { BasePage } from '../BasePage';

export class MachMarketInsightPage extends BasePage {
    constructor(page: Page) {
        super(page);
    }
    public async getGraphFooterTexts(chartContainerId: string): Promise<string[]> {
        const footerSpans = await this.page.locator(`//*[@id='${chartContainerId}']//div/ci-graph-footer//span`);
        console.log("chartid", chartContainerId)
        await footerSpans.first().waitFor({state: 'visible'})
        const count = await footerSpans.count();
        console.log(count)
        const texts = [];
        for (let i = 0; i < count; i++) {
            const text = await footerSpans.nth(i).textContent() || '';
            console.log('text-'+i, text)
            // Extract only matching word(s) - for example, extract first word or use regex as needed
            const match = text.match(/^[^:]+/);
            texts.push(match ? match[0] : '');
        }
        return texts;
    }

    public get averageNetLiabilityBtn(): Locator {
        return this.page.locator('//button[normalize-space()="Average Net Liability"]');  
    }

    public get averageHullRateBtn(): Locator {
        return this.page.locator('//button[normalize-space()="Average Hull Rate"]');  
    }

    public get averageHullRatedropdown(): Locator {
        return this.page.locator('//*[@id="chart1"]/div/div[2]/div/p-dropdown/div/div[2]/span');  
    }
    public get medianHullRate(): Locator {
        return this.page.locator('//span[normalize-space()="Median Hull Rate"]'); 
    }
    public get averageHullRate(): Locator {
        return this.page.locator('//span[normalize-space()="Average Hull Rate"]'); 
    }
    public get averageChangeHullRate(): Locator {
        return this.page.locator('//span[normalize-space()="Average % Change Hull Rate"]'); 
    }

    public get meidanChangeHullRate(): Locator {
        return this.page.locator('//span[normalize-space()="Median % Change Hull Rate"]'); 
    }

    public get machPrimaryDownlaod(): Locator {
        return this.page.locator("//*[@id='chart1']/div/div[1]/ci-menu-card/div/img"); 
            }

     public get machSecondaryDownlaod(): Locator {
        return this.page.locator("//*[@id='chart2']/div[1]/ci-menu-card/div/img"); 
                    }

    
    public get medianNetLiability(): Locator {
        return this.page.locator('//span[normalize-space()="Median Net Liability"]'); 
    }
    
    public get averageNetLiability(): Locator {
        return this.page.locator('//span[normalize-space()="Average Net Liability"]'); 
    }

    public get averageChangeNetLiability(): Locator {
        return this.page.locator('//span[normalize-space()="Average % Change Net Liability"]'); 
    }


    public get medianChangeNetLiability(): Locator {
        return this.page.locator('//span[normalize-space()="Median % Change Net Liability"]'); 
    }

 public get liabilityPremiumbyLiabilityLimitBtn(): Locator {
        return this.page.locator('//button[normalize-space()="Liability Premium by Liability Limit"]'); 
    }

     public get actualBtn(): Locator {
        return this.page.locator('//button[normalize-space()="Actual"]'); 
            }

            public get trendBtn(): Locator {
        return this.page.locator('//button[normalize-space()="Trend"]'); 
            }

 public get hullRatebyInsuredValueBtn(): Locator {
        return this.page.locator('//button[normalize-space()="Hull Rate by Insured Value"]'); 
    }


    
    public machButton(): Locator {
        return this.page.locator('//div[contains(text(),"MACH")]');  
    }

    public async waitForVisible(locator: Locator): Promise<void> {
        await locator.waitFor({ state: 'visible' });
    }

     public get marketButton(): Locator {
        return this.page.locator('//div[contains(text(),"Market")]')
    }

    
    public async uncheckPlaneType(): Promise<void> {
        const filterByPlaneType = this.page.locator('//input[@value="UAS"]/parent::label')
        await filterByPlaneType.click();
        await this.page.waitForTimeout(5000);
        await this.page.locator('//button[text()="Apply Filters"]').click();
    }

    public async checkCommercialBusinessType(): Promise<void> {
        const filterByBusinessType = this.page.locator('//input[@value="Commercial"]/parent::label')
        await filterByBusinessType.click();
        await this.page.locator('//button[text()="Apply Filters"]').click();
    }

    
    public async clickAverageNetLiabilityButton(): Promise<void> {
        await this.averageNetLiabilityBtn.click();
    }

    public async validateFilterRetention(){
        
        //await this.filtersButton.click();
         const filterByCrewType= this.page.locator('//input[@value="2+"]/parent::label')
        await filterByCrewType.click();
        await this.page.waitForTimeout(2000);
        await this.page.locator('//button[text()="Apply Filters"]').click();
        await this.page.waitForTimeout(5000);
        const marketButton = await this.page.locator('//div[contains(text(),"Market")]');
        marketButton.click();
        
         
    }
    
}
