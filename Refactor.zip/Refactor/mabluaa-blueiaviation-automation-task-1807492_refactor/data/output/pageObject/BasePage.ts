import { Page, Locator, expect } from '@playwright/test';


/**
 * Abstract Base Page class that provides common functionality for all pages.
 */
export abstract class BasePage {
     readonly page: Page;

    constructor(page: Page) {
        this.page = page;
    }

	async navigateToBaseURL(): Promise<void> {
        // Todo: use env variable
		//const url = EnvCommon.URL;
        const url = "https://staging2.linqbymarsh.com/linq/auth/login?redirect=https:%2F%2Fstaging2.linqbymarsh.com%2Fblueiaviation%2Foverview%3Fdl%3Dtrue"
		let response = await this.page.goto(url);
		if (!response.ok) {
			await this.page.reload({ timeout: 14000 });
		}
		await this.waitForPageToBeLoaded();
	};

    /**
     * Waits for the element to be visible.
     * @param locator - The locator of the element to wait for.
     */
    public async waitForVisible(locator: Locator): Promise<void> {
        await locator.waitFor({ state: 'visible' });
    }

    public get filtersButton(): Locator {
        return this.page.locator('//av-filter-chips//button//span[text()="Filters"]');
    }

    public get collapseAllFilterButton(): Locator {
        return this.page.locator('//button[normalize-space()="Collapse All"]');
    }

    public get resetAllFilterButton(): Locator {
        return this.page.locator('//button[normalize-space()="Reset All"]');
    }

    public buttonWithText(text: string): Locator {
        return this.page.locator(`//button[normalize-space()='${text}']`)        
    }

    public spanWithText(text: string): Locator {
        return this.page.locator(`//span[normalize-space()='${text}']`)        
    }

    public async getTooltipText(): Promise<string> {
        const tooltip = await this.page.locator('.p-tooltip-text')
        if (tooltip.isVisible()) {
            const tooltipText = await tooltip.textContent();
            return tooltipText
        }
        return ""
    }

    /**
     * Opens the Dashboard section and verifies the filters.
     */
    public async VerifyFiltersButtons(): Promise<void> {
        
        await expect(this.filtersButton).not.toHaveClass(/active|pressed/);
        await expect(this.filtersButton).not.toHaveAttribute('aria-pressed', 'true');
        await this.filtersButton.click();
        await expect(this.collapseAllFilterButton).toBeVisible();
        await expect(this.resetAllFilterButton).toBeVisible();
       
    }

	async waitForPageToBeLoaded(): Promise<void> {
		this.page.waitForLoadState('domcontentloaded', { timeout: 15000 });
	};

}