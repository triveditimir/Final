import { Locator, Page } from '@playwright/test';

export class ClientSelectionPopup {
  readonly page: Page;
  readonly popupContainer: Locator;
  readonly closeIcon: Locator;
  readonly companyNameInput: Locator;
  readonly clientRadioButtons: Locator;
  readonly goButton: Locator;
  readonly defaultClientName: string;

  constructor(page: Page) {
    this.page = page;
    this.popupContainer = page.locator('div.client-selection-wrapper');
    this.closeIcon = this.popupContainer.locator('img.close-icon');
    this.companyNameInput = this.popupContainer.locator('input.p-autocomplete-input');
    this.clientRadioButtons = this.popupContainer.locator('input[type="radio"][name="companyData"]');
    this.goButton = this.popupContainer.locator('button.select-btn');
    this.defaultClientName = "Scottsdale Inc (Demo)"
  }

  async isVisible(): Promise<boolean> {
    return await this.popupContainer.isVisible();
  }

  async close(): Promise<void> {
    if (await this.isVisible()) {
      await this.closeIcon.click();
      await this.popupContainer.waitFor({ state: 'hidden' });
    }
  }

  async selectClientByName(clientName: string): Promise<void> {
    if (!(await this.isVisible())) {
      throw new Error('Client Selection pop-up is not visible');
    }
    // Find the radio button corresponding to the client name and select it
    // Adjusted locator to better match the structure and avoid errors
    const clientListItems = this.popupContainer.locator('li.client-details');
    const count = await clientListItems.count();
    for (let i = 0; i < count; i++) {
      const nameLocator = clientListItems.nth(i).locator('.company-name b');
      const nameText = await nameLocator.textContent();
      if (nameText?.trim() === clientName) {
        const radioButton = clientListItems.nth(i).locator('input[type="radio"]');
        await radioButton.check();
        return;
      }
    }
    throw new Error(`Client with name "${clientName}" not found in the pop-up`);
  }
 
  async selectDefaultClient(): Promise<void> {
    const clientName = this.defaultClientName
    if (!(await this.isVisible())) {
      throw new Error('Client Selection pop-up is not visible');
    }
    // Find the radio button corresponding to the client name and select it
    // Adjusted locator to better match the structure and avoid errors
    const clientListItems = this.popupContainer.locator('li.client-details');
    const count = await clientListItems.count();
    for (let i = 0; i < count; i++) {
      const nameLocator = clientListItems.nth(i).locator('.company-name b');
      const nameText = await nameLocator.textContent();
      if (nameText?.trim() === clientName) {
        const radioButton = clientListItems.nth(i).locator('input[type="radio"]');
        await radioButton.check();
        return;
      }
    }
    throw new Error(`Client with name "${clientName}" not found in the pop-up`);
  }

  async clickGo(): Promise<void> {
    if (await this.isVisible()) {
      await this.goButton.click();
      await this.popupContainer.waitFor({ state: 'hidden' });
    } else {
      throw new Error('Client Selection pop-up is not visible');
    }
  }
}
