import { Page } from "playwright";
import { AppMain } from "../../AppMain";
import { expect } from "allure-playwright";

import FilterFunctions from "../commonBusinessFunctions/FilterBusinessFunctions";
import CommonFunctions from "../commonBusinessFunctions/CommonFunctions";
import { ClientSelectionPopup } from "../../../data/output/pageObject/ClientSelectionPopup";
import { FilterPage } from "../../../data/output/pageObject/common/FilterPage";




export default class ProspectsInsightsFunction {
    readonly page: Page
    readonly appMain: AppMain
    readonly commonFn: CommonFunctions
    readonly fitlerFn: FilterFunctions


    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
        this.commonFn = new CommonFunctions(page)
        this.fitlerFn = new FilterFunctions(page)
    }
    

    /**
     * Clicks on the Insights button
     */
    public async navigateToInsight(): Promise<void> {
        const aviationOverviewPage = this.appMain.aviationOverviewPage
        await aviationOverviewPage.insightsButton.click();
        const clientPopup = new ClientSelectionPopup(this.page);
        // Handle intermittent client selection pop-up if it appears
        if (await clientPopup.isVisible()) {
            await clientPopup.selectClientByName('3m Company');
            await clientPopup.clickGo();
        }
        await this.page.waitForTimeout(10000);
        await this.appMain.ClaimsMarketInsight.marketInsightsButton().click();
        await this.page.waitForTimeout(5000);
        
        
    }

    /**
     * Clicks on the Prospects Screen
     */
    public async navigateToProspects(): Promise<void> {
        const prospectPage = this.appMain.prospectInsight
        await prospectPage.prospects.click();
        await this.page.waitForTimeout(2000)
    }

    /**
     * Verifies the presence of expected dashboards in the Prospects Dashboard
     */
    public async verifyProspectsDashboard(): Promise<void> {
        const prospectPage = this.appMain.prospectInsight
        await prospectPage.waitForVisible(prospectPage.aviationInsightslabel);
        const graphProspectSampleImg = await prospectPage.graphImgProspect
        await prospectPage.waitForVisible(graphProspectSampleImg);

    }

    

}
