import { Locator, Page } from "playwright";
import { AppMain } from "../../../src/AppMain";
import { expect } from "allure-playwright";
import { captureXAxisLabels, captureYAxisLabels, validateGraphAxes } from "../../../data/output/Utils/graphValidationUtils";
import FilterFunctions from "./FilterBusinessFunctions";
import { GraphPage } from "../../../data/output/pageObject/common/graphPage";

export default class GraphFunctions {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    public async verifyChartAxes(chartSelector: string): Promise<void> {
        // Pass chartContainerSelector as parameter when calling validateGraphAxes
        //chartSelector = '#yearChangeHullRate' -- example
        const expectedXAxis = await captureXAxisLabels(this.page, chartSelector);
        const expectedYAxis = await captureYAxisLabels(this.page, chartSelector);
        await validateGraphAxes(this.page, expectedXAxis, expectedYAxis, chartSelector);
    }

    public async verifyGraphFooters(graphContainerId: string, expectedFooterTexts: string[]): Promise<void> {
        const footerSpans = await this.page.locator(`//*[@id='${graphContainerId}']//div/ci-graph-footer//span`);
        console.log("chartid", graphContainerId)
        await footerSpans.first().waitFor({ state: 'visible' })
        const count = await footerSpans.count();
        console.log(count)
        const texts = [];
        for (let i = 0; i < count; i++) {
            const text = await footerSpans.nth(i).textContent() || '';
            console.log('text-' + i, text)
            // Extract only matching word(s) - for example, extract first word or use regex as needed
            const match = text.match(/^[^:]+/);
            texts.push(match ? match[0] : '');
        }
        //   return texts;
        for (const expectedText of expectedFooterTexts) {
            expect(texts).toContain(expectedText);
        }
    }

    public async verifyGraphAxesWithClickOnFilterOption(chartId: string, filterName: string, filterValue?: string, resetFilters: boolean = true): Promise<void> {
        const filterFunctions = new FilterFunctions(this.page)
        await filterFunctions.clickFilterOption(filterName, filterValue)
        await filterFunctions.applyFilters()

        await this.verifyChartAxes(`#${chartId}`)

        if (resetFilters) {
            await filterFunctions.resetAllFilters();
        }
    }

    async verifyToggleButtonIsSelected(buttonText: string): Promise<void> {
        const graphPage = this.appMain.graphPage
        const chartToggleBtn = await graphPage.chartToggleBtn(buttonText)
        await expect(chartToggleBtn).toHaveCSS('background-color', 'rgb(38, 64, 232)')

    }

    async updateMaxSliderValue(chartId: string): Promise<void> {
        const graphPage = this.appMain.graphPage
        const sliderValueMax = await graphPage.chartSliderMaxlabel(chartId)
        await sliderValueMax.click()
        const maxValueInput = await graphPage.chartSliderMaxInput(chartId)
        const maxValue = await maxValueInput.getAttribute("max")
        const minValue = await maxValueInput.getAttribute("min")
        const newValue = Math.trunc((Number(minValue) + Number(maxValue)) / 2)
        await maxValueInput.fill(newValue.toString())



    }

    // async validateCustomSlider(buttonText: string): Promise<void> {
    //    const graphPage = this.appMain.graphPage
    //     const customSliderButton = await graphPage.chartSliderBtn(but)
    //     await customSliderButton.last().fill
    // }

    public async verifyChartChangesOnDropdownSelection(chartSelector: string, dropdownSelection: string, toggleButtonSelector?: Locator) {
        const chart = this.page.locator(chartSelector);
        // If toggleButtonSelector is provided, click it before proceeding
        if (toggleButtonSelector) {
            await toggleButtonSelector.click();
        }

        // Take initial screenshot
        const beforeScreenshot = await chart.screenshot();
        //await this.page.screenshot({ path: 'chartBefore.png', clip: await chart.boundingBox() });
        await chart.locator("span.p-dropdown-label").click()
        await chart.locator(`//ul//li//span[normalize-space(.)='${dropdownSelection}']`).click()
        await this.page.waitForTimeout(1000)
        // Take initial screenshot
        const afterScreenshot = await chart.screenshot();
        //await this.page.screenshot({ path: 'chartAfter.png', clip: await chart.boundingBox() });
        expect(beforeScreenshot).not.toEqual(afterScreenshot);

    }

    public async verifyChartChangesOnToggleSelection(chartSelector: string, toggleSelectorText: string, insideToggleSelectorText: string[]) {
        const chartLocator = this.page.locator(chartSelector);
        const chartToggleBtn = this.appMain.graphPage.chartToggleBtn(toggleSelectorText)
        await chartToggleBtn.click()
        const beforeScreenshot = await chartLocator.screenshot();
        
        const chartInsideToggleBtn = this.appMain.graphPage.chartInsideToggleBtn(insideToggleSelectorText[0])
        await expect(chartInsideToggleBtn).toHaveCSS('color', 'rgb(38, 64, 232)')
        
        const chartInsideToggleBtn2 = await this.appMain.graphPage.chartInsideToggleBtn(insideToggleSelectorText[1])
        await chartInsideToggleBtn2.click()
        await this.page.waitForTimeout(1000)
        await expect(chartInsideToggleBtn2).toHaveCSS('color', 'rgb(38, 64, 232)')

        const afterScreenshot = await chartLocator.screenshot();
        expect(beforeScreenshot).not.toEqual(afterScreenshot);
    }
}