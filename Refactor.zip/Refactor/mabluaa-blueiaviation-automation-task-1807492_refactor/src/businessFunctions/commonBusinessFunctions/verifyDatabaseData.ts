import constants from 'node:constants';
import { AppMain } from "./../../AppMain";
import { DataVerifier } from '../../../data/output/Utils/DataVerifier'; // Import the class
import { Page } from "playwright";
import config from '../../../config/config.json' with { type: "json" };


export default class VerifyDatabaseData {
  readonly page: Page;
  readonly appMain: AppMain;

  constructor(page: Page) {
    this.page = page;
    this.appMain = new AppMain(page);
  }

  // method: verifyDatabaseData
  public async verifyDatabaseData(dbName: string,collectionName: string,querySingle: object,queryMany: object): Promise<{ singleDoc: any | null; manyDocs: any[] }> 
  {
    const verifier = new DataVerifier(dbName);
    await verifier.connect();
    try {
      const singleDoc = await verifier.getOneDocument(collectionName, querySingle);
      const manyDocs = await verifier.getManyDocuments(collectionName, queryMany);
      return { singleDoc, manyDocs };
    } finally {
      await verifier.close();
    }
  }

  // method: verify With Aggregation
  public async verifyWithAggregation(filters: any,pipeline?: any[]): Promise<any[]> 
  {
    const verifier = new DataVerifier();
    await verifier.connect();
    try {
      const pipelineToRun = pipeline || await this.getAggregationPipeline(filters);
      const results = await verifier.getAggregation(filters.collectionName, pipelineToRun);
      return results;
    } finally {
      await verifier.close();
    }
  }

  // method: verify DatabaseData with pipeline
  public async verifyDatabaseDataWithPipeline(pipeline: object[],dbName?: string,collectionName?: string ): Promise<any[]> 
  {

    if (!collectionName) {
    throw new Error("Collection name must be provided");
  }

    const databaseName = dbName || config.dbName; // Use provided or fallback to config
    const verifier = new DataVerifier(databaseName);
    await verifier.connect();
    try {
      const results = await verifier.getAggregation(collectionName, pipeline,databaseName);
      return results;
    } finally {
      await verifier.close();
    }
  }

  /**
   * New dynamic method:
   * - Accepts collection name, filters object, optional dbName
   * - Builds a $match pipeline dynamically based on filters
   * - Executes aggregation and returns results
   */
  public async verifyDataWithDynamicFilters(collectionName: string,filters: any,dbName?: string): Promise<any[]> 
  {
    const verifier = new DataVerifier(dbName || 'defaultDbName'); // Replace 'defaultDbName' if needed
    await verifier.connect();

    try {
      const pipeline: any[] = [];

      if (filters && Object.keys(filters).length > 0) {
        pipeline.push({ $match: filters });
      }

      // Extend here if we  want to add more stages based on filters
      // e.g., sorting, grouping, projections, etc.

      const results = await verifier.getAggregation(collectionName, pipeline);
      return results;
    } finally {
      await verifier.close();
    }
  }

  
  public async getAggregationPipeline(filters: any): Promise<any[]> {
  // Build the pipeline with a $match stage using the filters object
  const pipeline: any[] = [];

  if (filters && Object.keys(filters).length > 0) {
    pipeline.push({ $match: filters });
  }

  // we can add more stages here if needed, e.g., $sort, $group, etc.

  return pipeline;
}

}