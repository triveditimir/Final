import { Locator, Page } from "playwright";
import { AppMain } from "../../../src/AppMain";
import { expect } from "allure-playwright";

export default class CommonFunctions {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    public async validateTableHasData(tableLocator: Locator): Promise<void> {
        const tdCells = tableLocator.locator("//td")
        const hasContent = await tdCells.evaluateAll(cells =>
            cells.some(cell => cell.textContent?.trim())
        );
        expect(hasContent).toBe(true);
    }
}