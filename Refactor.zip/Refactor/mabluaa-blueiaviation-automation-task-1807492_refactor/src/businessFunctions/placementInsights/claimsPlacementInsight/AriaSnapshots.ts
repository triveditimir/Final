export const businessSnapshot = `
    - text: Business Type 
    - checkbox "Commercial" [checked]
    - text: Commercial
    - checkbox "Industrial Aid" [checked]
    - text: Industrial Aid
`;

export const policySnapshot = `
    - text: Policy Type  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Hull & Liability" [checked]
    - text: Hull & Liability
`;

export const planeSnapshot = `
    - text: Plane Type  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Jet Engine" [checked]
    - text: Jet Engine
`;

export const lossPerilSnapshot = `
    - text: Loss Peril  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Personal Injury" [checked]
    - text: Personal Injury
    - checkbox "Pilot Error" [checked]
    - text: Pilot Error
    - checkbox "Weather Other" [checked]
    - text: Weather Other
`;

export const claimSnapshot = `
    - text: Claim Type  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Liability  Bodily Injury or Fatality" [checked]
    - text: Liability  Bodily Injury or Fatality
    - checkbox "Physical DamageIM" [checked]
    - text: Physical DamageIM
`;

export const coverageSnapshot = `
    - text: Coverage Type  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Hull" [checked]
    - text: Hull
    - checkbox "Passenger Liability" [checked]
    - text: Passenger Liability
`;

export const marketSnapshot = `
    - text: Market  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "QBE" [checked]
    - text: QBE
    - checkbox "Starr" [checked]
    - text: Starr
`;

export const yearSnapshot = `
    - text: Year  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "2022" [checked]
    - text: "2022"
`;


