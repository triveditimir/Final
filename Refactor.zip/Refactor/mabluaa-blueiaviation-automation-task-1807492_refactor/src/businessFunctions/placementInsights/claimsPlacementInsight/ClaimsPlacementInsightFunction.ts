import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import { expect } from "allure-playwright";
import { businessSnapshot, claimSnapshot, coverageSnapshot, lossPerilSnapshot, marketSnapshot, planeSnapshot, policySnapshot, yearSnapshot } from "./AriaSnapshots";
import FilterFunctions from "../../commonBusinessFunctions/FilterBusinessFunctions";
import CommonFunctions from "../../commonBusinessFunctions/CommonFunctions";
import GraphFunctions from "../../commonBusinessFunctions/GraphBusinessFunctions";
import { validateChartLegendswithTable } from "../../../../data/output/Utils/tableGraphValidationUtils";


export default class ClaimsPlacementInsightFunction {
    readonly page: Page
    readonly appMain: AppMain
    readonly commonFn: CommonFunctions
    readonly graphFn: GraphFunctions

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
        this.commonFn = new CommonFunctions(page)
        this.graphFn = new GraphFunctions(page)
    }

    async navigateToPlacementClaimsDashboard(): Promise<void> {
        const claimPlacementPage = this.appMain.claimsPlacementInsight
        const claimsButton = await claimPlacementPage.claimsButton()
        await claimsButton.click();
    }

    async verifyFiltersAndRetenion(): Promise<void> {
        const claimPlacementPage = this.appMain.claimsPlacementInsight

        // Verify Filters
        await this.verifyDefaultFilterSettings();
        // Verify Rententions
        await this.validateFilterRetention();
        const resFilter = await this.appMain.filterPage.filterContainerLocator().getByText('Starr')
        await expect(resFilter).not.toBeChecked();
        //Reset Filters
        await claimPlacementPage.resetAllFilterButton.click();
        await this.page.waitForTimeout(5000);
        await this.navigateToPlacementClaimsDashboard();
    };

    private async validateFilterRetention() {
        const filterFunction = new FilterFunctions(this.page)
        //TODO: Need to check filter in Market
        await filterFunction.clickFilterOptionAndApply("Market", "Starr")

        const marketButton = await this.appMain.claimsPlacementInsight.marketButton;
        await marketButton.click();
    }
/***    Verify user is able to check / uncheck "Business Type" and apply filter
        Verify user is able to check / uncheck "Policy Type" and apply filter
        Verify user is able to check / uncheck "Plane Type" and apply filter
        Verify user is able to check / uncheck "Loss Peril" and apply filter
        Verify user is able to check / uncheck "Claim Type" and apply filter
        Verify user is able to check / uncheck "Coverage Type" and apply filter
        Verify user is able to check / uncheck "Market" and apply filter
        Verify user is able to check / uncheck "Year" and apply filter
    ***/
    private async verifyDefaultFilterSettings(): Promise<void> {
        const claimMarketPage = this.appMain.ClaimsMarketInsight

        await claimMarketPage.VerifyFiltersButtons();

        const filterNamesAndSnapshots = [
            { name: "Business Type", snapshot: businessSnapshot },
            { name: "Policy Type", snapshot: policySnapshot },
            { name: "Plane Type", snapshot: planeSnapshot },
            { name: "Loss Peril", snapshot: lossPerilSnapshot },
            { name: "Claim Type", snapshot: claimSnapshot },
            { name: "Coverage Type", snapshot: coverageSnapshot },
            { name: "Market", snapshot: marketSnapshot },
            { name: "Year", snapshot: yearSnapshot }
        ];

        for (const filter of filterNamesAndSnapshots) {
            const locator = await this.appMain.filterPage.filterContainer(filter.name);
            await claimMarketPage.waitForVisible(locator);
            await expect(locator).toMatchAriaSnapshot(filter.snapshot);
        }
    }
    /**
     * Clicks on the claim count and verifies the claims main section.
     */
    public async validateClaimsSummaryboard(): Promise<void> {
        const claimMarketPage = this.appMain.ClaimsMarketInsight
        await expect(claimMarketPage.claimsSummaryView).toMatchAriaSnapshot(`
            - button "Claim Count"
            - button "Claim Incurred"`)
        await expect(claimMarketPage.claimcards.first()).toContainText("TOTAL PREMIUM")
        await expect(claimMarketPage.claimcards.nth(1)).toContainText("TOTAL INCURRED")
        await expect(claimMarketPage.claimcards.nth(2)).toContainText("LOSS RATIO")
    }

    public async validateClaimsPieChartWithTableData(tableLabel: string): Promise<void> {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight
        const pieChartClaimsCountData = await claimsMarketPage.getPieChartLegendData('#claimCountIncurredChart');
        const numberOfClaimsCountTableData = await claimsMarketPage.getNumberOfClaimsTableData(tableLabel);
        const result1 = claimsMarketPage.validateLegendPercentages(pieChartClaimsCountData, numberOfClaimsCountTableData);
        expect(result1).toBeTruthy();
    }

    /**
     * Verify user is able to see the screen elements for "Reserve Analysis" inside "Summary View" toggle
     * Verify user is able to see the screen elements for "Paid Analysis" inside "Summary View" toggle
     */

    public async validateTableGraphDataConsistency(): Promise<void> {

        await validateChartLegendswithTable(this.page, '#analysisReport');
        const claimsMarketPage = this.appMain.ClaimsMarketInsight
        await claimsMarketPage.paidAnalysisBtn.click();
        await validateChartLegendswithTable(this.page, '#analysisReport');

    }

    public async validateSummaryViewTableData(): Promise<void> {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const toggleButtons = claimsMarketPage.getClaimSummaryTableToggleButton();
        const count = await toggleButtons.count();

        for (let i = 0; i < count; i++) {
            const toggleButton = toggleButtons.nth(i);
            await toggleButton.click();
            await expect(toggleButton).toHaveCSS('background-color', 'rgb(38, 64, 232)')
            await claimsMarketPage.claimSummaryTable.waitFor({ state: 'visible' });

            await this.commonFn.validateTableHasData(claimsMarketPage.claimSummaryTable);
            await claimsMarketPage.claimSummaryTableDownloadButton.waitFor({ state: 'visible' });
        }
    }

    public async validateClaimsDetailedView() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight
        await claimsMarketPage.claimsDetailedViewBtn.click();
        await this.graphFn.verifyToggleButtonIsSelected("Detailed View")
        await this.graphFn.verifyToggleButtonIsSelected("By Count")
    }

    public async claimValueDistributionLabel() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight
        await claimsMarketPage.claimValueDistributionLabel.isVisible()

    }

    public async validateClaimIncurredSliderForClaimValueDistribution() {
        const claimsValueDistributionChardId = "claimValuesDistributionReport"
        const claimsMarketPage = this.appMain.ClaimsMarketInsight
        await claimsMarketPage.claimValueDistributionClaimIncurredLabel.isVisible()
        await this.graphFn.updateMaxSliderValue(claimsValueDistributionChardId)
        await claimsMarketPage.claimValueDistributionClaimIncurredLabel.click()
    }

    public async downloadSummaryandDetailedViewViewCharts() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidateSummaryAndDetailViewClaimChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.claimCountAndIncurredDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const claimCountAndIncurredDownloadCharts = [
            {

                action: async () => {

                    await claimsMarketPage.claimsSummaryViewBtn.click();
                    await claimsMarketPage.claimCountBtn.click();
                    await claimsMarketPage.claimCountAndIncurredDownload.click();
                    await claimsMarketPage.claimIncurredBtn.click();
                    await claimsMarketPage.claimCountAndIncurredDownload.click();
                }
            }

        ];

        // Loop through each chart action
        for (const chart of claimCountAndIncurredDownloadCharts) {
            await chart.action();
            await downloadAndValidateSummaryAndDetailViewClaimChart();
        }
    }

    public async downloadreserveAndPaidCharts() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidatereserveAndPaidChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.reserveAndPaidDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const downloadAndreserveAndPaidChart = [

            {

                action: async () => {

                    await claimsMarketPage.reserveAnalysisBtn.click();
                    await claimsMarketPage.reserveAndPaidDownload.click();
                    await claimsMarketPage.paidAnalysisBtn.click();
                    await claimsMarketPage.reserveAndPaidDownload.click();
                }
            }

        ];

        // Loop through each chart action
        for (const chart of downloadAndreserveAndPaidChart) {
            await chart.action();
            await downloadAndValidatereserveAndPaidChart();
        }
    }




    public async claimOccurrenceIncurredDownload() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidatereserveAndPaidChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.claimOccurrenceIncurredDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const downloadClaimOccurrenceIncurred = [
            {

                action: async () => {

                    await claimsMarketPage.claimSummarybyPolicyYearbtn.click();
                    await claimsMarketPage.claimOccurrenceIncurredDownload.click();
                    await claimsMarketPage.occurrenceCountTrianglebtn.click();
                    await claimsMarketPage.claimOccurrenceIncurredDownload.click();
                    await claimsMarketPage.incurredLossTrianglebtn.click();
                    await claimsMarketPage.claimOccurrenceIncurredDownload.click();
                    
                }

            }
        ];
        // Loop through each chart action
        for (const chart of downloadClaimOccurrenceIncurred) {
            await chart.action();
            await downloadAndValidatereserveAndPaidChart();
        }
    }

    
     public async claimSummaryByMarketDownload() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const claimSummaryByMarketDownloadChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.claimSummaryByMarketDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const claimSummaryByMarket = [

            {

                action: async () => {

                   await claimsMarketPage.claimSummaryByMarketDownload.click();

                }
            }

        ];


        for (const chart of claimSummaryByMarket) {
            await chart.action();
            await claimSummaryByMarketDownloadChart();
        }
    }




    public async lossPerilDownload() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadlossPerilChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.lossPerilDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const downloadlossPeril = [

            {

                action: async () => {

                    await claimsMarketPage.claimsDetailedViewBtn.click();
                    await claimsMarketPage.byValuebtn.click();
                    await claimsMarketPage.lossPerilDownload.click();
                    await claimsMarketPage.byCountbtn.click();
                    await claimsMarketPage.lossPerilDownload.click();

                }
            }

        ];


        for (const chart of downloadlossPeril) {
            await chart.action();
            await downloadlossPerilChart();
        }
    }

    public async claimValueDistributonDownload() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const claimValueDistributonDownloadChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.claimValueDistributonDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const downloadclaimValueDistributon = [

            {

                action: async () => {

                    await claimsMarketPage.claimValueDistributonDownload.click();

                }
            }

        ];


        for (const chart of downloadclaimValueDistributon) {
            await chart.action();
            await claimValueDistributonDownloadChart();
        }
    }


    public async lossPerilByYearDownload() {
        const claimsMarketPage = this.appMain.ClaimsMarketInsight;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const lossPerilByYearDownloadChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await claimsMarketPage.lossPerilByYearDownload.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const downloadlossPerilByYear = [

            {

                action: async () => {

                    await claimsMarketPage.lossPerilByYearDownload.click();

                }
            }

        ];


        for (const chart of downloadlossPerilByYear) {
            await chart.action();
            await lossPerilByYearDownloadChart();
        }
    }

            
            
}