import { Page } from "playwright";
import LiabilityMarketInsightFunction from "./marketInsights/liabilityMarketInsight/LiabilityMarketInsightFunction";
import DashboardFunctions from "../../src/businessFunctions/commonBusinessFunctions/DashboardFunctions";
import FilterFunctions from "../../src/businessFunctions/commonBusinessFunctions/FilterBusinessFunctions";
import DownloadBusinessFunctions from "../../src/businessFunctions/commonBusinessFunctions/DownloadBusinessFunctions";
import marketMarketInsightFunction from "./marketInsights/maketMarketInsight/marketMarketInsightFunction";
import underWriterMarketInsightFunction from "./marketInsights/underWriterMarketInsight/underWriterMarketInsightFunction";
import AviationOverviewFunction from "./aviationOverview/AviationOverviewFunction";
import hullMarketInsightFunction from "./marketInsights/hullMarketInsight/hullMarketInsightFunction";
import verifyDatabaseData from "../../src/businessFunctions/commonBusinessFunctions/verifyDatabaseData";
import dbPipeline from "./marketInsights/hullMarketInsight/dbPipeline";
import GraphFunctions from "./commonBusinessFunctions/GraphBusinessFunctions";
import MachMarketInsightFunction from "./marketInsights/machMarketInsight/MachMarketInsightFunction";
import ClaimsMarketInsightFunction from "./marketInsights/claimsMarketInsight/ClaimsMarketInsightFunction";
import CommonFunctions from "./commonBusinessFunctions/CommonFunctions";
import placeamentMarketInsight from "./placementInsights/marketPlacementInsight/MarketPlacementInsightFunction";

import LinqHomeFunction from "./linqHome/LinqHomeFunction";
import ProspectsInsightsFunction from "./prospectsInsights/ProspectsInsightsFunction";
import ClaimsPlacementInsightFunction from "./placementInsights/claimsPlacementInsight/ClaimsPlacementInsightFunction";

export default class AppFn {
	protected page: Page;

	constructor(page: Page) {
		this.page = page;
	};

	public get liabilityMarketInsightFunction(): LiabilityMarketInsightFunction {
		return new LiabilityMarketInsightFunction(this.page);
	}

	public get marketMarketInsightFunction(): marketMarketInsightFunction {
		return new marketMarketInsightFunction(this.page);
	}

public get placeamentMarketInsight(): placeamentMarketInsight {
		return new placeamentMarketInsight(this.page);
	}

	
	public get underWriterMarketInsightFunction(): underWriterMarketInsightFunction {
		return new underWriterMarketInsightFunction(this.page);
	}

	public get hullMarketInsightFunction(): hullMarketInsightFunction {
		return new hullMarketInsightFunction(this.page);
	}

	public get machMarketInsightFunction(): MachMarketInsightFunction {
		return new MachMarketInsightFunction(this.page);
	}

	public get claimsMarketInsightFunction(): ClaimsMarketInsightFunction {
		return new ClaimsMarketInsightFunction(this.page);
	}

	public get commonFunctions(): CommonFunctions {
		return new CommonFunctions(this.page);
	}

	public get dashboardFunctions(): DashboardFunctions {
		return new DashboardFunctions(this.page);
	}

	public get filterFunctions(): FilterFunctions {
		return new FilterFunctions(this.page);
	}
	public get downloadFunctions(): DownloadBusinessFunctions {
		return new DownloadBusinessFunctions(this.page);
	}

	public get aviationOverviewFunction (): AviationOverviewFunction {
		return new AviationOverviewFunction(this.page);
	}

	public get verifyDbDaataFunctions(): verifyDatabaseData {
		return new verifyDatabaseData(this.page);
	}

	public get dbPipeline(): dbPipeline {
		return new dbPipeline(this.page);
	}

	
	public get graphFunctions(): GraphFunctions {
		return new GraphFunctions(this.page);
	}

	public get linqHomeFunction(): LinqHomeFunction {
		return new LinqHomeFunction(this.page);
	}
	
	public get prospectsInsightsFunction(): ProspectsInsightsFunction {
		return new ProspectsInsightsFunction(this.page);
	}

	public get claimsPlacementInsightFunction(): ClaimsPlacementInsightFunction {
		return new ClaimsPlacementInsightFunction(this.page);
	}
}