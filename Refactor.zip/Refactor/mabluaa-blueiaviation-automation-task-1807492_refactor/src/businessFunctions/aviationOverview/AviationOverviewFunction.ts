import { Page } from "playwright";
import { AppMain } from "../../AppMain";
import { expect } from "allure-playwright";

import FilterFunctions from "../commonBusinessFunctions/FilterBusinessFunctions";
import CommonFunctions from "../commonBusinessFunctions/CommonFunctions";
import { ClientSelectionPopup } from "../../../data/output/pageObject/ClientSelectionPopup";
import { FilterPage } from "../../../data/output/pageObject/common/FilterPage";




export default class AviationOverviewFunction {
    readonly page: Page
    readonly appMain: AppMain
    readonly commonFn: CommonFunctions
    readonly fitlerFn: FilterFunctions


    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
        this.commonFn = new CommonFunctions(page)
        this.fitlerFn = new FilterFunctions(page)
    }
    /**
     * Validates the presence of key texts in the global header and section.
     */

    public async validateOverviewPage(): Promise<void> {
         const aviationOverviewPage = this.appMain.aviationOverviewPage
        await aviationOverviewPage.waitForVisible(aviationOverviewPage.globalHeader);
        await expect(aviationOverviewPage.globalHeader).toContainText(['MY DATA & ANALYTICS'])
        await expect(aviationOverviewPage.menuHeader).toContainText(['LINQ HOME', 'Aviation Overview', 'INSIGHTS', 'RISK INTAKE']);
        await expect(aviationOverviewPage.section).toContainText(['Insights', 'Risk Intake']);
    }

    /**
     * Clicks on the Insights button and validates the placement insights.
     */
    public async navigateToInsight(): Promise<void> {
        const aviationOverviewPage = this.appMain.aviationOverviewPage
        await aviationOverviewPage.insightsButton.click();
        const clientPopup = new ClientSelectionPopup(this.page);
        // Handle intermittent client selection pop-up if it appears
        if (await clientPopup.isVisible()) {
            await clientPopup.selectClientByName('Scottsdale Inc (Demo)');
            await clientPopup.clickGo();
        }
        await this.page.waitForTimeout(10000);
        await aviationOverviewPage.waitForVisible(aviationOverviewPage.placementInsightsHeader);
        await expect(aviationOverviewPage.placementInsightsHeader).toBeVisible();
        await expect(aviationOverviewPage.placementAnalyticsReports).toMatchAriaSnapshot(`- text: RSM Market Aircraft Client History UAS Claims`, { timeout: 10000 });

    }

    public async interactWithChart(): Promise<void> {
        const aviationOverviewPage = this.appMain.aviationOverviewPage
        await expect(aviationOverviewPage.chart1).toMatchAriaSnapshot(`- button "Net Hull Rate By Insured Value"`);
        await this.page.getByRole('button', { name: 'Net Hull Rate By Insured Value' }).click();
        await expect(aviationOverviewPage.chart1).toMatchAriaSnapshot(`- button "Net Liability Premium By Limit"`);
    }

    public async validateHullValueChange(): Promise<void> {
       await this.appMain.aviationOverviewPage.placementInsightsButtonLink.click();

       const hullValueText = await this.appMain.filterPage.getFilterCardValue("HULL VALUE");

        await this.appMain.filterPage.filtersButton.click()
        await this.fitlerFn.clickFilterOptionAndApply("Plane Type", "UAS")
        await this.page.waitForTimeout(2000);

        const newHullValueText = await this.appMain.filterPage.getFilterCardValue("HULL VALUE");
        expect(hullValueText).not.toBe(newHullValueText)
    }

}
