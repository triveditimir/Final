import { Page } from "playwright";
import { AppMain } from "../../AppMain";
import { expect } from "allure-playwright";
import CommonFunctions from "../commonBusinessFunctions/CommonFunctions";

export default class LinqHomeFunction {
  readonly page: Page
  readonly appMain: AppMain
  readonly commonFn: CommonFunctions


  constructor(page: Page) {
    this.page = page
    this.appMain = new AppMain(page)
    this.commonFn = new CommonFunctions(page)

  }

  /**
 * Clicks on the logo to navigate back to the home page.
 */
  public async clickLogo(): Promise<void> {
    const linqHomePage = this.appMain.linqPage
    const logoContainer = linqHomePage.logoContainer
    await logoContainer.click();
  }
  /**
     * Login to LINQ Home pgae URL
     */
  public async navigateToLinqHomePage(): Promise<void> {
    const linqHomePage = this.appMain.linqPage
    await this.page.goto('https://staging2.linqbymarsh.com/linq/home');
    await linqHomePage.waitForVisible(linqHomePage.colleagueLoginLink);
    await linqHomePage.colleagueLoginLink.click();
  }
  /**
   * Clicks on the Aviation Insights General link and waits for the popup.
   *.
   */
  public async clickAviationInsights(): Promise<void> {
    const linqHomePage = this.appMain.linqPage
    //await this.page.waitForEvent('popup');
    await linqHomePage.waitForVisible(linqHomePage.aviationInsightsLink);
    await linqHomePage.aviationInsightsLink.click();
  }

  /**
   * Navigates to the home page and verifies the content.
   */
  public async navigateToHomePageAndVerify(): Promise<void> {
    const linqHomePage = this.appMain.linqPage
    await linqHomePage.waitForVisible(linqHomePage.homePageContainer);

    await expect(linqHomePage.homePageContainer).toMatchAriaSnapshot(`
      - text: My Data & Analytics My Policies & Programs My Team My Insights & Intelligence My Apps & Shortcuts My Favorites
    `);

    await expect(linqHomePage.homePageContainer).toMatchAriaSnapshot(`
      - emphasis: 
      - paragraph: Private Equity Mergers & Acquisitions
      - paragraph: Overview of Portfolio Company activity
      - emphasis: 
      - emphasis: 
      - paragraph: Aviation Insights
      - paragraph: General Aviation Benchmarking & Analytics
      - emphasis: 
      - emphasis: 
      - paragraph: Marine Insights
      - paragraph: Marine placement analysis and market intelligence
      - emphasis: 
    `);
  }
}
