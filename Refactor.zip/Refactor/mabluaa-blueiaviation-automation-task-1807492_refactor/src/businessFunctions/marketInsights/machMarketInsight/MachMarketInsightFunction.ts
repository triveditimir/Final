import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import { expect } from "allure-playwright";
import { crewSnapshot, planeTypeSnapshot, marketSnapshot, liabilityLimitSnapshot, yearSnapshot, yearQuarterSnapshot } from './AriaSnapshots';


export default class MachMarketInsightFunction {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    async verifyFiltersAndRetenion(): Promise<void> {
        const machMarketPage = this.appMain.machMarketInsightPage
        const machButton = machMarketPage.machButton()
        await machButton.click()
        // Verify Filters
        await this.verifyMACHDefaultFilterSettings();
        // Verify Rententions
        await this.validateFilterRetention();


        const resFilter = await this.appMain.filterPage.filterContainerLocator().getByText('UAS')
        await expect(resFilter).toBeChecked();

        //Reset Filters
        await machMarketPage.resetAllFilterButton.click();
        await this.page.waitForTimeout(5000);

        await machButton.click();
    };

    private async validateFilterRetention() {
        const machMarketPage = this.appMain.machMarketInsightPage
        await machMarketPage.uncheckPlaneType();
        await this.page.waitForTimeout(5000);
        const marketButton = await machMarketPage.marketButton;
        marketButton.click();
    }

    private async verifyMACHDefaultFilterSettings(): Promise<void> {
        const machMarketPage = this.appMain.machMarketInsightPage
        await machMarketPage.VerifyFiltersButtons();

        const filterNamesAndSnapshots = [
            { name: "Crew", snapshot: crewSnapshot },
            { name: "Plane Type", snapshot: planeTypeSnapshot },
            { name: "Market", snapshot: marketSnapshot },
            { name: "Liability Limit", snapshot: liabilityLimitSnapshot },
            { name: "Year", snapshot: yearSnapshot },
            { name: "Year Quarter", snapshot: yearQuarterSnapshot }
        ];

        for (const filter of filterNamesAndSnapshots) {
            const locator = await this.appMain.filterPage.filterContainer(filter.name);
            await machMarketPage.waitForVisible(locator);
            await expect(locator).toMatchAriaSnapshot(filter.snapshot);
        }
    }



    public async downloadMultipleMachChartsPresentonTop() {
        const machMarketInsightPage = this.appMain.machMarketInsightPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidateMachAverageHullAndNetLiabilityCharts = async () => {
            await downloadFuncs.downloadAsPdf();
            await machMarketInsightPage.machPrimaryDownlaod.click(); // Assuming primary download button
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };



        // Array of actions for each chart
        const machAverageHullAndNetLiabilityChartActions = [
            {
                action: async () => {
                    await machMarketInsightPage.averageHullRateBtn.click();
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.medianHullRate.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },
            {
                action: async () => {
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.averageHullRate.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },

            {
                action: async () => {
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.averageChangeHullRate.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },

             {
                action: async () => {
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.meidanChangeHullRate.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },


            {
                action: async () => {
                    await machMarketInsightPage.averageNetLiabilityBtn.click();
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.medianNetLiability.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },


             {
                action: async () => {
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.averageNetLiability.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },
            

             {
                action: async () => {
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.averageChangeNetLiability.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },

             {
                action: async () => {
                    await machMarketInsightPage.averageHullRatedropdown.click();
                    await machMarketInsightPage.medianChangeNetLiability.click();
                    await machMarketInsightPage.machPrimaryDownlaod.click();
                }
            },

            {
                action: async () => {
                    await machMarketInsightPage.liabilityPremiumbyLiabilityLimitBtn.click();
                    await machMarketInsightPage.actualBtn.click();
                    await machMarketInsightPage.machSecondaryDownlaod.click();
                }
            },

            {
                action: async () => {
                    await machMarketInsightPage.liabilityPremiumbyLiabilityLimitBtn.click();
                    await machMarketInsightPage.trendBtn.click();
                    await machMarketInsightPage.machSecondaryDownlaod.click();
                }
            },

            
            {
                action: async () => {
                    await machMarketInsightPage.hullRatebyInsuredValueBtn.click();
                    await machMarketInsightPage.actualBtn.click();
                    await machMarketInsightPage.machSecondaryDownlaod.click();
                }
            },

            {
                action: async () => {
                    await machMarketInsightPage.hullRatebyInsuredValueBtn.click();
                    await machMarketInsightPage.trendBtn.click();
                    await machMarketInsightPage.machSecondaryDownlaod.click();
                }
            },


            
        ];

        // Loop through each chart action
        for (const chart of machAverageHullAndNetLiabilityChartActions) {
            await chart.action();
            await downloadAndValidateMachAverageHullAndNetLiabilityCharts();
        }
    }

    
}