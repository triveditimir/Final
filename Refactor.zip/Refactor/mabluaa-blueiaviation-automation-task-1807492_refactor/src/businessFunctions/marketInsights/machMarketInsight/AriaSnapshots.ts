export const crewSnapshot = `
    - text: Crew 
    - radio "All" [checked]
    - text: All
    - radio "2+"
    - text: 2+
`;

export const planeTypeSnapshot = `
    - text: Plane Type  
    - textbox "Enter search term"
    - text: Select All
    - checkbox "Jet Engine" [checked]
    - text: Jet Engine
    - checkbox "UAS"
    - text: UAS
`;

export const marketSnapshot = `
    - text: Market  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Starr" [checked]
    - text: Starr
`;

export const liabilityLimitSnapshot = `
    - text: Liability Limit  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "$100,000,000" [checked]
    - text: $100,000,000
    - checkbox "$300,000,000"
    - text: "$300,000,000"
`;

export const yearSnapshot = `
    - text: Year  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "2025" [checked]
    - text: "2025"
    - checkbox "2024"
    - text: "2024"
`;

export const yearQuarterSnapshot = `
    - text: Year Quarter  
    - textbox "Enter search term"
    - text: Clear All
    - checkbox "Q1" [checked]
    - text: Q1
`;
