import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import { expect } from "allure-playwright";
import { crewSnapshot, businessTypeSnapshot, planeTypeSnapshot, yearSnapshot, quotaShareSnapshot, marketSnapshot, yearQuarterSnapshot } from './AriaSnapshots';
import FilterFunctions from "../../commonBusinessFunctions/FilterBusinessFunctions";
import GraphFunctions from "../../commonBusinessFunctions/GraphBusinessFunctions";
import CommonFunctions from "../../commonBusinessFunctions/CommonFunctions";

export default class hullMarketInsightFunction {
    readonly page: Page
    readonly appMain: AppMain
    readonly commonFn: CommonFunctions

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
        this.commonFn = new CommonFunctions(page)
    }

    async verifyToggleLabels(): Promise<void> {
        const insightsPage = this.appMain.insightsPage
        const hullButton = await insightsPage.clickonHull
        await hullButton.click();
        //Validate toggle lables
        const hullToggleBtn = await insightsPage.hullInsightToggleBtn
        await hullToggleBtn.first().click();
        await expect(hullToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')
        await hullToggleBtn.last().click();
        await expect(hullToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')

    }
    async verifyFiltersAndRetenion(): Promise<void> {
        const insightsPage = this.appMain.insightsPage
        const hullButton = await insightsPage.clickonHull

        await hullButton.click();

        // Verify Filters
        await this.verifyDefaultFilterSettings();
        // Verify Rententions
        await this.validateFilterRetention();


        const resFilter = await insightsPage.filterContainerLocator().getByText('Commercial')
        await expect(resFilter).not.toBeChecked();

        //Reset Filters
        await insightsPage.resetAllFilterButton.click();
        await this.page.waitForTimeout(5000);

        await hullButton.click();
    };

    public async verifyGraphAxesWithClickOnFilterOption(filterName: string, filterValue?: string, resetFilters: boolean = true): Promise<void> {
        const filterFunctions = new FilterFunctions(this.page)
        console.log(filterName, filterValue)
        await filterFunctions.clickFilterOption(filterName, filterValue)
        await filterFunctions.applyFilters()

        await this.verifyChartAxes()

        if (resetFilters) {
            await filterFunctions.resetAllFilters();
        }
    }

    public async verifyChartAxes() {
        const graphFunctions = new GraphFunctions(this.page)
        const chartSelector = '#yearChangeHullRate';
        graphFunctions.verifyChartAxes(chartSelector)
    }

    public async verifyGraphFootersHull() {
        const graphFunctions = new GraphFunctions(this.page)

        await graphFunctions.verifyGraphFooters("chart1", [
            "Plane Type",
            "Insured Value Range",
            "Sample Count",
            " Time Frame",
            " Quarter"
        ])
        // Average Hull Rate Trend is blank for now
        /* await graphFunctions.verifyGraphFooters("chart2", [
          "Plane Type",
          "Insured Value Range",
          "Sample Count",
        ]) */
        const insightsPage = this.appMain.insightsPage
        await insightsPage.clickAverageHullRate.click();
        await graphFunctions.verifyGraphFooters("chart2", [
            "Plane Type",
            "Insured Value Range",
            "Sample Count"
        ])

        await this.commonFn.validateTableHasData(insightsPage.averageHullRateTable);
        await insightsPage.clickAnnualHullRateTrend.click();
        await this.page.waitForTimeout(3000)

    }



    private async validateFilterRetention() {
        const insightsPage = this.appMain.insightsPage
        await insightsPage.uncheckCommercialBusinessType();
        await this.page.waitForTimeout(5000);
        const hullButton = await insightsPage.clickonHull;
        hullButton.click();
    }

    private async verifyDefaultFilterSettings(): Promise<void> {
        const insightsPage = this.appMain.insightsPage

        await insightsPage.VerifyFiltersButtons();

        const filterNamesAndSnapshots = [
            { name: "Crew", snapshot: crewSnapshot },
            { name: "Business Type", snapshot: businessTypeSnapshot },
            { name: "Plane Type", snapshot: planeTypeSnapshot },
            { name: "Market", snapshot: marketSnapshot },
            { name: "Year", snapshot: yearSnapshot },
            { name: "Year Quarter", snapshot: yearQuarterSnapshot },
            { name: "Quota Share", snapshot: quotaShareSnapshot }
        ];

        for (const filter of filterNamesAndSnapshots) {
            const locator = await insightsPage.filterContainer(filter.name);
            await insightsPage.waitForVisible(locator);
            await expect(locator).toMatchAriaSnapshot(filter.snapshot);
        }
    }

    public async percentPlacementYoYRangegetText(): Promise<string> {
        const insightsPage = this.appMain.insightsPage;
        await insightsPage.percentPlacementYoYRange.waitFor({ state: 'visible', timeout: 5000 });
        const textContent = await insightsPage.percentPlacementYoYRange.textContent();
        console.log('Locator Text is :', textContent);
        return textContent.trim();
    }


    public async downloadMHullCharts() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidateYearOverYearChangeHUllRate = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.clickhullPrimaryDownlaod.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const YearOverYearChangeHUllRate = [
            {
                description: 'Year Over Year Change HUllRate',
                action: async () => {

                    await insightsPage.clickhullPrimaryDownlaod.click();
                }
            },
        ];

        // Loop through each chart action
        for (const chart of YearOverYearChangeHUllRate) {
            await chart.action();
            await downloadAndValidateYearOverYearChangeHUllRate();
        }
    }


    public async downloadMultipleHullRateCharts() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidateAnnualHullCharts = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.clickhullSecondaryDownlaod.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const annualHullChartsActions = [
            {
                description: 'AnnualHullCharts',
                action: async () => {
                    await insightsPage.clickAnnualHullRateTrend.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

        ];
        for (const chart of annualHullChartsActions) {
            await chart.action();
            await downloadAndValidateAnnualHullCharts();
        }
    }


    public async downloadHullMultipleAverageCharts() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        const downloadAndValidateAerageHullCharts = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.clickhullSecondaryDownlaod.click();
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };
        // Array of chart actions
        const averagetHullChartsActions = [
            {
                description: 'AverageHullCharts',
                action: async () => {
                    await insightsPage.clickAverageHullRate.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

            {
                description: 'Hull Rate median',
                action: async () => {
                    await insightsPage.clickAverageHullRatedropdown.click();
                    await insightsPage.clickMedianHullRate.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },
            {
                description: 'Hull Rate Average %  Hull Rate',
                action: async () => {
                    await insightsPage.clickAverageHullRatedropdown.click();
                    await insightsPage.clickAverageHull.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

            {
                description: 'Hull Rate Median %  Hull Rate',
                action: async () => {
                    await insightsPage.clickAverageHullRatedropdown.click();
                    await insightsPage.clickMedianHull.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

            {
                description: 'Hull Rate Average %  Hull Value',
                action: async () => {
                    await insightsPage.clickAverageHullRatedropdown.click();
                    await insightsPage.clickAverageHullValue.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

            {
                description: 'Hull Rate Median %  Hull Value',
                action: async () => {
                    await insightsPage.clickAverageHullRatedropdown.click();
                    await insightsPage.clickMedianHullValue.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

            {
                description: 'Hull Rate Aircraft  Count Value',
                action: async () => {
                    await insightsPage.clickAverageHullRatedropdown.click();
                    await insightsPage.clickAirCraftValue.click();
                    await insightsPage.clickhullSecondaryDownlaod.click();
                }
            },

        ];
        for (const chart of averagetHullChartsActions) {
            await chart.action();
            await downloadAndValidateAerageHullCharts();
        }
    }


}
