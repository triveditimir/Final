import { Page } from "playwright";
import { AppMain } from "../../../AppMain";
import { expect } from "allure-playwright";

import { crewSnapshot, businessTypeSnapshot, planeTypeSnapshot, yearSnapshot, marketSnapshot, liabilityLimitSnapshot, yearQuarterSnapshot, quotaShareSnapshot } from './AriaSnapshots';
import FilterFunctions from "../../commonBusinessFunctions/FilterBusinessFunctions";
import GraphFunctions from "../../commonBusinessFunctions/GraphBusinessFunctions";

export default class underWriterMarketInsightFunction {
    readonly page: Page
    readonly appMain: AppMain

    constructor(page: Page) {
        this.page = page
        this.appMain = new AppMain(page)
    }

    async verifyToggleLabels(): Promise<void> {
        const insightsPage = this.appMain.insightsPage
        const underwriterButton = await insightsPage.clickonUnderwriter
        await underwriterButton.click();
        //Validate toggle lables
        const underWriterToggleBtn = await insightsPage.underWriterToggleBtn
        //await underWriterToggleBtn.first().click();
        //await expect(underWriterToggleBtn.first()).toHaveCSS('background-color', '#2640e8)')
        await expect(underWriterToggleBtn.first()).toHaveCSS('background-color', 'rgb(38, 64, 232)')
        await underWriterToggleBtn.last().click();
        await expect(underWriterToggleBtn.last()).toHaveCSS('background-color', 'rgb(38, 64, 232)')

    }
    async verifyFiltersAndRetenion(): Promise<void> {
        const insightsPage = this.appMain.insightsPage
        const underwriterButton = await insightsPage.clickonUnderwriter

        await underwriterButton.click();

        // Verify Filters
        await this.verifyDefaultFilterSettings();
        // Verify Rententions
        await this.validateFilterRetention();

        //TBD
        //  const resFilter = await insightsPage.filterContainerLocator().getByText('Starr')
        // await expect(resFilter).not.toBeChecked();
        //TBD

        //Reset Filters
        await insightsPage.resetAllFilterButton.click();
        await this.page.waitForTimeout(5000);

        await underwriterButton.click();
    };

    public async verifyGraphAxesWithClickOnFilterOption(filterName: string, filterValue?: string, resetFilters: boolean = true): Promise<void> {
        const filterFunctions = new FilterFunctions(this.page)
        console.log(filterName, filterValue)
        await filterFunctions.clickFilterOption(filterName, filterValue)
        await filterFunctions.applyFilters()

        await this.verifyChartAxes()

        if (resetFilters) {
            await filterFunctions.resetAllFilters();
        }
    }

    public async verifyChartAxes() {
        const graphFunctions = new GraphFunctions(this.page)
        const chartSelector = '#hullRate';
        graphFunctions.verifyChartAxes(chartSelector)
    }

    private async validateFilterRetention() {
        const insightsPage = this.appMain.insightsPage
        await insightsPage.uncheckCommercialBusinessType();
        await this.page.waitForTimeout(5000);
        const underwriterButton = await insightsPage.clickonUnderwriter;
        underwriterButton.click();
    }

    private async verifyDefaultFilterSettings(): Promise<void> {
        const insightsPage = this.appMain.insightsPage

        await insightsPage.VerifyFiltersButtons();

        const filterNamesAndSnapshots = [
            { name: "Crew", snapshot: crewSnapshot },
            { name: "Business Type", snapshot: businessTypeSnapshot },
            { name: "Plane Type", snapshot: planeTypeSnapshot },
            { name: "Market", snapshot: marketSnapshot },
            { name: "Liability Limit", snapshot: liabilityLimitSnapshot },
            { name: "Year", snapshot: yearSnapshot },
            { name: "Year Quarter", snapshot: yearQuarterSnapshot },
            { name: "Quota Share", snapshot: quotaShareSnapshot }
        ];

        for (const filter of filterNamesAndSnapshots) {
            const locator = await insightsPage.filterContainer(filter.name);
            await insightsPage.waitForVisible(locator);
            await expect(locator).toMatchAriaSnapshot(filter.snapshot);
        }
    }


    public async downloadMultiplePrimaryCharts() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation
        const downloadAndValidateUnderWriterAverageCharts = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.clickunderWriterPrimaryDownlaod.click(); // Assuming primary download button
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };



        // Array of actions for each chart
        const underWriterAverageChartsActions = [
            {
                description: 'Liability Premium Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.buttonLiabilityPremium.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },

            {
                description: 'Liability Premium Median Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumMedian.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },
            {
                description: 'Liability Premium Aircraft Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumAircraftCount.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },
            {
                description: 'Liability Premium Maximum Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumMaximum.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Premium Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickHullRateButton.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Median Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumMedian.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();


                }
            },
            {
                description: 'Hull Rate Average Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumAverage.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Aircraft Count Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumAircraftCount.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Maximum Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterPremiumdropDown.click();
                    await insightsPage.clickunderWriterPremiumMaximum.click();
                    await insightsPage.clickunderWriterPrimaryDownlaod.click();

                }
            }
        ];

        // Loop through each chart action
        for (const chart of underWriterAverageChartsActions) {
            await chart.action();
            await downloadAndValidateUnderWriterAverageCharts();
        }
    }


    // Helper function for secondary download and validation


    public async downloadUnderWriterMarketInsightAveragepercentChart() {
        const insightsPage = this.appMain.insightsPage;
        const downloadFuncs = this.appMain.downloadFunctions;

        // Helper function for download and validation

        const downloadAndValidateAveragepercentChart = async () => {
            await downloadFuncs.downloadAsPdf();
            await insightsPage.clickunderWriterSecondaryDownlaod.click(); // Assuming secondary download button
            await downloadFuncs.downloadAsPng();
            await downloadFuncs.validatePdfContent();
        };

        const underWriterAveragepercentChartsActions = [
            {

                description: 'Hull Rate in % Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickHullRateButton.click();
                    await insightsPage.clickunderWriterAveragedropDown.click();
                    await insightsPage.clickunderWriterSecondaryMaximum.click();
                    await insightsPage.clickunderWriterSecondaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate median in % Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterAveragedropDown.click();
                    await insightsPage.clickunderWriterSecondaryMedian.click();
                    await insightsPage.clickunderWriterSecondaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Average in % Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterAveragedropDown.click();
                    await insightsPage.clickunderWriterSecondaryAverage.click();
                    await insightsPage.clickunderWriterSecondaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Maximum in % Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickLiabilitySecondaryButton.click();
                    await insightsPage.clickunderWriterAveragedropDown.click();
                    await insightsPage.clickunderWriterSecondaryMaximum.click();
                    await insightsPage.clickunderWriterSecondaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate median in % Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterAveragedropDown.click();
                    await insightsPage.clickunderWriterSecondaryMedian.click();
                    await insightsPage.clickunderWriterSecondaryDownlaod.click();

                }
            },
            {
                description: 'Hull Rate Download for Hull Rate Average',
                action: async () => {
                    await insightsPage.clickunderWriterAveragedropDown.click();
                    await insightsPage.clickunderWriterSecondaryAverage.click();
                    await insightsPage.clickunderWriterSecondaryDownlaod.click();

                }
            }
        ];

        // Loop through each chart action
        for (const chart of underWriterAveragepercentChartsActions) {
            await chart.action();

            await downloadAndValidateAveragepercentChart();
        }
    }


}
