import dialog from 'dialog-node';
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { PlaywrightWebBaseLoader, Page } from "langchain/document_loaders/web/playwright";
import path from 'path';
import fs from 'fs';
import { TextLoader } from 'langchain/document_loaders/fs/text';
import {
  RunnableConfig,
  RunnableWithMessageHistory,
} from "@langchain/core/runnables";
import { ChatMessageHistory } from "@langchain/community/stores/message/in_memory";
import { error } from 'console';
import config from '../../config/config.json' with {type:"json"}



var dir = '././data/output/Rec/';

const basePath = config.openaiBasePath;



const model = new ChatOpenAI({
  openAIApiKey: process.env.openaiApiKey,
  temperature: 0.1,
  maxRetries: 0,
  maxTokens: -1,
},
  {
    basePath: `${basePath}/mmc-tech-gpt-4o-mini-128k-2024-07-18/`,
  });

const chat = async () => {


  async function writeToHtmlFile(outputFilePath, htmlPage) {
    return new Promise((resolve, reject) => {
      fs.writeFile(outputFilePath, htmlPage, function (err) {
        if (err) reject(err);
        else resolve('Saved!');
      });
    });
  }

  const promptTemplate = ChatPromptTemplate.fromMessages([
    ["human", "You are a helpful assistant"],
    ["human", "{input}"],
  ]);




  const runnable = promptTemplate.pipe(model);

  const messageHistory = new ChatMessageHistory();

  const withHistory = new RunnableWithMessageHistory({
    runnable,

    getMessageHistory: (_sessionId: string) => messageHistory,
    inputMessagesKey: "input",

    historyMessagesKey: "history",
  });

  const __dirname = path.resolve();

  
  let names;
  async function readDirectory() {
    try{
      return await fs.readdirSync(dir);
    }catch(e){
      console.log("e",e)
      return "Error while reading file"
    }
  }
  var loaderHTML;
  var htmlText;
  var lengthofOutput;
  var maxToken = 10000
  var files = await readDirectory()
  console.log("-------------------------------------------------")
  console.log("files --> ",files.length)
  console.log("-------------------------------------------------")
  for (let i = 0; i < files.length; i++) {
    const config: RunnableConfig = { configurable: { sessionId: Math.random() * (100 - 1 + 1) + 1 } };
    var inputFilePathFeature = dir + "/"+files[i]
    var loader1 = new TextLoader(inputFilePathFeature)
    loaderHTML = await loader1.load()
    htmlText = loaderHTML[0].pageContent.toString()
    lengthofOutput = htmlText.length
    console.log("lengthofHTML", htmlText.length)
    var count = Math.ceil(lengthofOutput / maxToken)
    var start = 0
    var outputGherkinscript = "";
    var outputStepDefinition = "";
    for (let j = 0; j < count; j++) {
      var inputMessage = "Below is a playwright recording script. As a automation tester could you please help me to create a cucumberjs feature file using below playwright recorded script \n" + htmlText.substring(start, start + maxToken)
      var output = await withHistory.invoke({ input: inputMessage }, config);
      console.log("outputGherkinscript  ----------->",outputGherkinscript)
      if (!output.content.toString().toLowerCase().includes("sorry")) {
        outputGherkinscript = outputGherkinscript + output.content.toString()
      }
      //var inputMessagepage = "You are an automation tester. Below is a playwright recording script. Help me create page object pattern and getter setters for all the elements presented in recorded script in TypeScript format.\n" + htmlText.substring(start, start + maxToken)
      //var inputMessagepage = "You are an automation tester. Below html is a portion of the larger webpage. Help me create page object pattern and getter setters for all the elements if present with type links, text boxes, buttons, radio buttons, checkboxes and dropdowns with page object model for below HTML in selenium and java format. \n" + htmlText.substring(start, start + maxToken)
       var inputMessagepage = `You are an expert automation engineer specializing in Playwright and TypeScript.
                              Generate a production-ready Page Object Model implementation from the HTML file under sources ${htmlText.substring(start, start + maxToken)} and following are the requirements:

                              1. **Element Identification**
                              - Categorize elements by type: links, textboxes, buttons, radio, checkboxes, dropdowns
                              - Use semantic HTML attributes in priority order:
                              1. data-testid
                              2. ARIA roles
                              3. Text content matching
                              4. CSS selectors (last resort)

                              2. **Class Structure**
                              - Implement using Abstract Base Page pattern
                              - Separate element definitions from interaction methods
                              - Include type guards for dynamic element states

                              3. **Code Standards**
                              - TypeScript 5.0+ with strict null checks
                              - Playwright 1.40+ best practices
                              - Documentation with TSDoc
                              - Error handling for element visibility/timeouts

                              4. **Output Format**
                              Provide a complete TypeScript file with the following structure:
                              - Import statements for necessary Playwright modules.-Abstract Base Page class definition.
                              - Specific Page Object class definition (e.g., FirstPage).
                              - Element definitions as private getters.
                              - Public methods for interactions with the page.Error handling and visibility checks.
                              - TSDoc comments for each method and class. 
                              `
      var output1 = await withHistory.invoke({ input: inputMessagepage }, config);
      if (!output1.content.toString().toLowerCase().includes("sorry")) {
        outputStepDefinition = outputStepDefinition + output1.content.toString()
      }
      start = start + maxToken
    }
    var outputFilePathFeature = path.join(__dirname, "data", "output", "Feature", "featureRec_"  +files[i].substring(0,files[i].lastIndexOf(".")) + ".feature")
    if (outputGherkinscript.length > 0) {
      const fileWriteResult = await writeToHtmlFile(outputFilePathFeature, outputGherkinscript);
    }
    var outputFilePathDefinition = path.join(__dirname, "data", "output", "pageObject", "pageObjectRec_" + files[i].replace(".txt","") + ".steps.ts")
    if (outputStepDefinition.length > 0) {
      var inputMessageCodeOptimize = "Redefine the following typescript code to improve readability, performance, and best practices. Ensure correct type annotation, remove reduntant code, and optimize logic where necessary. Return only the improved code without any explanation" + outputStepDefinition
      var outputOptimizeCode = await withHistory.invoke({ input: inputMessageCodeOptimize }, config);
      var outputOptimizeCodeUpdated = outputOptimizeCode.content.toString()
      if (outputOptimizeCodeUpdated.length > 0){
        const fileWriteResult = await writeToHtmlFile(outputFilePathDefinition, outputOptimizeCodeUpdated);
      }
    }
  }
}
chat();
