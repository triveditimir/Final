import { test, Page } from '@playwright/test';
import * as dotenv from 'dotenv';
import AppFn from '../src/businessFunctions/AppFn';
import { AppMain } from '../src/AppMain';



let appMain: AppMain
let appFunc: AppFn

test.describe('UnderWriter Market Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    dotenv.config();

  });

  test.beforeEach(async ({ page }) => {
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {

  });

  test.afterAll(async () => {

  });

  test('Verify Underwriter Market Insight Filters and UI Elements @smoke @liability', async ({ page }, testInfo) => {
    await appMain.ClaimsMarketInsight.navigateToMarketInsights();

    await test.step('UnderWirter Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyMarketDashboardReports()
    });


    await test.step('Select Underwriter section and verify filters and retention', async () => {
      await appFunc.underWriterMarketInsightFunction.verifyFiltersAndRetenion()

    });

    await test.step('Verify filter chips value as selected in filters', async () => {
      await appFunc.filterFunctions.validatefilterChips()
    });

    await test.step('Verify chart chips', async () => {
      const liabilityPremiumToggleBtn = await appMain.insightsPage.liabilityPremiumToggleBtn
      await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart1", "Median")
      await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart1", "Maximum",liabilityPremiumToggleBtn.first())
      await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart2", "% Maximum")
      await appFunc.graphFunctions.verifyChartChangesOnDropdownSelection("#chart2", "% Average",liabilityPremiumToggleBtn.last())
    });

    await test.step('UnderWriter: Verify Toggle Button', async () => {
      await appFunc.underWriterMarketInsightFunction.verifyToggleLabels();

    });


    await test.step('Validate footer and disclaimers visibility', async () => {
      await appFunc.dashboardFunctions.validateFooter();
    });

    await test.step('Validate Graph Axes for different filters', async () => {
      
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Crew", "All", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Plane Type", "UAS", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Plane Type", "Jet Engine", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Business Type", "Industrial Aid", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Business Type", "Commercial", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Liability Limit", "$300,000,000", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Liability Limit", "$100,000,000", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Market", "Starr", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Year", "2025", true)
      await appFunc.underWriterMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Year Quarter", "Q1", true)

      

      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      //await appFunc.graphFunctions.verifyChartAxes(chartId)
      await appFunc.filterFunctions.resetAllFilters();
      // All years selected to enable more options in Year Quater

      // All years selected to enable more options in Quota Share
      //await appFunc.filterFunctions.selectAllFilterOptions("Year")
      //await appFunc.liabilityMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Quota Share", "Quota Share", true)

    })

    await test.step('Validate Warning when filters incorrect', async () => {
      await appFunc.filterFunctions.resetAllFilters();
      await appFunc.filterFunctions.unSelectFilterOptionsAllAndValidateWarning("Commercial", "Insufficient Data")
      await appFunc.filterFunctions.resetAllFilters();
    })
    // Download Chart Different Charts of Market Insight in  PDF and PNG
    await test.step('Download Chart Different Charts of Market Insight in  PDF and PNG', async () => {
      await appFunc.underWriterMarketInsightFunction.downloadMultiplePrimaryCharts();
      await appFunc.underWriterMarketInsightFunction.downloadUnderWriterMarketInsightAveragepercentChart();



    });
  });

});

