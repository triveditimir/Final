import { test, expect, Page } from '@playwright/test';
//import { LoginPage } from '../data/output/pageObject/aviationOverviewPage';
//import { FileDownload } from '../data/output/utils/fileDownload';
//import { BlueIAviationInsightsPage } from '../data/output/pageObject/aviationInsightsPage';
import * as dotenv from 'dotenv';
import { captureXAxisLabels, captureYAxisLabels, validateGraphAxes } from '../data/output/Utils/graphValidationUtils';
import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';
//import { marketInsightsPage } from '../data/output/pageObject/marketInsightsPage';

let appMain: AppMain
let page: Page
let appFunc: AppFn

test.describe(' Market Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    dotenv.config();

  });

  test.beforeEach(async ({ page }) => {
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {
    // Capture screenshot after each test and attach to report
  });
  test.afterAll(async () => {
    // Cleanup steps after all tests run, e.g., close database connections
  });

  test('Verify Market Insight Filters and UI Elements @smoke @market', async ({ page }, testInfo) => {
    await appMain.ClaimsMarketInsight.navigateToMarketInsights();

    await test.step('Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyMarketDashboardReports()
    });

    await test.step('Select Market section and verify filters and retention', async () => {
      await appFunc.marketMarketInsightFunction.verifyFiltersAndRetenion()
    });

    await test.step('UnderWriter: Verify Toggle Button', async () => {
      await appFunc.graphFunctions.verifyToggleButtonIsSelected("Lost Business By Market");
    });

    await test.step('Validate footer and disclaimers visibility', async () => {
      await appFunc.dashboardFunctions.validateFooter();
    });

    await test.step('Validate Graph Axes for different filters', async () => {
      await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Crew", "2+", true)
      await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Plane Type", "UAS", true)
      await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Business Type", "Industrial Aid", true)

      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      await appFunc.marketMarketInsightFunction.verifyChartAxes()

      // Todo
      // All years selected to enable more options in Year Quater
      //await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Year Quarter", "Q3", true)

      // All years selected to enable more options in Quota Share
      //await appFunc.filterFunctions.selectAllFilterOptions("Year")
      //await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Quota Share", "Quota Share", true)

    })

    await test.step('Validate Warning when filters incorrect', async () => {
      await appFunc.filterFunctions.resetAllFilters();
      // Todo
      //await appFunc.filterFunctions.unSelectFilterOptionsAllAndValidateWarning("Business Type", "Insufficient Data")
      await appFunc.filterFunctions.resetAllFilters();
    })


    // Download Chart Different Charts of Market Insight in  PDF and PNG
    await test.step('Download Chart Different Charts of Market Insight in  PDF and PNG', async () => {
      await appFunc.marketMarketInsightFunction.downloadMultiplePrimaryCharts();
      await appFunc.marketMarketInsightFunction.downloadMultipleSecondaryCharts();

    });
  });

});

