import { test, expect, Page } from '@playwright/test';
import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';
import * as dotenv from 'dotenv';

let appMain: AppMain
let appFunc: AppFn

test.describe('Aviation Insight Dashboard', () => {
    test.beforeAll(async ({ browser }) => {
        // Setup steps before all tests run, e.g., initialize database connections, environment variables
        dotenv.config();
    });

    test.beforeEach(async ({ page }) => {
        // Setup steps before each test, e.g., navigate to login page
        appMain = new AppMain(page);
        appFunc = new AppFn(page)
        await test.step('Login as colleague', async () => {
            await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
            await appMain.BlueIAviationInsightsPage.loginAsColleague();
        });
    });

    test.afterEach(async ({ page }, testInfo) => {
        // Capture screenshot after each test and attach to report
        const screenshot = await page.screenshot();
        await testInfo.attach('Screenshot', {
            body: screenshot,
            contentType: 'image/png',
        });
    });

    test.afterAll(async () => {
        // Cleanup steps after all tests run, e.g., close database connections
    });
    test('Validate aviation Insight Dashboard elements', async ({ page }, testInfo) => {

        await test.step('Market Insights: Verify dashboard', async () => {
            await appFunc.aviationOverviewFunction.validateOverviewPage()
        });

        await test.step('Validate Footers of Aviation Overview Page', async () => {
            await appFunc.dashboardFunctions.validateFooter()
        });

        await test.step('Navigate to Insights', async () => {
            await appFunc.aviationOverviewFunction.navigateToInsight()
        });

        await test.step('Interact with Charts for placement Insights', async () => {
            await appFunc.aviationOverviewFunction.interactWithChart()
        });

        await test.step('validate Hull Value Change on RSM Dashboard', async () => {
            await appFunc.aviationOverviewFunction.validateHullValueChange
        });
    })
})