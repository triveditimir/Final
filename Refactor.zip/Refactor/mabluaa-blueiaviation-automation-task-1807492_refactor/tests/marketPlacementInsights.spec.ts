import { test } from '@playwright/test';
import * as dotenv from 'dotenv';
import { AppMain } from '../src/AppMain';
import AppFn from '../src/businessFunctions/AppFn';

let appMain: AppMain
let appFunc: AppFn

test.describe(' Placement Insight Tests', () => {
  test.beforeAll(async ({ browser }) => {
    dotenv.config();

  });

  test.beforeEach(async ({ page }) => {
    appMain = new AppMain(page);
    appFunc = new AppFn(page)
    await test.step('Login as colleague', async () => {
      await appMain.BlueIAviationInsightsPage.navigateToBaseURL();
      await appMain.BlueIAviationInsightsPage.loginAsColleague();
    });
  });

  test.afterEach(async ({ page }, testInfo) => {
    // Capture screenshot after each test and attach to report
  });
  test.afterAll(async () => {
    // Cleanup steps after all tests run, e.g., close database connections
  });

  test('Verify Placement Market Insight Filters and UI Elements @smoke @market', async ({ page }, testInfo) => {
    await appMain.claimsPlacementInsight.navigateToPlacementInsights();

    await test.step('Placement Market Insights: Verify dashboard', async () => {
      await appFunc.dashboardFunctions.verifyPlacementDashboardReports()
    });

   await test.step('Placement Market: Verify Toggle Button', async () => {
                 await appFunc.graphFunctions.verifyToggleButtonIsSelected("Net Hull Rate Change");
              
           });

    await test.step('Select Market section and verify filters and retention', async () => {
      await appFunc.placeamentMarketInsight.verifyFiltersAndRetenion()

    });

    await test.step('UnderWriter: Verify Toggle Button', async () => {
              await appFunc.graphFunctions.verifyToggleButtonIsSelected("Lost Business By Market");
           
        });

    await test.step('Validate footer and disclaimers visibility', async () => {
      await appFunc.dashboardFunctions.validateFooter();
    });

    await test.step('Validate Graph Axes for different filters', async () => {
      await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Crew", "2+", true)
      await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Plane Type", "UAS", true)
      await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Business Type", "Industrial Aid", true)
      //await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Liability Limit", "$300,000,000", true)

      await appFunc.filterFunctions.selectAllFilterOptions("Year")
      await appFunc.marketMarketInsightFunction.verifyChartAxes()
      // All years selected to enable more options in Year Quater
      //await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Year Quarter", "Q3", true)

      // All years selected to enable more options in Quota Share
      //await appFunc.filterFunctions.selectAllFilterOptions("Year")
      //await appFunc.marketMarketInsightFunction.verifyGraphAxesWithClickOnFilterOption("Quota Share", "Quota Share", true)

    })

    await test.step('Validate Warning when filters incorrect', async () => {
      await appFunc.filterFunctions.resetAllFilters();
      //await appFunc.filterFunctions.unSelectFilterOptionsAllAndValidateWarning("Business Type", "Insufficient Data")
      await appFunc.filterFunctions.resetAllFilters();
    })

    
    // Download Chart Different Charts of Market Insight in  PDF and PNG
    await test.step('Download Chart Different Charts of Market Insight in  PDF and PNG', async () => {
    await appFunc.marketMarketInsightFunction.downloadMultiplePrimaryCharts();
    await appFunc.marketMarketInsightFunction.downloadMultipleSecondaryCharts();
    
  });
    });
  
  });

 