# PAIGe
 "PAIGe: POM AI Generated"
 
A tool to help speed up UI automation testing in applications. The tool uses OpenAI API to generate the tests and the Page Object for web pages.
It will help the manual testers to capture and write page objects for their applications by interactively capturing pages.
The user will effectively navigate through the web applications and capturing pages to be automated.

The utility it aimed at reducing the efforts required to automate UI testing thereby increasing the ROI.
User Guide

**Prerequisites**:
1. Node.js installed on your machine.
2. Len AI key (Follow the instructions mentioned in https://hubble.mmc.com/)
3. Visual Studio Code

**Installation**:
1.Clone the repo on your system from https://github.com/mmctech/pageObjectPOC.git
2.Open the project in VS Code and in terminal run “npm install” to install all the dependencies for the project


**Configuration**:

 Edit the "siteURL" with your application URL and “openapikey” with your API key in config/confog.json file. (PLEASE DO NOT PUSH THE KEY TO GIT)


**Run**:

1. Open a terminal on Visual Studio Code.

2. Execute the command: “npm run PO” for generating the getter setter method using xpath

3. Execute the command: “npm run POHTML” for generating the getter setter method using existing HTML (HTML file should be present in data/output/HTML folder)

4. Execute the command: “npm run POREC” for generating the getter setter method using existing Playwright recording script (codegen) (Recording files should be present in data/output/Rec folder)

5. Execute the command: “npm run highlightandcapture” to create the getter and setter methods by utilizing mouse movement to capture the area or elements.

**Note** : Delete the files which are present in folder "Feature", "HTML", "Rec" and "pageObject" (path: data/output)



**Capturing Pages:**

1.The tool will launch a webpage with the url of the site given in configurations. Simultaneously, a dialogue box will open to prompt if you want to capture the page.
The tool will not capture anything unless the user clicks “OK”

2.On clicking “OK”, another prompt will ask the user to input the locator details. Since the tool uses OpenAI API, the token size needs to be smaller for better results.

3.Using inspect element, copy the XPath of the Area which we want to automate. Paste the copied XPath in the dialogue and click on OK

4.The user can continue navigating through their apps to interactively capture the pages to be automated. Once the user completes their navigations, the user can click on “Cancel” to stop the execution.

5.The utility will generate the below files for the users in the data/OutputFiles folder

	a.HTML – Stores the captured html code
 
	b.Feature – Gherkin BDD style tests to be used for cucumber
 
	c.pageObject – Generate Page Object code files
 
6.The page Object code files then can be imported withing your automation project to be used.



**Future work backlog:**

1.Handle multiple windows and iframes

2.Provision for multi language support to generate page objects

3.Create Step definition files using page objects and Feature files

